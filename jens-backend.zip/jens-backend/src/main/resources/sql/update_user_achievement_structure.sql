-- 更新用户成就表结构，使其与实体类匹配

-- 首先添加缺失的字段
ALTER TABLE `jens_user_achievement` 
ADD COLUMN `is_rewarded` TINYINT NULL DEFAULT 0 COMMENT '是否已发放奖励(0-未发放,1-已发放)' AFTER `achieve_time`,
ADD COLUMN `reward_points` INT NULL DEFAULT 0 COMMENT '奖励积分' AFTER `is_rewarded`,
ADD COLUMN `create_time` DATETIME NULL COMMENT '创建时间' AFTER `reward_points`,
ADD COLUMN `update_time` DATETIME NULL COMMENT '更新时间' AFTER `create_time`;

-- 将status字段的值复制到is_rewarded字段
UPDATE `jens_user_achievement` 
SET `is_rewarded` = `status` 
WHERE `is_rewarded` = 0 AND `status` = 1;

-- 更新创建时间和更新时间
UPDATE `jens_user_achievement` 
SET `create_time` = NOW(), 
    `update_time` = NOW() 
WHERE `create_time` IS NULL;

-- 从成就表获取奖励积分信息
UPDATE `jens_user_achievement` ua
JOIN `jens_achievement` a ON ua.`achievement_id` = a.`id`
SET ua.`reward_points` = a.`reward_points`
WHERE ua.`reward_points` = 0 AND a.`reward_points` > 0;

-- 查看修改后的表结构
-- DESCRIBE jens_user_achievement; 