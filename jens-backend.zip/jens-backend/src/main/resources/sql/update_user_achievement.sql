-- 更新用户成就表结构
-- 添加achievement_name列
ALTER TABLE `jens_user_achievement` 
ADD COLUMN `achievement_name` VARCHAR(50) NULL COMMENT '成就名称' AFTER `achievement_id`;

-- 更新注释，完善表结构说明
ALTER TABLE `jens_user_achievement` 
MODIFY COLUMN `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键ID',
MODIFY COLUMN `user_id` BIGINT NOT NULL COMMENT '用户ID',
MODIFY COLUMN `achievement_id` BIGINT NOT NULL COMMENT '成就ID',
MODIFY COLUMN `achieve_time` DATETIME NULL COMMENT '成就获得时间',
MODIFY COLUMN `is_rewarded` TINYINT NULL DEFAULT 0 COMMENT '是否已发放奖励(0-未发放,1-已发放)',
MODIFY COLUMN `reward_points` INT NULL DEFAULT 0 COMMENT '奖励积分',
MODIFY COLUMN `create_time` DATETIME NULL COMMENT '创建时间',
MODIFY COLUMN `update_time` DATETIME NULL COMMENT '更新时间';

-- 为了方便测试，从成就表中获取名称更新到用户成就表
UPDATE `jens_user_achievement` ua
JOIN `jens_achievement` a ON ua.`achievement_id` = a.`id`
SET ua.`achievement_name` = a.`name`
WHERE ua.`achievement_name` IS NULL; 