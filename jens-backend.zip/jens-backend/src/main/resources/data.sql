-- 添加碳减排系数
INSERT INTO `jens_carbon_factor` (`activity_type`, `factor_name`, `factor_value`, `unit`, `description`, `status`) VALUES
('walking', '步行碳减排系数', 0.000215, 'kg/m', '每米步行减少的二氧化碳排放量', 1),
('running', '跑步碳减排系数', 0.000275, 'kg/m', '每米跑步减少的二氧化碳排放量', 1),
('cycling', '骑行碳减排系数', 0.000196, 'kg/m', '每米骑行减少的二氧化碳排放量', 1)
ON DUPLICATE KEY UPDATE status = 1;

-- 添加成就
-- 确保使用完整的WHERE NOT EXISTS检查来避免重复插入
INSERT INTO `jens_achievement` (`name`, `description`, `type`, `condition_value`, `reward_points`, `status`)
SELECT '初级环保者', '累计减少1公斤碳排放', 'carbon', 1, 50, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `jens_achievement` WHERE `type` = 'carbon' AND `condition_value` = 1);

INSERT INTO `jens_achievement` (`name`, `description`, `type`, `condition_value`, `reward_points`, `status`)
SELECT '中级环保者', '累计减少5公斤碳排放', 'carbon', 5, 100, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `jens_achievement` WHERE `type` = 'carbon' AND `condition_value` = 5);

INSERT INTO `jens_achievement` (`name`, `description`, `type`, `condition_value`, `reward_points`, `status`)
SELECT '高级环保者', '累计减少10公斤碳排放', 'carbon', 10, 200, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `jens_achievement` WHERE `type` = 'carbon' AND `condition_value` = 10);

INSERT INTO `jens_achievement` (`name`, `description`, `type`, `condition_value`, `reward_points`, `status`)
SELECT '步行达人初级', '累计步行10000步', 'step', 10000, 50, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `jens_achievement` WHERE `type` = 'step' AND `condition_value` = 10000);

INSERT INTO `jens_achievement` (`name`, `description`, `type`, `condition_value`, `reward_points`, `status`)
SELECT '步行达人中级', '累计步行50000步', 'step', 50000, 100, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `jens_achievement` WHERE `type` = 'step' AND `condition_value` = 50000);

INSERT INTO `jens_achievement` (`name`, `description`, `type`, `condition_value`, `reward_points`, `status`)
SELECT '步行达人高级', '累计步行100000步', 'step', 100000, 200, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `jens_achievement` WHERE `type` = 'step' AND `condition_value` = 100000);

INSERT INTO `jens_achievement` (`name`, `description`, `type`, `condition_value`, `reward_points`, `status`)
SELECT '马拉松初体验', '累计跑步10公里', 'run_distance', 10000, 50, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `jens_achievement` WHERE `type` = 'run_distance' AND `condition_value` = 10000);

INSERT INTO `jens_achievement` (`name`, `description`, `type`, `condition_value`, `reward_points`, `status`)
SELECT '半程马拉松', '累计跑步21公里', 'run_distance', 21000, 100, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `jens_achievement` WHERE `type` = 'run_distance' AND `condition_value` = 21000);

INSERT INTO `jens_achievement` (`name`, `description`, `type`, `condition_value`, `reward_points`, `status`)
SELECT '马拉松完成者', '累计跑步42公里', 'run_distance', 42000, 200, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `jens_achievement` WHERE `type` = 'run_distance' AND `condition_value` = 42000);

-- 添加虚拟奖品
INSERT INTO `jens_prize` (`name`, `description`, `image_url`, `points_required`, `stock`, `prize_type`, `status`) VALUES
('碳中和证书', '获得个人专属碳中和电子证书', '/image/Prize/certificate.png', 500, 9999, 1, 1),
('视频平台月卡', '获得某视频平台VIP会员月卡', '/image/Prize/video_vip.png', 1000, 100, 1, 1),
('音乐平台季卡', '获得某音乐平台VIP会员季卡', '/image/Prize/music_vip.png', 2000, 50, 1, 1)
ON DUPLICATE KEY UPDATE status = 1;

-- 添加实物奖品
INSERT INTO `jens_prize` (`name`, `description`, `image_url`, `points_required`, `stock`, `prize_type`, `status`) VALUES
('定制环保袋', '可降解材质制作的定制环保购物袋', '/image/Prize/eco_bag.png', 800, 200, 2, 1),
('太阳能充电宝', '环保便携式太阳能充电宝', '/image/Prize/solar_charger.png', 3000, 50, 2, 1),
('智能水杯', '记录饮水量的智能水杯', '/image/Prize/smart_cup.png', 2500, 30, 2, 1)
ON DUPLICATE KEY UPDATE status = 1;

-- 添加测试用户(如果不存在)
INSERT INTO `jens_user` (`username`, `password`, `nickname`, `email`, `phone`, `carbon_points`, `status`)
SELECT 'admin', '$2a$10$ULxRssv/4NWOc388.1VBXe6HmQoVRw0xmSSby4iiWCqcxT9xvGMfC', '系统管理员', 'admin@example.com', '13800138000', 1100000, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `jens_user` WHERE username = 'admin');

-- 更新已存在的admin用户的手机号和积分
UPDATE `jens_user` SET `phone` = '13800138000', `carbon_points` = 1100000 WHERE `username` = 'admin' AND (`phone` IS NULL OR `phone` = '');

-- 添加默认传感器配置
INSERT INTO `jens_sensor_config` (`user_id`, `activity_type`, `heart_rate_min`, `heart_rate_max`, `speed_min`, `speed_max`, `step_frequency`, `enabled`)
SELECT 1, 'walking', 60, 120, 0.50, 2.00, 1.50, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `jens_sensor_config` WHERE user_id = 1 AND activity_type = 'walking');

INSERT INTO `jens_sensor_config` (`user_id`, `activity_type`, `heart_rate_min`, `heart_rate_max`, `speed_min`, `speed_max`, `step_frequency`, `enabled`)
SELECT 1, 'running', 100, 160, 2.00, 4.00, 2.50, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `jens_sensor_config` WHERE user_id = 1 AND activity_type = 'running');

INSERT INTO `jens_sensor_config` (`user_id`, `activity_type`, `heart_rate_min`, `heart_rate_max`, `speed_min`, `speed_max`, `step_frequency`, `enabled`)
SELECT 1, 'cycling', 80, 140, 3.00, 8.00, 1.00, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `jens_sensor_config` WHERE user_id = 1 AND activity_type = 'cycling'); 