package com.jens.green.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jens.green.entity.JENSActivityRecord;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import java.util.Date;

/**
 * 活动记录Mapper接口
 *
 * @author JENKENSSQ(JENS)
 */
public interface JENSActivityRecordMapper extends BaseMapper<JENSActivityRecord> {
    
    /**
     * 查询用户的活动记录
     * @param userId 用户ID
     * @return 活动记录列表
     */
    List<JENSActivityRecord> selectByUserId(@Param("userId") Long userId);
    
    /**
     * 根据用户ID和活动类型查询活动记录
     * @param userId 用户ID
     * @param activityType 活动类型
     * @param page 分页对象
     * @return 分页后的活动记录列表
     */
    IPage<JENSActivityRecord> selectByUserIdAndType(
        IPage<JENSActivityRecord> page,
        @Param("userId") Long userId, 
        @Param("activityType") String activityType);
    
    /**
     * 获取用户活动统计数据
     * @param userId 用户ID
     * @return 活动统计数据
     */
    List<JENSActivityRecord> selectStatsForUser(@Param("userId") Long userId);
} 