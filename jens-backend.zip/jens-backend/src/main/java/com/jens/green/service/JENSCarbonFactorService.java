package com.jens.green.service;

import com.jens.green.entity.JENSCarbonFactor;

import java.util.List;

/**
 * 碳因子服务接口
 *
 * @author JENKENSSQ(JENS)
 */
public interface JENSCarbonFactorService extends JENSBaseService<JENSCarbonFactor> {
    
    /**
     * 根据活动类型查询碳因子
     *
     * @param activityType 活动类型
     * @return 碳因子
     */
    JENSCarbonFactor getByActivityType(String activityType);
    
    /**
     * 获取所有启用的碳因子
     *
     * @return 碳因子列表
     */
    List<JENSCarbonFactor> getAllEnabledFactors();
} 