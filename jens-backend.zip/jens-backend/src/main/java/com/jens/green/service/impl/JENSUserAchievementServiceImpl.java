package com.jens.green.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;
import com.jens.green.constants.JENSConstants;
import com.jens.green.entity.JENSAchievement;
import com.jens.green.entity.JENSActivityRecord;
import com.jens.green.entity.JENSUserAchievement;
import com.jens.green.exception.JENSServiceException;
import com.jens.green.mapper.JENSUserAchievementMapper;
import com.jens.green.service.JENSAchievementService;
import com.jens.green.service.JENSActivityRecordService;
import com.jens.green.service.JENSPointsRecordService;
import com.jens.green.service.JENSUserAchievementService;
import com.jens.green.service.JENSUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 用户成就服务实现类
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@Service
public class JENSUserAchievementServiceImpl extends JENSBaseServiceImpl<JENSUserAchievementMapper, JENSUserAchievement> implements JENSUserAchievementService {

    @Autowired
    private JENSUserService userService;
    
    @Autowired
    private JENSAchievementService achievementService;
    
    @Autowired
    private JENSActivityRecordService activityRecordService;
    
    @Autowired
    private JENSPointsRecordService pointsRecordService;

    @Override
    public List<JENSUserAchievement> getUserAchievements(Long userId, Boolean achievedOnly) {
        // 验证用户是否存在
        if (userService.getById(userId) == null) {
            throw new JENSServiceException("用户不存在");
        }
        
        // 查询用户成就
        LambdaQueryWrapper<JENSUserAchievement> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(JENSUserAchievement::getUserId, userId);
        
        if (achievedOnly != null && achievedOnly) {
            // 已经获得的成就应该有获得时间
            queryWrapper.isNotNull(JENSUserAchievement::getAchieveTime);
        }
        
        queryWrapper.orderByDesc(JENSUserAchievement::getAchieveTime);
        
        return list(queryWrapper);
    }

    @Override
    public JENSPageResult<JENSUserAchievement> getUserAchievementsByPage(Long userId, Boolean achievedOnly, JENSPageRequest pageRequest) {
        // 验证用户是否存在
        if (userService.getById(userId) == null) {
            throw new JENSServiceException("用户不存在");
        }
        
        // 构建查询条件
        QueryWrapper<JENSUserAchievement> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId);
        
        if (achievedOnly != null) {
            if (achievedOnly) {
                queryWrapper.isNotNull("achieve_time");
            } else {
                queryWrapper.isNull("achieve_time");
            }
        }
        
        // 设置排序
        if (pageRequest.getOrderField() != null && !pageRequest.getOrderField().isEmpty()) {
            queryWrapper.orderBy(true, pageRequest.getIsAsc(), pageRequest.getOrderField());
        } else {
            // 默认按达成时间降序排序
            queryWrapper.orderByDesc("achieve_time");
        }
        
        return page(pageRequest, queryWrapper);
    }

    @Override
    public JENSUserAchievement getUserAchievementDetail(Long userId, Long achievementId) {
        // 查询用户成就
        LambdaQueryWrapper<JENSUserAchievement> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(JENSUserAchievement::getUserId, userId)
                .eq(JENSUserAchievement::getAchievementId, achievementId);
        
        JENSUserAchievement userAchievement = getOne(queryWrapper);
        if (userAchievement == null) {
            throw new JENSServiceException("用户成就记录不存在");
        }
        
        return userAchievement;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long grantAchievement(Long userId, Long achievementId) {
        // 验证用户是否存在
        if (userService.getById(userId) == null) {
            throw new JENSServiceException("用户不存在");
        }
        
        // 验证成就是否存在
        JENSAchievement achievement = achievementService.getById(achievementId);
        if (achievement == null) {
            throw new JENSServiceException("成就不存在");
        }
        
        // 查询用户是否已拥有该成就
        LambdaQueryWrapper<JENSUserAchievement> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(JENSUserAchievement::getUserId, userId)
                .eq(JENSUserAchievement::getAchievementId, achievementId);
        
        JENSUserAchievement userAchievement = getOne(queryWrapper);
        
        if (userAchievement != null && userAchievement.getAchieveTime() != null) {
            // 用户已经获得该成就
            return userAchievement.getId();
        }
        
        LocalDateTime now = LocalDateTime.now();
        
        if (userAchievement == null) {
            // 创建新的用户成就记录
            userAchievement = new JENSUserAchievement();
            userAchievement.setUserId(userId);
            userAchievement.setAchievementId(achievementId);
            userAchievement.setAchievementName(achievement.getName());
            userAchievement.setAchieveTime(now);
            userAchievement.setRewardPoints(achievement.getRewardPoints());
            userAchievement.setIsRewarded(1); // 默认自动发放奖励
            userAchievement.setCreateTime(now);
            
            save(userAchievement);
        } else {
            // 更新已有记录为已达成
            userAchievement.setAchieveTime(now);
            userAchievement.setIsRewarded(1);
            
            updateById(userAchievement);
        }
        
        // 发放奖励积分
        if (achievement.getRewardPoints() > 0) {
            String description = "获得成就【" + achievement.getName() + "】奖励";
            pointsRecordService.addPointsRecord(userId, achievement.getRewardPoints(), 
                    JENSConstants.PointsType.ACHIEVEMENT_REWARD, description, userAchievement.getId());
        }
        
        return userAchievement.getId();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<Long> checkUserAchievements(Long userId) {
        // 获取所有可用的成就
        List<JENSAchievement> allAchievements = achievementService.getAllEnabledAchievements();
        
        // 获取用户统计信息
        Map<String, Object> userStats = activityRecordService.calculateStatistics(userId);
        
        // 获取用户已获得的成就ID列表
        List<JENSUserAchievement> userAchievements = getUserAchievements(userId, true);
        List<Long> achievedIds = new ArrayList<>();
        for (JENSUserAchievement ua : userAchievements) {
            achievedIds.add(ua.getAchievementId());
        }
        
        // 新达成的成就ID列表
        List<Long> newAchievedIds = new ArrayList<>();
        
        // 检查每个成就是否达成
        for (JENSAchievement achievement : allAchievements) {
            // 跳过已达成的成就
            if (achievedIds.contains(achievement.getId())) {
                continue;
            }
            
            boolean achieved = false;
            
            // 根据成就类型和条件判断是否达成
            String achievementType = achievement.getAchievementType();
            if (JENSConstants.AchievementType.CARBON_REDUCTION.equals(achievementType)) {
                // 减碳量成就
                BigDecimal totalCarbonReduced = (BigDecimal) userStats.get("totalCarbonReduced");
                if (totalCarbonReduced != null) {
                    // 简化处理，conditionValue字段存储目标减碳量
                    try {
                        BigDecimal targetAmount = new BigDecimal(achievement.getConditionValue());
                        achieved = totalCarbonReduced.compareTo(targetAmount) >= 0;
                    } catch (Exception e) {
                        log.error("解析成就条件失败: " + e.getMessage());
                    }
                }
            } else if (JENSConstants.AchievementType.STEP.equals(achievementType)) {
                // 步行步数成就
                Integer totalSteps = (Integer) userStats.get("totalSteps");
                if (totalSteps != null) {
                    try {
                        int targetCount = achievement.getConditionValue();
                        achieved = totalSteps >= targetCount;
                    } catch (Exception e) {
                        log.error("解析成就条件失败: " + e.getMessage());
                    }
                }
            } else if (JENSConstants.AchievementType.RUN_DISTANCE.equals(achievementType)) {
                // 跑步距离成就
                Integer totalRunDistance = (Integer) userStats.get("totalRunDistance");
                if (totalRunDistance != null) {
                    try {
                        int targetCount = achievement.getConditionValue();
                        achieved = totalRunDistance >= targetCount;
                    } catch (Exception e) {
                        log.error("解析成就条件失败: " + e.getMessage());
                    }
                }
            } else if (JENSConstants.AchievementType.CONSECUTIVE_CHECK_IN.equals(achievementType)) {
                // 连续打卡成就
                // 此处可能需要更复杂的逻辑来判断连续打卡天数
            } else if (JENSConstants.AchievementType.SPECIAL.equals(achievementType)) {
                // 特殊成就，需要单独判断
            }
            
            // 如果达成了成就，授予用户
            if (achieved) {
                Long userAchievementId = grantAchievement(userId, achievement.getId());
                if (userAchievementId != null) {
                    newAchievedIds.add(achievement.getId());
                }
            }
        }
        
        return newAchievedIds;
    }

    @Override
    public Map<String, Object> getUserAchievementStatistics(Long userId) {
        // 验证用户是否存在
        if (userService.getById(userId) == null) {
            throw new JENSServiceException("用户不存在");
        }
        
        // 获取所有成就
        List<JENSAchievement> allAchievements = achievementService.getAllEnabledAchievements();
        int totalAchievements = allAchievements.size();
        
        // 获取用户已达成的成就
        List<JENSUserAchievement> userAchievements = getUserAchievements(userId, true);
        int achievedCount = userAchievements.size();
        
        // 按类型统计
        Map<String, Integer> achievedByType = new HashMap<>();
        Map<String, Integer> totalByType = new HashMap<>();
        
        for (JENSAchievement achievement : allAchievements) {
            String type = achievement.getAchievementType();
            totalByType.put(type, totalByType.getOrDefault(type, 0) + 1);
        }
        
        // 为了避免用户成就表中可能没有存储成就类型，需要通过成就ID查找对应的成就类型
        for (JENSUserAchievement userAchievement : userAchievements) {
            Long achievementId = userAchievement.getAchievementId();
            JENSAchievement achievement = achievementService.getById(achievementId);
            if (achievement != null) {
                String type = achievement.getAchievementType();
                achievedByType.put(type, achievedByType.getOrDefault(type, 0) + 1);
            }
        }
        
        // 构建结果
        Map<String, Object> result = new HashMap<>();
        result.put("totalAchievements", totalAchievements);
        result.put("achievedCount", achievedCount);
        result.put("unachievedCount", totalAchievements - achievedCount);
        result.put("achievementProgress", totalAchievements > 0 ? (float) achievedCount / totalAchievements : 0);
        result.put("achievedByType", achievedByType);
        result.put("totalByType", totalByType);
        
        return result;
    }
} 