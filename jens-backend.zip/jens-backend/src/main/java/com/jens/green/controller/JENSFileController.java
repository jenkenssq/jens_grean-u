package com.jens.green.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 文件控制器
 * 处理文件上传和下载
 */
@RestController
@RequestMapping("/api/file")
public class JENSFileController {

    // 文件上传路径
    private final Path uploadPath = Paths.get("src/main/resources/static/uploads");

    /**
     * 上传图片接口
     * @param file 上传的文件
     * @return 包含文件URL的JSON响应
     */
    @PostMapping("/upload/image")
    public Map<String, Object> uploadImage(@RequestParam("file") MultipartFile file) {
        Map<String, Object> result = new HashMap<>();
        
        if (file.isEmpty()) {
            result.put("code", 400);
            result.put("message", "请选择要上传的文件");
            return result;
        }
        
        try {
            // 确保上传目录存在
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }
            
            // 获取原始文件名
            String originalFilename = StringUtils.cleanPath(file.getOriginalFilename());
            
            // 获取文件扩展名
            String fileExtension = "";
            if (originalFilename.contains(".")) {
                fileExtension = originalFilename.substring(originalFilename.lastIndexOf('.'));
            }
            
            // 生成新的文件名
            String newFilename = UUID.randomUUID().toString() + fileExtension;
            
            // 保存文件
            Path targetLocation = uploadPath.resolve(newFilename);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
            
            // 构建文件URL
            String fileUrl = "/uploads/" + newFilename;
            
            result.put("code", 200);
            result.put("message", "文件上传成功");
            result.put("data", fileUrl);
            
            return result;
        } catch (IOException e) {
            result.put("code", 500);
            result.put("message", "文件上传失败: " + e.getMessage());
            return result;
        }
    }
    
    /**
     * 获取图片接口
     * @param filename 图片文件名
     * @return 图片资源
     */
    @GetMapping("/image/{filename:.+}")
    public ResponseEntity<Resource> getImage(@PathVariable String filename) {
        try {
            Path filePath = uploadPath.resolve(filename);
            Resource resource = new UrlResource(filePath.toUri());
            
            if (resource.exists() && resource.isReadable()) {
                return ResponseEntity.ok()
                        .contentType(MediaType.IMAGE_JPEG)
                        .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + resource.getFilename() + "\"")
                        .body(resource);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (MalformedURLException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    /**
     * 删除图片接口
     * @param filename 图片文件名
     * @return 操作结果
     */
    @DeleteMapping("/image/{filename:.+}")
    public Map<String, Object> deleteImage(@PathVariable String filename) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            Path filePath = uploadPath.resolve(filename);
            boolean deleted = Files.deleteIfExists(filePath);
            
            if (deleted) {
                result.put("code", 200);
                result.put("message", "文件删除成功");
            } else {
                result.put("code", 404);
                result.put("message", "文件不存在");
            }
            
            return result;
        } catch (IOException e) {
            result.put("code", 500);
            result.put("message", "文件删除失败: " + e.getMessage());
            return result;
        }
    }
} 