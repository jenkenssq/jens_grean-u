package com.jens.green.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 碳减排因子实体类
 * 
 * @author JENKENSSQ(JENS)
 */
@Data
@TableName("jens_carbon_factor")
public class JENSCarbonFactor {
    
    /**
     * 因子ID
     */
    private Long id;
    
    /**
     * 活动类型
     */
    private String activityType;
    
    /**
     * 碳减排因子值
     */
    private BigDecimal factorValue;
    
    /**
     * 描述
     */
    private String description;
    
    /**
     * 状态：0-禁用，1-启用
     */
    private Integer status;
    
    /**
     * 因子名称
     */
    private String factorName;
    
    /**
     * 单位
     */
    private String unit;
    
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
} 