package com.jens.green.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.jens.green.entity.JENSUser;
import com.jens.green.exception.JENSServiceException;
import com.jens.green.mapper.JENSUserMapper;
import com.jens.green.model.request.JENSRegisterRequest;
import com.jens.green.service.JENSUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 用户服务实现类
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@Service
public class JENSUserServiceImpl extends JENSBaseServiceImpl<JENSUserMapper, JENSUser> implements JENSUserService {

    @Override
    public JENSUser getUserByUsername(String username) {
        // 使用新定义的方法替代原来的Lambda查询
        return baseMapper.selectByUsername(username);
    }

    @Override
    public Long getUserIdByUsername(String username) {
        JENSUser user = getUserByUsername(username);
        return user != null ? user.getId() : null;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean register(JENSUser user) {
        try {
            // 检查用户名是否已存在
            JENSUser existUser = getUserByUsername(user.getUsername());
            if (existUser != null) {
                throw new JENSServiceException("用户名已存在");
            }
            
            // 检查邮箱是否已被使用
            if (user.getEmail() != null && !user.getEmail().isEmpty()) {
                boolean emailExists = existsByEmail(user.getEmail());
                if (emailExists) {
                    throw new JENSServiceException("该邮箱已被注册");
                }
            }
            
            // 密码加密
            user.setPassword(encryptPassword(user.getPassword()));
            
            // 设置初始值
            user.setTotalCarbon(BigDecimal.ZERO);
            user.setCarbonPoints(0);
            user.setTotalPoints(0);
            user.setStatus(1); // 默认启用
            user.setCreateTime(LocalDateTime.now());
            user.setUpdateTime(LocalDateTime.now());
            
            // 防止字段为null导致SQL插入失败
            if (user.getGender() == null) {
                user.setGender(0); // 未知
            }
            
            return save(user);
        } catch (Exception e) {
            // 记录错误日志
            System.err.println("注册用户时发生异常: " + e.getMessage());
            e.printStackTrace();
            throw e; // 重新抛出异常以便事务回滚
        }
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean register(JENSRegisterRequest registerRequest) {
        try {
            JENSUser user = new JENSUser();
            BeanUtils.copyProperties(registerRequest, user);
            
            // 设置昵称（如果未设置）
            if (user.getNickname() == null || user.getNickname().isEmpty()) {
                user.setNickname(registerRequest.getUsername());
            }
            
            // 设置手机号，防止空指针异常
            String mobile = registerRequest.getMobile();
            if (mobile != null) {
                user.setPhone(mobile);
            }
            
            return register(user);
        } catch (Exception e) {
            // 记录错误日志
            System.err.println("注册过程中发生异常(JENSRegisterRequest): " + e.getMessage());
            e.printStackTrace();
            throw e; // 重新抛出异常以便事务回滚
        }
    }

    @Override
    public JENSUser login(String username, String password) {
        JENSUser user = getUserByUsername(username);
        if (user == null) {
            return null; // 用户不存在
        }
        
        // 使用新的验证方法验证密码
        if (!verifyPassword(password, user.getPassword())) {
            return null; // 密码错误
        }
        
        // 检查用户状态
        if (user.getStatus() != 1) {
            throw new JENSServiceException("用户已被禁用");
        }
        
        return user;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateUserPoints(Long userId, BigDecimal carbonReduced, Integer pointsEarned) {
        JENSUser user = getById(userId);
        if (user == null) {
            throw new JENSServiceException("用户不存在");
        }
        
        // 使用新定义的方法更新用户积分和碳减排量
        int result1 = baseMapper.updateCarbonPoints(userId, pointsEarned);
        int result2 = baseMapper.updateTotalCarbon(userId, carbonReduced.doubleValue());
        
        return result1 > 0 && result2 > 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean consumePoints(Long userId, Integer points) {
        if (!checkPointsEnough(userId, points)) {
            throw new JENSServiceException("积分不足");
        }
        
        // 消费积分时，用负数更新积分
        int result = baseMapper.updateCarbonPoints(userId, -points);
        return result > 0;
    }

    @Override
    public boolean checkPointsEnough(Long userId, Integer points) {
        JENSUser user = getById(userId);
        if (user == null) {
            throw new JENSServiceException("用户不存在");
        }
        
        return user.getCarbonPoints() >= points;
    }
    
    @Override
    public boolean existsByUsername(String username) {
        LambdaQueryWrapper<JENSUser> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(JENSUser::getUsername, username);
        return baseMapper.exists(queryWrapper);
    }
    
    @Override
    public boolean existsByEmail(String email) {
        LambdaQueryWrapper<JENSUser> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(JENSUser::getEmail, email);
        return baseMapper.exists(queryWrapper);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateLastLoginTime(Long userId) {
        LambdaUpdateWrapper<JENSUser> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(JENSUser::getId, userId)
                .set(JENSUser::getUpdateTime, LocalDateTime.now());
        return update(updateWrapper);
    }
    
    @Override
    public List<String> getUserRoles(Long userId) {
        // 实际项目中应该从角色表查询用户角色
        // 这里简化处理，所有用户都是普通用户
        if (userId != null && userId > 0) {
            if (userId == 1) {
                return Arrays.asList("admin", "user"); // 管理员+用户角色
            }
            return Collections.singletonList("user"); // 普通用户角色
        }
        return Collections.emptyList();
    }
    
    @Override
    public List<String> getUserPermissions(Long userId) {
        // 实际项目中应该从权限表查询用户权限
        // 这里简化处理，根据用户角色返回不同权限
        List<String> roles = getUserRoles(userId);
        List<String> permissions = new ArrayList<>();
        
        if (roles.contains("admin")) {
            permissions.add("system:manage");
            permissions.add("user:manage");
            permissions.add("data:export");
        }
        
        if (roles.contains("user")) {
            permissions.add("user:info");
            permissions.add("activity:submit");
            permissions.add("point:exchange");
        }
        
        return permissions;
    }
    
    /**
     * 密码加密
     *
     * @param password 原密码
     * @return 加密后的密码
     */
    private String encryptPassword(String password) {
        // 使用MD5加密 + 简单盐值
        return DigestUtils.md5DigestAsHex((password + "JENS_SALT").getBytes(StandardCharsets.UTF_8));
    }
    
    /**
     * 验证密码
     * 
     * @param inputPassword 输入的密码
     * @param storedPassword 存储的密码
     * @return 密码是否匹配
     */
    private boolean verifyPassword(String inputPassword, String storedPassword) {
        // 尝试新密码格式
        String encryptedInputPassword = encryptPassword(inputPassword);
        if (encryptedInputPassword.equals(storedPassword)) {
            return true;
        }
        
        // 尝试旧密码格式 (项目名变更前的加密方式)
        String oldEncryptedPassword = DigestUtils.md5DigestAsHex((inputPassword + "JDWA_SALT").getBytes(StandardCharsets.UTF_8));
        return oldEncryptedPassword.equals(storedPassword);
    }
} 