package com.jens.green.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.jens.green.constants.JENSConstants;
import com.jens.green.entity.JENSSensorConfig;
import com.jens.green.exception.JENSServiceException;
import com.jens.green.mapper.JENSSensorConfigMapper;
import com.jens.green.service.JENSSensorConfigService;
import com.jens.green.service.JENSUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 传感器配置服务实现类
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@Service
public class JENSSensorConfigServiceImpl extends JENSBaseServiceImpl<JENSSensorConfigMapper, JENSSensorConfig> implements JENSSensorConfigService {

    @Autowired
    private JENSUserService userService;

    @Override
    public List<JENSSensorConfig> getConfigsByUserId(Long userId) {
        // 验证用户是否存在
        if (userService.getById(userId) == null) {
            throw new JENSServiceException("用户不存在");
        }

        // 查询用户的所有传感器配置
        LambdaQueryWrapper<JENSSensorConfig> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(JENSSensorConfig::getUserId, userId);
        return list(queryWrapper);
    }

    @Override
    public JENSSensorConfig getConfigByUserIdAndType(Long userId, Integer sensorType) {
        // 验证用户是否存在
        if (userService.getById(userId) == null) {
            throw new JENSServiceException("用户不存在");
        }

        // 改为使用XML自定义查询
        return baseMapper.selectByUserIdAndType(userId, sensorType);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean saveConfig(JENSSensorConfig config) {
        // 验证用户是否存在
        if (userService.getById(config.getUserId()) == null) {
            throw new JENSServiceException("用户不存在");
        }

        // 设置创建/更新时间
        LocalDateTime now = LocalDateTime.now();
        
        // 查询是否已存在该用户的该活动类型传感器配置
        LambdaQueryWrapper<JENSSensorConfig> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(JENSSensorConfig::getUserId, config.getUserId())
                .eq(JENSSensorConfig::getActivityType, config.getActivityType());
        JENSSensorConfig existConfig = getOne(queryWrapper);

        if (existConfig != null) {
            // 更新已有配置
            config.setId(existConfig.getId());
            config.setUpdateTime(now);
            return updateById(config);
        } else {
            // 新增配置
            config.setCreateTime(now);
            config.setUpdateTime(now);
            // 如果未设置状态，默认启用
            if (config.getEnabled() == null) {
                config.setEnabled(JENSConstants.CommonStatus.ENABLED);
            }
            return save(config);
        }
    }

    @Override
    public boolean updateStatus(Long configId, Integer status) {
        // 验证配置是否存在
        JENSSensorConfig config = getById(configId);
        if (config == null) {
            throw new JENSServiceException("传感器配置不存在");
        }

        // 更新状态
        config.setEnabled(status);
        config.setUpdateTime(LocalDateTime.now());
        return updateById(config);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean batchUpdateStatus(Long userId, Integer status) {
        // 验证用户是否存在
        if (userService.getById(userId) == null) {
            throw new JENSServiceException("用户不存在");
        }

        // 批量更新状态
        LambdaUpdateWrapper<JENSSensorConfig> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(JENSSensorConfig::getUserId, userId)
                .set(JENSSensorConfig::getEnabled, status)
                .set(JENSSensorConfig::getUpdateTime, LocalDateTime.now());
        return update(updateWrapper);
    }
} 