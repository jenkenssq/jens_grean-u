package com.jens.green.entity;

import lombok.Data;

/**
 * 传感器配置实体类
 * 
 * @author JENKENSSQ(JENS)
 */
@Data
public class SensorConfig {
    
    /**
     * 配置ID
     */
    private Long id;
    
    /**
     * 活动类型
     */
    private String activityType;
    
    /**
     * 最小心率
     */
    private int heartRateMin;
    
    /**
     * 最大心率
     */
    private int heartRateMax;
    
    /**
     * 最小速度(米/秒)
     */
    private double speedMin;
    
    /**
     * 最大速度(米/秒)
     */
    private double speedMax;
    
    /**
     * 步频(步/秒)
     */
    private double stepFrequency;
    
    /**
     * 描述
     */
    private String description;
} 