package com.jens.green.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jens.green.entity.JENSCarbonFactor;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import java.util.List;

/**
 * 碳因子Mapper接口
 *
 * @author JENKENSSQ(JENS)
 */
@Mapper
public interface JENSCarbonFactorMapper extends BaseMapper<JENSCarbonFactor> {
    
    /**
     * 根据活动类型查询碳减排因子列表
     * @param activityType 活动类型
     * @return 碳减排因子列表
     */
    List<JENSCarbonFactor> selectByActivityType(@Param("activityType") String activityType);
    
    /**
     * 查询所有启用的碳减排因子
     * @return 碳减排因子列表
     */
    List<JENSCarbonFactor> selectAllEnabled();
    
    /**
     * 检查表是否存在
     * @return 表存在返回1
     */
    @Select("SELECT 1 FROM jens_carbon_factor LIMIT 1")
    Integer checkTableExists();
} 