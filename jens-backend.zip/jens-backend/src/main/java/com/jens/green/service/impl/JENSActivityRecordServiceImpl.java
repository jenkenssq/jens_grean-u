package com.jens.green.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;
import com.jens.green.constants.JENSConstants;
import com.jens.green.entity.JENSActivityRecord;
import com.jens.green.entity.JENSCarbonFactor;
import com.jens.green.entity.JENSTrackPoint;
import com.jens.green.exception.JENSServiceException;
import com.jens.green.mapper.JENSActivityRecordMapper;
import com.jens.green.service.JENSActivityRecordService;
import com.jens.green.service.JENSCarbonFactorService;
import com.jens.green.service.JENSTrackPointService;
import com.jens.green.service.JENSUserService;
import com.jens.green.utils.JENSCarbonCalculator;
import com.jens.green.utils.JENSSensorDataGenerator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 活动记录服务实现类
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@Service
public class JENSActivityRecordServiceImpl extends JENSBaseServiceImpl<JENSActivityRecordMapper, JENSActivityRecord> implements JENSActivityRecordService {

    @Autowired
    private JENSTrackPointService trackPointService;
    
    @Autowired
    private JENSUserService userService;
    
    @Autowired
    private JENSCarbonFactorService carbonFactorService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long startActivity(Long userId, String activityType, BigDecimal latitude, BigDecimal longitude) {
        if (userService.getById(userId) == null) {
            throw new JENSServiceException("用户不存在");
        }
        
        // 查询用户是否有未结束的活动
        LambdaQueryWrapper<JENSActivityRecord> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(JENSActivityRecord::getUserId, userId)
                .isNull(JENSActivityRecord::getEndTime);
        
        JENSActivityRecord existingRecord = getOne(queryWrapper);
        if (existingRecord != null) {
            throw new JENSServiceException("您有未结束的活动，请先结束当前活动");
        }
        
        JENSActivityRecord record = new JENSActivityRecord();
        record.setUserId(userId);
        record.setActivityType(activityType);
        record.setStartTime(LocalDateTime.now());
        record.setStatus(JENSConstants.RecordStatus.IN_PROGRESS);
        record.setCreateTime(LocalDateTime.now());
        record.setUpdateTime(LocalDateTime.now());
        
        save(record);
        
        // 创建起点轨迹
        JENSTrackPoint startPoint = new JENSTrackPoint();
        startPoint.setRecordId(record.getId());
        startPoint.setLatitude(latitude);
        startPoint.setLongitude(longitude);
        startPoint.setAltitude(BigDecimal.ZERO); // 初始高度设为0
        startPoint.setHeartRate(70); // 初始心率设为70
        startPoint.setSpeed(BigDecimal.ZERO); // 初始速度设为0
        startPoint.setTimestamp(record.getStartTime());
        startPoint.setCreateTime(LocalDateTime.now());
        
        trackPointService.save(startPoint);
        
        return record.getId();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean endActivity(Long recordId, List<JENSTrackPoint> trackPoints) {
        JENSActivityRecord record = getById(recordId);
        if (record == null) {
            throw new JENSServiceException("活动记录不存在");
        }
        
        if (record.getEndTime() != null) {
            throw new JENSServiceException("该活动已结束");
        }
        
        // 保存轨迹点
        if (trackPoints != null && !trackPoints.isEmpty()) {
            for (JENSTrackPoint trackPoint : trackPoints) {
                trackPoint.setRecordId(recordId);
                trackPoint.setCreateTime(LocalDateTime.now());
            }
            trackPointService.saveBatch(trackPoints);
        }
        
        // 获取所有轨迹点并计算相关数据
        List<JENSTrackPoint> allTrackPoints = trackPointService.getTrackPointsByRecordId(recordId);
        if (allTrackPoints.isEmpty()) {
            throw new JENSServiceException("无有效轨迹数据");
        }
        
        // 计算持续时间（秒）
        LocalDateTime endTime = LocalDateTime.now();
        record.setEndTime(endTime);
        int durationInSeconds = (int) Duration.between(record.getStartTime(), endTime).getSeconds();
        record.setDuration(durationInSeconds);
        
        // 计算距离（米）
        double distanceInMeters = JENSSensorDataGenerator.calculateTotalDistance(allTrackPoints);
        record.setDistance(BigDecimal.valueOf(distanceInMeters));
        
        // 计算步数（假设步长约0.8米）
        int steps = (int) (distanceInMeters / 0.8);
        record.setSteps(steps);
        
        // 计算卡路里（假设每公里消耗60千卡）
        BigDecimal calories = BigDecimal.valueOf(distanceInMeters / 1000 * 60);
        record.setCalories(calories);
        
        // 计算碳减排量和积分
        Map<String, Object> carbonAndPoints = calculateCarbonAndPoints(record.getActivityType(), record.getDistance());
        BigDecimal carbonReduced = (BigDecimal) carbonAndPoints.get("carbonReduced");
        Integer pointsEarned = (Integer) carbonAndPoints.get("pointsEarned");
        
        record.setCarbonReduced(carbonReduced);
        record.setPointsEarned(pointsEarned);
        record.setStatus(JENSConstants.RecordStatus.COMPLETED);
        record.setUpdateTime(LocalDateTime.now());
        
        // 更新记录
        boolean updateResult = updateById(record);
        
        // 更新用户积分
        if (updateResult) {
            userService.updateUserPoints(record.getUserId(), carbonReduced, pointsEarned);
        }
        
        return updateResult;
    }

    @Override
    public JENSPageResult<JENSActivityRecord> getUserActivityRecords(Long userId, String activityType, JENSPageRequest pageRequest) {
        // 直接使用普通QueryWrapper
        QueryWrapper<JENSActivityRecord> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId);
        
        if (activityType != null) {
            queryWrapper.eq("activity_type", activityType);
        }
        
        queryWrapper.eq("status", JENSConstants.RecordStatus.COMPLETED);
        queryWrapper.orderByDesc("start_time");
        
        // 调用基类的分页方法
        return page(pageRequest, queryWrapper);
    }

    @Override
    public JENSActivityRecord getActivityDetail(Long recordId) {
        return getById(recordId);
    }

    @Override
    public Map<String, Object> calculateStatistics(Long userId) {
        LambdaQueryWrapper<JENSActivityRecord> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(JENSActivityRecord::getUserId, userId)
                .eq(JENSActivityRecord::getStatus, JENSConstants.RecordStatus.COMPLETED);
        
        List<JENSActivityRecord> records = list(queryWrapper);
        
        // 初始化统计结果
        int totalActivities = records.size();
        BigDecimal totalDistance = BigDecimal.ZERO;
        BigDecimal totalCarbonReduced = BigDecimal.ZERO;
        int totalPointsEarned = 0;
        int totalSteps = 0;
        BigDecimal totalCalories = BigDecimal.ZERO;
        int totalDuration = 0;
        
        // 各类型活动次数
        Map<String, Integer> activityTypeCount = new HashMap<>();
        
        for (JENSActivityRecord record : records) {
            if (record.getDistance() != null) totalDistance = totalDistance.add(record.getDistance());
            if (record.getCarbonReduced() != null) totalCarbonReduced = totalCarbonReduced.add(record.getCarbonReduced());
            if (record.getPointsEarned() != null) totalPointsEarned += record.getPointsEarned();
            if (record.getSteps() != null) totalSteps += record.getSteps();
            if (record.getCalories() != null) totalCalories = totalCalories.add(record.getCalories());
            if (record.getDuration() != null) totalDuration += record.getDuration();
            
            // 统计各类型活动次数
            String type = record.getActivityType();
            activityTypeCount.put(type, activityTypeCount.getOrDefault(type, 0) + 1);
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("totalActivities", totalActivities);
        result.put("totalDistance", totalDistance);
        result.put("totalCarbonReduced", totalCarbonReduced);
        result.put("totalPointsEarned", totalPointsEarned);
        result.put("totalSteps", totalSteps);
        result.put("totalCalories", totalCalories);
        result.put("totalDuration", totalDuration);
        result.put("activityTypeCount", activityTypeCount);
        
        return result;
    }

    @Override
    public Map<String, Object> calculateCarbonAndPoints(String activityType, BigDecimal distance) {
        // 查询碳减排因子
        JENSCarbonFactor carbonFactor = carbonFactorService.getByActivityType(activityType);
        if (carbonFactor == null) {
            throw new JENSServiceException("未找到对应活动类型的碳减排因子");
        }
        
        // 计算碳减排量（公式：距离(km) * 碳减排因子）
        BigDecimal distanceInKm = distance.divide(BigDecimal.valueOf(1000), 2, BigDecimal.ROUND_HALF_UP);
        BigDecimal carbonReduced = distanceInKm.multiply(carbonFactor.getFactorValue());
        
        // 计算积分（使用工具类）
        int pointsEarned = JENSCarbonCalculator.calculatePoints(carbonReduced);
        
        Map<String, Object> result = new HashMap<>();
        result.put("carbonReduced", carbonReduced);
        result.put("pointsEarned", pointsEarned);
        
        return result;
    }

    @Override
    public Map<String, Object> getUserActivityStatistics(Long userId, String timeRange) {
        if (userId == null) {
            throw new JENSServiceException("用户ID不能为空");
        }
        
        LocalDateTime startTime = null;
        LocalDateTime endTime = LocalDateTime.now();
        
        // 根据时间范围设置开始时间
        LocalDate today = LocalDate.now();
        switch (timeRange) {
            case "day":
                startTime = today.atStartOfDay();
                break;
            case "week":
                startTime = today.minusDays(today.getDayOfWeek().getValue() - 1).atStartOfDay();
                break;
            case "month":
                startTime = today.withDayOfMonth(1).atStartOfDay();
                break;
            case "year":
                startTime = today.withDayOfYear(1).atStartOfDay();
                break;
            default:
                throw new JENSServiceException("不支持的时间范围: " + timeRange);
        }
        
        // 查询指定时间范围内的活动记录
        LambdaQueryWrapper<JENSActivityRecord> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(JENSActivityRecord::getUserId, userId)
                .eq(JENSActivityRecord::getStatus, JENSConstants.RecordStatus.COMPLETED)
                .ge(JENSActivityRecord::getStartTime, startTime)
                .le(JENSActivityRecord::getEndTime, endTime)
                .orderByAsc(JENSActivityRecord::getStartTime);
        
        List<JENSActivityRecord> records = list(queryWrapper);
        
        // 初始化统计结果
        Map<String, Object> result = new HashMap<>();
        
        // 基本统计数据
        int totalActivities = records.size();
        BigDecimal totalDistance = BigDecimal.ZERO;
        BigDecimal totalCarbonReduced = BigDecimal.ZERO;
        int totalPointsEarned = 0;
        int totalSteps = 0;
        BigDecimal totalCalories = BigDecimal.ZERO;
        int totalDuration = 0;
        
        // 各类型活动次数
        Map<String, Integer> activityTypeCount = new HashMap<>();
        
        // 日期分组数据（用于图表展示）
        Map<String, BigDecimal> dailyDistance = new HashMap<>();
        Map<String, BigDecimal> dailyCarbon = new HashMap<>();
        Map<String, Integer> dailyPoints = new HashMap<>();
        
        for (JENSActivityRecord record : records) {
            if (record.getDistance() != null) totalDistance = totalDistance.add(record.getDistance());
            if (record.getCarbonReduced() != null) totalCarbonReduced = totalCarbonReduced.add(record.getCarbonReduced());
            if (record.getPointsEarned() != null) totalPointsEarned += record.getPointsEarned();
            if (record.getSteps() != null) totalSteps += record.getSteps();
            if (record.getCalories() != null) totalCalories = totalCalories.add(record.getCalories());
            if (record.getDuration() != null) totalDuration += record.getDuration();
            
            // 统计各类型活动次数
            String type = record.getActivityType();
            activityTypeCount.put(type, activityTypeCount.getOrDefault(type, 0) + 1);
            
            // 按日期分组统计（使用日期作为key）
            String dateKey = record.getStartTime().toLocalDate().toString();
            
            // 累加每日距离
            BigDecimal distance = record.getDistance() != null ? record.getDistance() : BigDecimal.ZERO;
            dailyDistance.put(dateKey, dailyDistance.getOrDefault(dateKey, BigDecimal.ZERO).add(distance));
            
            // 累加每日碳减排
            BigDecimal carbon = record.getCarbonReduced() != null ? record.getCarbonReduced() : BigDecimal.ZERO;
            dailyCarbon.put(dateKey, dailyCarbon.getOrDefault(dateKey, BigDecimal.ZERO).add(carbon));
            
            // 累加每日积分
            int points = record.getPointsEarned() != null ? record.getPointsEarned() : 0;
            dailyPoints.put(dateKey, dailyPoints.getOrDefault(dateKey, 0) + points);
        }
        
        // 组装返回结果
        result.put("totalActivities", totalActivities);
        result.put("totalDistance", totalDistance);
        result.put("totalCarbonReduced", totalCarbonReduced);
        result.put("totalPointsEarned", totalPointsEarned);
        result.put("totalSteps", totalSteps);
        result.put("totalCalories", totalCalories);
        result.put("totalDuration", totalDuration);
        result.put("activityTypeCount", activityTypeCount);
        result.put("dailyDistance", dailyDistance);
        result.put("dailyCarbon", dailyCarbon);
        result.put("dailyPoints", dailyPoints);
        result.put("timeRange", timeRange);
        
        return result;
    }
} 