package com.jens.green.service;

import com.jens.green.entity.JENSSensorConfig;

import java.util.List;

/**
 * 传感器配置服务接口
 *
 * @author JENKENSSQ(JENS)
 */
public interface JENSSensorConfigService extends JENSBaseService<JENSSensorConfig> {

    /**
     * 根据用户ID获取传感器配置
     *
     * @param userId 用户ID
     * @return 传感器配置列表
     */
    List<JENSSensorConfig> getConfigsByUserId(Long userId);

    /**
     * 根据用户ID和传感器类型获取传感器配置
     *
     * @param userId 用户ID
     * @param sensorType 传感器类型
     * @return 传感器配置
     */
    JENSSensorConfig getConfigByUserIdAndType(Long userId, Integer sensorType);

    /**
     * 保存传感器配置
     *
     * @param config 传感器配置
     * @return 是否成功
     */
    boolean saveConfig(JENSSensorConfig config);

    /**
     * 更新传感器状态
     *
     * @param configId 配置ID
     * @param status 状态
     * @return 是否成功
     */
    boolean updateStatus(Long configId, Integer status);

    /**
     * 批量更新传感器状态
     *
     * @param userId 用户ID
     * @param status 状态
     * @return 是否成功
     */
    boolean batchUpdateStatus(Long userId, Integer status);
} 