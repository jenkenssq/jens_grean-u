package com.jens.green.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;
import com.jens.green.constants.JENSConstants;
import com.jens.green.entity.JENSAchievement;
import com.jens.green.exception.JENSServiceException;
import com.jens.green.mapper.JENSAchievementMapper;
import com.jens.green.service.JENSAchievementService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 成就服务实现类
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@Service
public class JENSAchievementServiceImpl extends JENSBaseServiceImpl<JENSAchievementMapper, JENSAchievement> implements JENSAchievementService {

    @Override
    public List<JENSAchievement> getAllEnabledAchievements() {
        // 查询所有启用状态的成就
        QueryWrapper<JENSAchievement> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("status", JENSConstants.CommonStatus.ENABLED)
                .orderByAsc("type")
                .orderByAsc("condition_value");
        return list(queryWrapper);
    }

    @Override
    public List<JENSAchievement> getAchievementsByType(String achievementType) {
        // 查询指定类型的成就
        QueryWrapper<JENSAchievement> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("type", achievementType)
                .eq("status", JENSConstants.CommonStatus.ENABLED)
                .orderByAsc("condition_value");
        return list(queryWrapper);
    }

    @Override
    public JENSPageResult<JENSAchievement> getAchievementList(String achievementType, JENSPageRequest pageRequest) {
        // 构建查询条件
        QueryWrapper<JENSAchievement> queryWrapper = new QueryWrapper<>();
        
        if (achievementType != null && !achievementType.isEmpty()) {
            queryWrapper.eq("type", achievementType);
        }
        
        // 设置排序
        if (pageRequest.getOrderField() != null && !pageRequest.getOrderField().isEmpty()) {
            String orderField = pageRequest.getOrderField();
            if ("achievementType".equals(orderField)) {
                orderField = "type";
            } else if ("difficultyLevel".equals(orderField)) {
                orderField = "condition_value";
            }
            queryWrapper.orderBy(true, pageRequest.getIsAsc(), orderField);
        } else {
            queryWrapper.orderByAsc("type", "condition_value");
        }
        
        return page(pageRequest, queryWrapper);
    }

    @Override
    public JENSAchievement getAchievementDetail(Long achievementId) {
        JENSAchievement achievement = getById(achievementId);
        if (achievement == null) {
            throw new JENSServiceException("成就不存在");
        }
        return achievement;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean createAchievement(JENSAchievement achievement) {
        // 设置创建和更新时间
        LocalDateTime now = LocalDateTime.now();
        achievement.setCreateTime(now);
        achievement.setUpdateTime(now);
        
        // 如果未设置状态，默认为启用
        if (achievement.getStatus() == null) {
            achievement.setStatus(JENSConstants.CommonStatus.ENABLED);
        }
        
        return save(achievement);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateAchievement(JENSAchievement achievement) {
        // 验证成就是否存在
        if (getById(achievement.getId()) == null) {
            throw new JENSServiceException("成就不存在");
        }
        
        // 设置更新时间
        achievement.setUpdateTime(LocalDateTime.now());
        
        return updateById(achievement);
    }

    @Override
    public boolean updateStatus(Long achievementId, Integer status) {
        // 验证成就是否存在
        JENSAchievement achievement = getById(achievementId);
        if (achievement == null) {
            throw new JENSServiceException("成就不存在");
        }
        
        // 更新状态
        achievement.setStatus(status);
        achievement.setUpdateTime(LocalDateTime.now());
        
        return updateById(achievement);
    }
} 