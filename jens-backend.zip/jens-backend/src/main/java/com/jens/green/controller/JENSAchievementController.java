package com.jens.green.controller;

import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;
import com.jens.green.common.JENSResult;
import com.jens.green.entity.JENSAchievement;
import com.jens.green.entity.JENSUserAchievement;
import com.jens.green.service.JENSAchievementService;
import com.jens.green.service.JENSUserAchievementService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 成就控制器
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@RestController
@RequestMapping("/api/achievement")
public class JENSAchievementController extends JENSBaseController {

    @Autowired
    private JENSAchievementService achievementService;

    @Autowired
    private JENSUserAchievementService userAchievementService;

    /**
     * 获取成就列表
     *
     * @param achievementType 成就类型（可选）
     * @param page     页码
     * @param pageSize 每页大小
     * @return 成就列表
     */
    @GetMapping("/list")
    public JENSResult<Object> getAchievements(
            @RequestParam(required = false) String achievementType,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "20") Integer pageSize
    ) {
        JENSPageRequest pageRequest = new JENSPageRequest();
        pageRequest.setCurrent(page);
        pageRequest.setSize(pageSize);
        
        JENSPageResult<JENSAchievement> achievements = achievementService.getAchievementList(achievementType, pageRequest);
        
        Map<String, Object> result = new HashMap<>();
        result.put("total", achievements.getTotal());
        result.put("pages", achievements.getPages());
        result.put("current", achievements.getCurrent());
        result.put("records", achievements.getRecords());
        
        return JENSResult.success("获取成功", result);
    }

    /**
     * 获取用户成就列表
     *
     * @return 用户成就列表
     */
    @GetMapping("/user")
    public JENSResult<Object> getUserAchievements() {
        Long userId = getCurrentUserId();
        
        try {
            // 获取所有可用的成就
            List<JENSAchievement> allAchievements = achievementService.getAllEnabledAchievements();
            
            // 获取用户已获得的成就
            List<JENSUserAchievement> userAchievements = userAchievementService.getUserAchievements(userId, true);
            
            // 用户已获得成就ID集合
            List<Long> userAchievementIds = userAchievements.stream()
                    .map(JENSUserAchievement::getAchievementId)
                    .collect(Collectors.toList());
            
            // 构建前端展示数据
            List<Map<String, Object>> result = allAchievements.stream().map(achievement -> {
                Map<String, Object> map = new HashMap<>();
                map.put("id", achievement.getId());
                map.put("name", achievement.getName());
                map.put("description", achievement.getDescription());
                map.put("icon", achievement.getIconUrl());
                map.put("pointsReward", achievement.getRewardPoints());
                map.put("difficultyLevel", achievement.getDifficultyLevel());
                
                // 是否已获得
                boolean isAchieved = userAchievementIds.contains(achievement.getId());
                map.put("isAchieved", isAchieved);
                
                // 已获得的成就，补充获取时间
                if (isAchieved) {
                    JENSUserAchievement userAchievement = userAchievements.stream()
                            .filter(ua -> ua.getAchievementId().equals(achievement.getId()))
                            .findFirst().orElse(null);
                    
                    if (userAchievement != null) {
                        map.put("achievedTime", userAchievement.getAchieveTime());
                    }
                }
                
                return map;
            }).collect(Collectors.toList());
            
            return JENSResult.success("获取成功", result);
            
        } catch (Exception e) {
            log.error("获取用户成就异常", e);
            return JENSResult.serverError("获取失败：" + e.getMessage());
        }
    }
    
    /**
     * 获取成就详情
     *
     * @param achievementId 成就ID
     * @return 成就详情
     */
    @GetMapping("/{achievementId}")
    public JENSResult<Object> getAchievementDetail(@PathVariable Long achievementId) {
        JENSAchievement achievement = achievementService.getAchievementDetail(achievementId);
        if (achievement == null) {
            return JENSResult.notFound("成就不存在");
        }
        
        // 查询当前用户是否已获得此成就
        Long userId = getCurrentUserId();
        JENSUserAchievement userAchievement = userAchievementService.getUserAchievementDetail(userId, achievementId);
        
        Map<String, Object> result = new HashMap<>();
        result.put("achievement", achievement);
        result.put("isAchieved", userAchievement != null);
        if (userAchievement != null) {
            result.put("achievedTime", userAchievement.getAchieveTime());
        }
        
        return JENSResult.success("获取成功", result);
    }

    /**
     * 获取用户成就统计数据
     *
     * @return 统计数据
     */
    @GetMapping("/stats")
    public JENSResult<Object> getAchievementStats() {
        Long userId = getCurrentUserId();
        
        try {
            Map<String, Object> stats = userAchievementService.getUserAchievementStatistics(userId);
            return JENSResult.success("获取成功", stats);
        } catch (Exception e) {
            log.error("获取成就统计数据异常", e);
            return JENSResult.serverError("获取统计数据失败：" + e.getMessage());
        }
    }
} 