package com.jens.green.controller;

import com.jens.green.common.JENSResult;
import com.jens.green.model.request.JENSLoginRequest;
import com.jens.green.model.request.JENSRegisterRequest;
import com.jens.green.model.response.JENSAuthResponse;
import com.jens.green.security.JENSUserDetails;
import com.jens.green.service.JENSUserService;
import com.jens.green.util.JENSJwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 认证控制器
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class JENSAuthController {

    private final AuthenticationManager authenticationManager;
    private final JENSJwtUtil jwtUtil;
    private final JENSUserService userService;

    @Value("${jwt.expiration:86400000}")
    private long jwtExpiration;

    /**
     * 用户登录
     *
     * @param loginRequest 登录请求
     * @return 认证结果
     */
    @PostMapping("/login")
    public JENSResult<JENSAuthResponse> login(@Validated @RequestBody JENSLoginRequest loginRequest) {
        try {
            // 验证用户名和密码
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            loginRequest.getUsername(),
                            loginRequest.getPassword()
                    )
            );

            // 认证通过，设置Authentication到上下文
            SecurityContextHolder.getContext().setAuthentication(authentication);

            // 获取用户详情
            JENSUserDetails userDetails = (JENSUserDetails) authentication.getPrincipal();

            // 生成JWT令牌
            String jwt = jwtUtil.generateToken(userDetails);

            // 更新用户最后登录时间
            userService.updateLastLoginTime(userDetails.getId());

            // 构造响应
            List<String> roles = userDetails.getAuthorities().stream()
                    .map(GrantedAuthority::getAuthority)
                    .collect(Collectors.toList());

            JENSAuthResponse authResponse = JENSAuthResponse.builder()
                    .token(jwt)
                    .tokenType(jwtUtil.getPrefix().trim())
                    .expiresIn(jwtExpiration)
                    .userId(userDetails.getId())
                    .username(userDetails.getUsername())
                    .nickname(userDetails.getNickname())
                    .email(userDetails.getEmail())
                    .mobile(userDetails.getMobile())
                    .avatar(userDetails.getAvatar())
                    .roles(roles)
                    .permissions(userDetails.getPermissions())
                    .lastLoginTime(LocalDateTime.now())
                    .build();

            return JENSResult.success("登录成功", authResponse);
        } catch (Exception e) {
            log.error("登录失败: {}", e.getMessage());
            return JENSResult.error(401, "用户名或密码错误");
        }
    }

    /**
     * 用户注册
     *
     * @param registerRequest 注册请求
     * @return 注册结果
     */
    @PostMapping("/register")
    public JENSResult<Object> register(@Validated @RequestBody JENSRegisterRequest registerRequest) {
        // 检查两次密码输入是否一致
        if (!registerRequest.getPassword().equals(registerRequest.getConfirmPassword())) {
            return JENSResult.paramError("两次密码输入不一致");
        }

        // 检查用户名是否已存在
        if (userService.existsByUsername(registerRequest.getUsername())) {
            return JENSResult.paramError("用户名已被使用");
        }

        // 检查邮箱是否已存在
        if (userService.existsByEmail(registerRequest.getEmail())) {
            return JENSResult.paramError("邮箱已被使用");
        }

        // 注册用户
        userService.register(registerRequest);

        return JENSResult.success("注册成功");
    }

    /**
     * 获取当前用户信息
     *
     * @return 用户信息
     */
    @PostMapping("/info")
    public JENSResult<Object> getUserInfo() {
        return JENSResult.success("获取成功", SecurityContextHolder.getContext().getAuthentication().getPrincipal());
    }

    /**
     * 注销登录
     *
     * @return 注销结果
     */
    @PostMapping("/logout")
    public JENSResult<Object> logout() {
        SecurityContextHolder.clearContext();
        return JENSResult.success("注销成功");
    }
} 