package com.jens.green.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 传感器配置实体类
 * 
 * @author JENKENSSQ(JENS)
 */
@Data
@TableName("jens_sensor_config")
public class JENSSensorConfig {
    
    /**
     * 配置ID
     */
    private Long id;
    
    /**
     * 用户ID
     */
    private Long userId;
    
    /**
     * 传感器类型：1-心率，2-加速度计，3-GPS
     * 注：该字段在数据库中不存在
     */
    @TableField(exist = false)
    private Integer sensorType;
    
    /**
     * 采样频率（单位：秒）
     * 注：该字段在数据库中不存在
     */
    @TableField(exist = false)
    private Integer samplingRate;
    
    /**
     * 数据精度
     * 注：该字段在数据库中不存在
     */
    @TableField(exist = false)
    private Integer precision;
    
    /**
     * 是否启用：0-禁用，1-启用
     */
    private Integer enabled;
    
    /**
     * 传感器硬件ID
     * 注：该字段在数据库中不存在
     */
    @TableField(exist = false)
    private String hardwareId;
    
    /**
     * 额外配置（JSON格式）
     * 注：该字段在数据库中不存在
     */
    @TableField(exist = false)
    private String extraConfig;
    
    /**
     * 活动类型
     */
    private String activityType;
    
    /**
     * 最小心率
     */
    private int heartRateMin;
    
    /**
     * 最大心率
     */
    private int heartRateMax;
    
    /**
     * 最小速度(米/秒)
     */
    private double speedMin;
    
    /**
     * 最大速度(米/秒)
     */
    private double speedMax;
    
    /**
     * 步频(步/秒)
     */
    private double stepFrequency;
    
    /**
     * 描述
     * 注：该字段在数据库中不存在
     */
    @TableField(exist = false)
    private String description;
    
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
} 