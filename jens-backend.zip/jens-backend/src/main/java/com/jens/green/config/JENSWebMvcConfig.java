package com.jens.green.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import java.nio.file.Paths;

/**
 * Web MVC配置类
 * 处理静态资源映射等配置
 */
@Configuration
public class JENSWebMvcConfig implements WebMvcConfigurer {
    
    /**
     * 添加静态资源处理器
     * 配置各种静态资源的访问路径
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 获取项目运行目录
        String projectPath = System.getProperty("user.dir");
        String uploadsPath = Paths.get(projectPath, "src", "main", "resources", "static", "uploads").toString();
        String uploadsAvatarPath = Paths.get(projectPath, "src", "main", "resources", "static", "uploads", "avatar").toString();
        
        // 映射/images/**请求到classpath:/static/images/
        registry.addResourceHandler("/images/**")
                .addResourceLocations("classpath:/static/images/");
        
        // 映射/uploads/**请求到classpath:/static/uploads/以及绝对路径
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations("classpath:/static/uploads/")
                .addResourceLocations("file:" + uploadsPath + "/");
                
        // 映射/uploads/avatar/**请求到classpath:/static/uploads/avatar/以及绝对路径
        registry.addResourceHandler("/uploads/avatar/**")
                .addResourceLocations("classpath:/static/uploads/avatar/")
                .addResourceLocations("file:" + uploadsAvatarPath + "/");
                
        // 映射/assets/**请求到classpath:/static/assets/
        registry.addResourceHandler("/assets/**")
                .addResourceLocations("classpath:/static/assets/");
                
        // 映射/image/**请求到项目根目录下的image/目录
        registry.addResourceHandler("/image/**")
                .addResourceLocations("file:./image/")
                .addResourceLocations("classpath:/static/image/");
                
        // 静态资源映射
        registry.addResourceHandler("/static/**")
                .addResourceLocations("classpath:/static/");
    }
} 