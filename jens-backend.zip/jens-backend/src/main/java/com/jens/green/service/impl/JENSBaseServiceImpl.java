package com.jens.green.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;
import com.jens.green.service.JENSBaseService;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

/**
 * 基础Service实现类
 *
 * @author JENKENSSQ(JENS)
 */
public class JENSBaseServiceImpl<M extends BaseMapper<T>, T> extends ServiceImpl<M, T> implements JENSBaseService<T> {

    @Override
    public boolean save(T entity) {
        return super.save(entity);
    }

    @Override
    public boolean saveBatch(Collection<T> entityList) {
        return super.saveBatch(entityList);
    }

    @Override
    public boolean updateById(T entity) {
        return super.updateById(entity);
    }

    @Override
    public boolean removeById(Serializable id) {
        return super.removeById(id);
    }

    @Override
    public boolean removeByIds(List<? extends Serializable> idList) {
        return super.removeByIds(idList);
    }

    @Override
    public T getById(Serializable id) {
        return super.getById(id);
    }

    @Override
    public List<T> list() {
        return super.list();
    }

    @Override
    public List<T> list(QueryWrapper<T> queryWrapper) {
        return super.list(queryWrapper);
    }
    
    @Override
    public List<T> list(Object queryWrapper) {
        if (queryWrapper instanceof QueryWrapper) {
            return super.list((QueryWrapper<T>) queryWrapper);
        }
        return super.list();
    }
    
    @Override
    public T getOne(Object queryWrapper) {
        if (queryWrapper instanceof QueryWrapper) {
            return super.getOne((QueryWrapper<T>) queryWrapper);
        }
        return null;
    }
    
    @Override
    public boolean update(Object updateWrapper) {
        if (updateWrapper instanceof UpdateWrapper) {
            return super.update(null, (UpdateWrapper<T>) updateWrapper);
        }
        return false;
    }
    
    @Override
    public boolean update(T entity, Object updateWrapper) {
        if (updateWrapper instanceof UpdateWrapper) {
            return super.update(entity, (UpdateWrapper<T>) updateWrapper);
        }
        return false;
    }

    @Override
    public JENSPageResult<T> page(JENSPageRequest pageRequest) {
        Page<T> page = new Page<>(pageRequest.getCurrent(), pageRequest.getSize());
        if (pageRequest.getOrderField() != null && !pageRequest.getOrderField().isEmpty()) {
            page.addOrder(pageRequest.getIsAsc() 
                ? new com.baomidou.mybatisplus.core.metadata.OrderItem(pageRequest.getOrderField(), true) 
                : new com.baomidou.mybatisplus.core.metadata.OrderItem(pageRequest.getOrderField(), false));
        }
        
        Page<T> resultPage = super.page(page);
        return new JENSPageResult<>(pageRequest, resultPage.getTotal(), resultPage.getRecords());
    }

    @Override
    public JENSPageResult<T> page(JENSPageRequest pageRequest, Object queryWrapper) {
        Page<T> page = new Page<>(pageRequest.getCurrent(), pageRequest.getSize());
        if (pageRequest.getOrderField() != null && !pageRequest.getOrderField().isEmpty()) {
            page.addOrder(pageRequest.getIsAsc() 
                ? new com.baomidou.mybatisplus.core.metadata.OrderItem(pageRequest.getOrderField(), true) 
                : new com.baomidou.mybatisplus.core.metadata.OrderItem(pageRequest.getOrderField(), false));
        }
        
        if (queryWrapper instanceof QueryWrapper) {
            Page<T> resultPage = super.page(page, (QueryWrapper<T>) queryWrapper);
            return new JENSPageResult<>(pageRequest, resultPage.getTotal(), resultPage.getRecords());
        }
        
        Page<T> resultPage = super.page(page);
        return new JENSPageResult<>(pageRequest, resultPage.getTotal(), resultPage.getRecords());
    }
} 