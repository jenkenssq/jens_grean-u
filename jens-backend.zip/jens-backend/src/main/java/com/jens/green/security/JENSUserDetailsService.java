package com.jens.green.security;

import com.jens.green.entity.JENSUser;
import com.jens.green.service.JENSUserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 用户详情服务
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class JENSUserDetailsService implements UserDetailsService {

    private final JENSUserService userService;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // 根据用户名查询用户
        JENSUser user = userService.getUserByUsername(username);
        if (user == null) {
            log.error("用户不存在: {}", username);
            throw new UsernameNotFoundException("用户名或密码错误");
        }

        // 获取用户角色和权限
        List<String> roles = userService.getUserRoles(user.getId());
        List<String> permissions = userService.getUserPermissions(user.getId());

        // 构建用户详情
        return JENSUserDetails.builder()
                .id(user.getId())
                .username(user.getUsername())
                .password(user.getPassword())
                .nickname(user.getNickname())
                .email(user.getEmail())
                .mobile(user.getPhone())
                .avatar(user.getAvatar())
                .enabled(user.getStatus() == 1)
                .accountNonExpired(true)
                .credentialsNonExpired(true)
                .accountNonLocked(true)
                .roles(roles)
                .permissions(permissions)
                .build();
    }
} 