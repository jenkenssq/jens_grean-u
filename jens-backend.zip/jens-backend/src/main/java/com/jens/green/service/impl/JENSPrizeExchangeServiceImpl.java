package com.jens.green.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;
import com.jens.green.constants.JENSConstants;
import com.jens.green.entity.JENSPrize;
import com.jens.green.entity.JENSPrizeExchange;
import com.jens.green.entity.JENSUser;
import com.jens.green.exception.JENSServiceException;
import com.jens.green.mapper.JENSPrizeExchangeMapper;
import com.jens.green.service.JENSPointsRecordService;
import com.jens.green.service.JENSPrizeExchangeService;
import com.jens.green.service.JENSPrizeService;
import com.jens.green.service.JENSUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.Arrays;

/**
 * 奖品兑换服务实现类
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@Service
public class JENSPrizeExchangeServiceImpl extends JENSBaseServiceImpl<JENSPrizeExchangeMapper, JENSPrizeExchange> implements JENSPrizeExchangeService {

    @Autowired
    private JENSUserService userService;
    
    @Autowired
    private JENSPrizeService prizeService;
    
    @Autowired
    private JENSPointsRecordService pointsRecordService;
    
    // 兑换记录状态常量
    private static final int EXCHANGE_STATUS_PENDING = 0;    // 待处理
    private static final int EXCHANGE_STATUS_PROCESSING = 1; // 处理中
    private static final int EXCHANGE_STATUS_COMPLETED = 2;  // 已完成
    private static final int EXCHANGE_STATUS_CANCELLED = 3;  // 已取消

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long createExchange(Long userId, Long prizeId, Integer count, String address, String phone, String remark) {
        // 验证用户存在
        JENSUser user = userService.getById(userId);
        if (user == null) {
            throw new JENSServiceException("用户不存在");
        }
        
        // 验证奖品存在且有库存
        JENSPrize prize = prizeService.getById(prizeId);
        if (prize == null) {
            throw new JENSServiceException("奖品不存在");
        }
        
        // 检查奖品状态
        if (prize.getStatus() != JENSConstants.CommonStatus.ENABLED) {
            throw new JENSServiceException("奖品已下架");
        }
        
        // 检查库存
        if (!prizeService.checkStock(prizeId, count)) {
            throw new JENSServiceException("奖品库存不足");
        }
        
        // 计算所需积分
        int requiredPoints = prize.getPointsRequired() * count;
        
        // 检查用户积分是否足够
        if (!pointsRecordService.checkPointsEnough(userId, requiredPoints)) {
            throw new JENSServiceException("用户积分不足");
        }
        
        // 如果是实物奖品，验证地址和电话
        if (prize.getPrizeType() == JENSConstants.PrizeType.PHYSICAL && 
                (!StringUtils.hasText(address) || !StringUtils.hasText(phone))) {
            throw new JENSServiceException("实物奖品需要提供收货地址和联系电话");
        }
        
        // 创建兑换记录
        JENSPrizeExchange exchange = new JENSPrizeExchange();
        exchange.setUserId(userId);
        exchange.setPrizeId(prizeId);
        exchange.setPrizeName(prize.getName());
        exchange.setPrizeType(prize.getPrizeType());
        exchange.setPointsUsed(requiredPoints);
        exchange.setStatus(EXCHANGE_STATUS_PENDING);
        exchange.setExchangeTime(LocalDateTime.now());
        exchange.setRemark(remark);
        exchange.setCreateTime(LocalDateTime.now());
        
        // 保存兑换记录
        boolean saveResult = save(exchange);
        if (!saveResult) {
            throw new JENSServiceException("创建兑换记录失败");
        }
        
        // 扣减用户积分
        String description = "兑换" + prize.getName() + "，数量：" + count;
        boolean pointsResult = pointsRecordService.addPointsRecord(userId, -requiredPoints, 
                JENSConstants.PointsType.PRIZE_EXCHANGE, description, exchange.getId());
        if (!pointsResult) {
            throw new JENSServiceException("扣减积分失败");
        }
        
        // 扣减奖品库存
        boolean stockResult = prizeService.decreaseStock(prizeId, count);
        if (!stockResult) {
            throw new JENSServiceException("扣减库存失败");
        }
        
        // 虚拟奖品自动完成兑换
        if (prize.getPrizeType() == JENSConstants.PrizeType.VIRTUAL) {
            exchange.setStatus(EXCHANGE_STATUS_COMPLETED);
            exchange.setDeliveryTime(LocalDateTime.now());
            updateById(exchange);
        }
        
        return exchange.getId();
    }

    @Override
    public JENSPageResult<JENSPrizeExchange> getUserExchanges(Long userId, Integer status, JENSPageRequest pageRequest) {
        QueryWrapper<JENSPrizeExchange> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId);
        
        if (status != null) {
            queryWrapper.eq("status", status);
        }
        
        if (pageRequest.getOrderField() != null && !pageRequest.getOrderField().isEmpty()) {
            queryWrapper.orderBy(true, pageRequest.getIsAsc(), pageRequest.getOrderField());
        } else {
            // 默认按创建时间降序排序
            queryWrapper.orderByDesc("create_time");
        }
        
        return page(pageRequest, queryWrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateExchangeStatus(Long exchangeId, Integer status, String operateNote) {
        // 获取兑换记录
        JENSPrizeExchange exchange = getById(exchangeId);
        if (exchange == null) {
            throw new JENSServiceException("兑换记录不存在");
        }
        
        // 验证状态变更是否合法
        if (!isValidStatusChange(exchange.getStatus(), status)) {
            throw new JENSServiceException("非法的状态变更");
        }
        
        // 更新状态
        exchange.setStatus(status);
        exchange.setRemark(exchange.getRemark() + "\n操作备注: " + operateNote);
        
        // 如果是完成状态，设置发放时间
        if (status == EXCHANGE_STATUS_COMPLETED) {
            exchange.setDeliveryTime(LocalDateTime.now());
        }
        
        // 如果是取消状态，退还积分
        if (status == EXCHANGE_STATUS_CANCELLED) {
            // 退还用户积分
            String description = "取消兑换" + exchange.getPrizeName() + "，退还积分";
            boolean pointsResult = pointsRecordService.addPointsRecord(exchange.getUserId(), exchange.getPointsUsed(), 
                    JENSConstants.PointsType.ADMIN_ADJUSTMENT, description, exchangeId);
            if (!pointsResult) {
                throw new JENSServiceException("退还积分失败");
            }
            
            // 恢复奖品库存
            JENSPrize prize = prizeService.getById(exchange.getPrizeId());
            if (prize != null) {
                prize.setStock(prize.getStock() + 1); // 默认兑换数量为1
                prizeService.updateById(prize);
            }
        }
        
        exchange.setUpdateTime(LocalDateTime.now());
        return updateById(exchange);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean cancelExchange(Long exchangeId, Long userId, String reason) {
        // 获取兑换记录
        JENSPrizeExchange exchange = getById(exchangeId);
        if (exchange == null) {
            throw new JENSServiceException("兑换记录不存在");
        }
        
        // 验证是否为用户自己的兑换记录
        if (!exchange.getUserId().equals(userId)) {
            throw new JENSServiceException("无权操作此兑换记录");
        }
        
        // 验证是否可以取消
        if (exchange.getStatus() != EXCHANGE_STATUS_PENDING) {
            throw new JENSServiceException("只有待处理的兑换才能取消");
        }
        
        // 设置取消原因
        String operateNote = "用户取消：" + reason;
        
        // 更新状态为已取消
        return updateExchangeStatus(exchangeId, EXCHANGE_STATUS_CANCELLED, operateNote);
    }
    
    /**
     * 验证状态变更是否合法
     *
     * @param oldStatus 旧状态
     * @param newStatus 新状态
     * @return 是否合法
     */
    private boolean isValidStatusChange(Integer oldStatus, Integer newStatus) {
        // 初始状态为待处理，可以变为处理中、已完成、已取消
        if (oldStatus == EXCHANGE_STATUS_PENDING) {
            return Arrays.asList(
                    EXCHANGE_STATUS_PROCESSING,
                    EXCHANGE_STATUS_COMPLETED,
                    EXCHANGE_STATUS_CANCELLED
            ).contains(newStatus);
        }
        
        // 处理中状态可以变为已完成、已取消
        if (oldStatus == EXCHANGE_STATUS_PROCESSING) {
            return Arrays.asList(
                    EXCHANGE_STATUS_COMPLETED,
                    EXCHANGE_STATUS_CANCELLED
            ).contains(newStatus);
        }
        
        // 其他状态不可变更
        return false;
    }
} 