package com.jens.green.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jens.green.entity.JENSPointsRecord;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 积分记录Mapper接口
 *
 * @author JENKENSSQ(JENS)
 */
@Mapper
public interface JENSPointsRecordMapper extends BaseMapper<JENSPointsRecord> {
    
    /**
     * 分页查询用户积分记录
     *
     * @param page      分页参数
     * @param userId    用户ID
     * @param pointsType 积分类型，null则查询全部
     * @return 分页结果
     */
    IPage<JENSPointsRecord> selectUserPointsRecords(Page<JENSPointsRecord> page, 
                                              @Param("userId") Long userId, 
                                              @Param("pointsType") Integer pointsType);
    
    /**
     * 查询用户最近一次积分记录
     *
     * @param userId 用户ID
     * @return 积分记录
     */
    JENSPointsRecord selectLatestRecord(@Param("userId") Long userId);
} 