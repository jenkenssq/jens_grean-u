package com.jens.green.config;

import com.jens.green.common.JENSResult;
import com.jens.green.security.JENSJwtAuthenticationFilter;
import com.jens.green.security.JENSUserDetailsService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;

/**
 * Spring Security 配置类
 *
 * @author JENKENSSQ(JENS)
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class JENSSecurityConfig {

    private final JENSUserDetailsService userDetailsService;
    private final JENSJwtAuthenticationFilter jwtAuthenticationFilter;
    private final ObjectMapper objectMapper;

    @Autowired
    private CorsFilter corsFilter;

    /**
     * 密码编码器
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * 处理异常响应
     */
    private void handleExceptionResponse(HttpServletResponse response, int status, String message) throws IOException {
        response.setStatus(status);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(objectMapper.writeValueAsString(JENSResult.error(status, message)));
    }

    /**
     * 安全过滤器链配置
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        // 禁用CSRF，因为我们使用JWT进行认证
        http.csrf().disable();
        
        // 使用CORS
        http.cors().configurationSource(corsConfigurationSource());

        // 添加CORS过滤器到Spring Security过滤器链中
        http.addFilterBefore(corsFilter, UsernamePasswordAuthenticationFilter.class);
        
        // 配置会话管理，使用无状态会话
        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
        
        // 设置异常处理
        http.exceptionHandling()
            // 未认证处理
            .authenticationEntryPoint((request, response, e) -> {
                handleExceptionResponse(response, 401, "未认证，请先登录");
            })
            // 权限不足处理
            .accessDeniedHandler((request, response, e) -> {
                handleExceptionResponse(response, 403, "权限不足，无法访问");
            });
        
        // 配置请求授权规则
        http.authorizeRequests()
            // 允许静态资源访问
            .antMatchers("/", "/favicon.ico", "/error").permitAll()
            // 允许Swagger相关资源访问
            .antMatchers("/doc.html", "/swagger-ui/**", "/swagger-resources/**", "/v3/api-docs/**", "/webjars/**").permitAll()
            // 允许认证相关接口访问
            .antMatchers("/api/user/login", "/api/user/register", "/api/user/info").permitAll()
            // 允许图片资源访问
            .antMatchers("/images/**", "/uploads/**", "/assets/images/**", "/static/images/**").permitAll()
            // 允许所有OPTIONS请求
            .antMatchers(HttpMethod.OPTIONS, "/**").permitAll()
            // 暂时允许所有请求，便于开发测试
            .antMatchers("/**").permitAll()
            // 其他请求需要认证
            .anyRequest().authenticated();
        
        // 添加JWT过滤器
        http.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);
        
        return http.build();
    }

    /**
     * CORS配置源
     */
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOriginPatterns(Arrays.asList("*"));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type", "X-Requested-With"));
        configuration.setAllowCredentials(false);
        configuration.setMaxAge(3600L);
        
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
    
    /**
     * 认证管理器
     */
    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http, 
                                                      PasswordEncoder passwordEncoder, 
                                                      JENSUserDetailsService userDetailsService) throws Exception {
        return http.getSharedObject(AuthenticationManagerBuilder.class)
                .userDetailsService(userDetailsService)
                .passwordEncoder(passwordEncoder)
                .and()
                .build();
    }
} 