package com.jens.green.controller;

import com.jens.green.common.JENSResult;
import com.jens.green.exception.JENSServiceException;
import com.jens.green.service.JENSUserService;
import com.jens.green.util.JENSSecurityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 控制器基类
 *
 * @author JENKENSSQ(JENS)
 */
public class JENSBaseController {

    protected final Logger logger = LoggerFactory.getLogger(getClass());
    
    @Autowired
    protected JENSUserService userService;

    /**
     * 获取当前登录用户ID
     * 从Spring Security上下文中获取用户名，再通过用户服务查询用户ID
     *
     * @return 用户ID
     */
    protected Long getCurrentUserId() {
        // 从Security上下文获取当前用户名
        String username = JENSSecurityUtils.getCurrentUsername();
        
        if (username == null) {
            logger.warn("未找到当前用户信息，可能未授权访问");
            return null;
        }
        
        // 通过用户名查询用户ID
        Long userId = userService.getUserIdByUsername(username);
        
        if (userId == null) {
            logger.warn("用户{}不存在", username);
            return null;
        }
        
        logger.debug("当前用户: {}, ID: {}", username, userId);
        return userId;
    }

    /**
     * 业务异常统一处理
     */
    @ExceptionHandler(JENSServiceException.class)
    @ResponseBody
    public JENSResult<Object> handleServiceException(JENSServiceException e) {
        logger.warn("业务异常: {}", e.getMessage());
        return JENSResult.error(e.getCode() != null ? e.getCode() : 500, e.getMessage());
    }

    /**
     * 系统异常统一处理
     */
    @ExceptionHandler(Exception.class)
    @ResponseBody
    public JENSResult<Object> handleException(Exception e) {
        logger.error("系统异常", e);
        return JENSResult.serverError("服务器内部错误");
    }
} 