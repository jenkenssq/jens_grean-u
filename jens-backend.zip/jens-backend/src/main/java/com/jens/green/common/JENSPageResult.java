package com.jens.green.common;

import lombok.Data;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

/**
 * 分页结果对象
 *
 * @author JENKENSSQ(JENS)
 */
@Data
public class JENSPageResult<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 当前页码
     */
    private Integer current;

    /**
     * 每页大小
     */
    private Integer size;

    /**
     * 总记录数
     */
    private Long total;

    /**
     * 总页数
     */
    private Long pages;

    /**
     * 是否有上一页
     */
    private Boolean hasPrevious;

    /**
     * 是否有下一页
     */
    private Boolean hasNext;

    /**
     * 分页数据
     */
    private List<T> records;

    /**
     * 构造分页结果对象
     *
     * @param current 当前页码
     * @param size    每页大小
     * @param total   总记录数
     * @param records 分页数据
     */
    public JENSPageResult(Integer current, Integer size, Long total, List<T> records) {
        this.current = current;
        this.size = size;
        this.total = total;
        this.records = records;
        this.pages = (total + size - 1) / size;
        this.hasPrevious = current > 1;
        this.hasNext = current < pages;
    }

    /**
     * 构造分页结果对象
     *
     * @param pageRequest 分页请求对象
     * @param total       总记录数
     * @param records     分页数据
     */
    public JENSPageResult(JENSPageRequest pageRequest, Long total, List<T> records) {
        this(pageRequest.getCurrent(), pageRequest.getSize(), total, records);
    }

    /**
     * 构造空的分页结果对象
     *
     * @param pageRequest 分页请求对象
     * @param <T>         数据类型
     * @return 空的分页结果对象
     */
    public static <T> JENSPageResult<T> empty(JENSPageRequest pageRequest) {
        return new JENSPageResult<>(pageRequest.getCurrent(), pageRequest.getSize(), 0L, Collections.emptyList());
    }

    /**
     * 构造函数
     */
    public JENSPageResult() {
        this.records = Collections.emptyList();
        this.total = 0L;
        this.pages = 0L;
        this.current = 1;
        this.size = 10;
    }

    /**
     * 构造函数
     *
     * @param records 数据列表
     * @param total 总记录数
     * @param pageRequest 分页请求
     */
    public JENSPageResult(List<T> records, long total, JENSPageRequest pageRequest) {
        this.records = records;
        this.total = total;
        this.current = pageRequest.getCurrent();
        this.size = pageRequest.getSize();
        this.pages = this.size > 0 ? (total + this.size - 1) / this.size : 0;
    }

    /**
     * 构造函数
     *
     * @param records 数据列表
     * @param total 总记录数
     * @param current 当前页码
     * @param size 页面大小
     */
    public JENSPageResult(List<T> records, long total, int current, int size) {
        this.records = records;
        this.total = total;
        this.current = current;
        this.size = size;
        this.pages = this.size > 0 ? (total + this.size - 1) / this.size : 0;
    }

    /**
     * 是否有上一页
     *
     * @return 是否有上一页
     */
    public boolean hasPrevious() {
        return this.current > 1;
    }

    /**
     * 是否有下一页
     *
     * @return 是否有下一页
     */
    public boolean hasNext() {
        return this.current < this.pages;
    }
} 