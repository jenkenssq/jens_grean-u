package com.jens.green.controller;

import com.jens.green.common.JENSResult;
import com.jens.green.entity.JENSUser;
import com.jens.green.security.JENSUserDetailsService;
import com.jens.green.service.JENSUserService;
import com.jens.green.util.JENSJwtUtil;
import com.jens.green.service.JENSActivityRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 用户控制器
 *
 * @author JENKENSSQ(JENS)
 */
@RestController
@RequestMapping("/api/user")
public class JENSUserController extends JENSBaseController {

    @Autowired
    private JENSUserService userService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JENSJwtUtil jwtUtil;

    @Autowired
    private JENSUserDetailsService userDetailsService;

    @Autowired
    private JENSActivityRecordService activityRecordService;

    /**
     * 用户注册
     *
     * @param params 注册参数
     * @return 注册结果
     */
    @PostMapping("/register")
    public JENSResult<Object> register(@RequestBody Map<String, Object> params) {
        try {
            // 参数校验
            String username = (String) params.get("username");
            String password = (String) params.get("password");
            String email = (String) params.get("email");
            String phone = (String) params.get("phone");
            // 兼容前端可能使用mobile代替phone的情况
            if (!StringUtils.hasText(phone)) {
                phone = (String) params.get("mobile");
            }
            String nickname = (String) params.get("nickname");

            if (!StringUtils.hasText(username) || !StringUtils.hasText(password)) {
                return JENSResult.paramError("用户名和密码不能为空");
            }

            // 创建用户对象
            JENSUser user = new JENSUser();
            user.setUsername(username);
            user.setPassword(password); // 实际在Service层会进行加密
            user.setEmail(email);
            user.setPhone(phone);
            user.setNickname(StringUtils.hasText(nickname) ? nickname : username);

            // 注册用户
            boolean result = userService.register(user);
            if (result) {
                Map<String, Object> data = new HashMap<>();
                data.put("userId", user.getId());
                data.put("username", user.getUsername());
                data.put("phone", user.getPhone());
                data.put("mobile", user.getPhone()); // 添加mobile作为phone的别名
                data.put("email", user.getEmail());
                data.put("nickname", user.getNickname());
                return JENSResult.success("注册成功", data);
            } else {
                return JENSResult.serverError("注册失败，请稍后重试");
            }
        } catch (Exception e) {
            // 添加详细的错误日志
            System.err.println("注册过程中发生异常: " + e.getMessage());
            e.printStackTrace();
            return JENSResult.serverError("注册过程中发生错误: " + e.getMessage());
        }
    }

    /**
     * 用户登录
     *
     * @param params 登录参数
     * @return 登录结果
     */
    @PostMapping("/login")
    public JENSResult<Object> login(@RequestBody Map<String, Object> params) {
        String username = (String) params.get("username");
        String password = (String) params.get("password");

        if (!StringUtils.hasText(username) || !StringUtils.hasText(password)) {
            return JENSResult.paramError("用户名和密码不能为空");
        }

        // 登录验证
        JENSUser user = userService.login(username, password);
        if (user != null) {
            // 生成登录凭证（token）
            String token = generateToken(user);

            // 构建返回结果
            Map<String, Object> data = new HashMap<>();
            data.put("token", token);
            data.put("userId", user.getId());
            data.put("username", user.getUsername());
            data.put("nickname", user.getNickname());
            data.put("avatar", user.getAvatar());
            data.put("phone", user.getPhone());
            data.put("mobile", user.getPhone()); // 添加mobile作为phone的别名
            data.put("email", user.getEmail());

            return JENSResult.success("登录成功", data);
        } else {
            return JENSResult.error(401, "用户名或密码错误");
        }
    }

    /**
     * 获取用户信息
     *
     * @return 用户信息
     */
    @GetMapping("/info")
    public JENSResult<Object> getUserInfo() {
        Long userId = getCurrentUserId();
        logger.debug("当前用户ID: {}", userId);
        JENSUser user = userService.getById(userId);
        if (user == null) {
            return JENSResult.notFound("用户不存在");
        }

        // 构建返回数据（排除敏感信息）
        Map<String, Object> data = new HashMap<>();
        data.put("userId", user.getId());
        data.put("username", user.getUsername());
        data.put("nickname", user.getNickname());
        data.put("avatar", user.getAvatar());
        data.put("email", user.getEmail());
        data.put("phone", user.getPhone());
        data.put("mobile", user.getPhone()); // 添加mobile作为phone的别名，确保前端兼容
        data.put("gender", user.getGender());
        data.put("birthday", user.getBirthday());
        data.put("totalCarbon", user.getTotalCarbon());
        data.put("carbonPoints", user.getCarbonPoints());
        data.put("totalPoints", user.getTotalPoints());
        data.put("status", user.getStatus());
        data.put("createTime", user.getCreateTime());
        data.put("updateTime", user.getUpdateTime());

        return JENSResult.success("获取成功", data);
    }

    /**
     * 修改用户信息
     *
     * @param params 修改参数
     * @return 修改结果
     */
    @PutMapping("/info")
    public JENSResult<Object> updateUserInfo(@RequestBody Map<String, Object> params) {
        Long userId = getCurrentUserId();
        JENSUser user = userService.getById(userId);
        if (user == null) {
            return JENSResult.notFound("用户不存在");
        }

        // 只允许修改部分字段
        String nickname = (String) params.get("nickname");
        String avatar = (String) params.get("avatar");
        Integer gender = (Integer) params.get("gender");
        String birthdayStr = (String) params.get("birthday");

        // 更新用户信息
        if (StringUtils.hasText(nickname)) {
            user.setNickname(nickname);
        }
        if (StringUtils.hasText(avatar)) {
            user.setAvatar(avatar);
        }
        if (gender != null) {
            user.setGender(gender);
        }
        if (StringUtils.hasText(birthdayStr)) {
            try {
                LocalDate birthday = LocalDate.parse(birthdayStr, DateTimeFormatter.ISO_DATE);
                user.setBirthday(birthday);
            } catch (DateTimeParseException e) {
                return JENSResult.paramError("生日格式错误，请使用yyyy-MM-dd格式");
            }
        }

        boolean result = userService.updateById(user);
        if (result) {
            return JENSResult.success("修改成功", null);
        } else {
            return JENSResult.serverError("修改失败，请稍后重试");
        }
    }

    /**
     * 生成JWT token
     *
     * @param user 用户信息
     * @return JWT token字符串
     */
    private String generateToken(JENSUser user) {
        // 通过UserDetailsService获取UserDetails对象
        UserDetails userDetails = userDetailsService.loadUserByUsername(user.getUsername());
        
        // 使用JwtUtil生成标准JWT Token
        return jwtUtil.generateToken(userDetails);
    }

    /**
     * 获取用户碳积分统计信息
     *
     * @param period 统计周期，可选值：day, week, month, year，默认为week
     * @return 碳积分统计信息
     */
    @GetMapping("/carbon-stats")
    public JENSResult<Object> getCarbonStats(
            @RequestParam(defaultValue = "week") String period
    ) {
        Long userId = getCurrentUserId();
        if (userId == null) {
            return JENSResult.unauthorized("请先登录");
        }
        
        try {
            // 获取用户基本信息
            JENSUser user = userService.getById(userId);
            if (user == null) {
                return JENSResult.notFound("用户不存在");
            }
            
            // 查询用户活动记录统计信息
            Map<String, Object> stats = new HashMap<>();
            stats.put("userId", userId);
            stats.put("totalCarbon", user.getTotalCarbon());
            stats.put("carbonPoints", user.getCarbonPoints());
            
            // 获取用户活动统计
            Map<String, Object> activityStats = activityRecordService.getUserActivityStatistics(userId, period);
            if (activityStats == null) {
                // 如果没有获取到活动统计数据，使用默认值
                activityStats = new HashMap<>();
                activityStats.put("period", period);
                activityStats.put("activityCount", 0);
                activityStats.put("periodCarbon", 0.0);
                activityStats.put("periodPoints", 0);
                
                // 活动类型分布
                Map<String, Object> carbonByActivityType = new HashMap<>();
                carbonByActivityType.put("walking", 0);
                carbonByActivityType.put("running", 0);
                carbonByActivityType.put("cycling", 0);
                activityStats.put("carbonByActivityType", carbonByActivityType);
            }
            
            // 添加到返回结果
            stats.putAll(activityStats);
            
            return JENSResult.success("获取成功", stats);
        } catch (Exception e) {
            logger.error("获取用户碳积分统计信息失败", e);
            return JENSResult.serverError("获取用户碳积分统计信息失败: " + e.getMessage());
        }
    }

    /**
     * 获取用户积分信息
     *
     * @return 用户积分信息
     */
    @GetMapping("/points")
    public JENSResult<Object> getUserPoints() {
        Long userId = getCurrentUserId();
        if (userId == null) {
            return JENSResult.unauthorized("请先登录");
        }
        
        try {
            // 获取用户信息
            JENSUser user = userService.getById(userId);
            if (user == null) {
                return JENSResult.notFound("用户不存在");
            }
            
            Map<String, Object> result = new HashMap<>();
            result.put("points", user.getCarbonPoints());
            result.put("totalPoints", user.getTotalPoints());
            result.put("totalCarbon", user.getTotalCarbon());
            
            return JENSResult.success("获取成功", result);
        } catch (Exception e) {
            logger.error("获取用户积分信息失败", e);
            return JENSResult.serverError("获取积分信息失败: " + e.getMessage());
        }
    }

    /**
     * 上传用户头像
     *
     * @param file 头像文件
     * @return 上传结果
     */
    @PostMapping("/avatar")
    public JENSResult<Object> uploadAvatar(@RequestParam("file") MultipartFile file) {
        // 获取当前用户ID
        Long userId = getCurrentUserId();
        if (userId == null) {
            return JENSResult.unauthorized("请先登录");
        }
        
        JENSUser user = userService.getById(userId);
        if (user == null) {
            return JENSResult.notFound("用户不存在");
        }

        if (file.isEmpty()) {
            return JENSResult.paramError("请选择要上传的头像文件");
        }
        
        try {
            // 获取项目运行目录
            String projectPath = System.getProperty("user.dir");
            // 文件上传路径
            Path uploadPath = Paths.get(projectPath, "src", "main", "resources", "static", "uploads", "avatar");
            
            // 确保上传目录存在
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }
            
            // 获取原始文件名
            String originalFilename = StringUtils.cleanPath(file.getOriginalFilename());
            
            // 获取文件扩展名
            String fileExtension = "";
            if (originalFilename.contains(".")) {
                fileExtension = originalFilename.substring(originalFilename.lastIndexOf('.'));
            }
            
            // 生成新的文件名（userId_uuid.扩展名）
            String newFilename = "avatar_" + userId + "_" + UUID.randomUUID().toString() + fileExtension;
            
            // 保存文件
            Path targetLocation = uploadPath.resolve(newFilename);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
            
            // 构建文件URL
            String avatarUrl = "/uploads/avatar/" + newFilename;
            
            // 记录文件位置
            logger.info("头像保存至: {}", targetLocation.toAbsolutePath());
            logger.info("头像访问URL: {}", avatarUrl);
            
            // 更新用户头像URL
            user.setAvatar(avatarUrl);
            boolean updateResult = userService.updateById(user);
            
            if (updateResult) {
                Map<String, String> data = new HashMap<>();
                data.put("avatarUrl", avatarUrl);
                return JENSResult.success("头像上传成功", data);
            } else {
                return JENSResult.serverError("头像URL更新失败");
            }
        } catch (IOException e) {
            logger.error("头像上传失败", e);
            return JENSResult.serverError("头像上传失败: " + e.getMessage());
        }
    }
} 