package com.jens.green.service;

import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;
import com.jens.green.entity.JENSPrize;

/**
 * 奖品服务接口
 *
 * @author JENKENSSQ(JENS)
 */
public interface JENSPrizeService extends JENSBaseService<JENSPrize> {
    
    /**
     * 分页查询上架的奖品
     *
     * @param prizeType   奖品类型，null则查询全部
     * @param pageRequest 分页请求
     * @return 分页结果
     */
    JENSPageResult<JENSPrize> getOnSalePrizes(Integer prizeType, JENSPageRequest pageRequest);
    
    /**
     * 检查奖品是否存在且有库存
     *
     * @param prizeId 奖品ID
     * @param count   数量
     * @return 是否有库存
     */
    boolean checkStock(Long prizeId, Integer count);
    
    /**
     * 减少奖品库存
     *
     * @param prizeId 奖品ID
     * @param count   数量
     * @return 是否成功
     */
    boolean decreaseStock(Long prizeId, Integer count);
} 