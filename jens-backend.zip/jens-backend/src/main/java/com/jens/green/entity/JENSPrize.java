package com.jens.green.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 奖品实体类
 *
 * @author JENKENSSQ(JENS)
 */
@Data
@Accessors(chain = true)
@TableName("jens_prize")
public class JENSPrize implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 奖品ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    
    /**
     * 奖品名称
     */
    private String name;
    
    /**
     * 奖品描述
     */
    private String description;
    
    /**
     * 图片URL
     */
    private String imageUrl;
    
    /**
     * 所需积分
     */
    private Integer pointsRequired;
    
    /**
     * 库存
     */
    private Integer stock;
    
    /**
     * 奖品类型：1-虚拟奖品，2-实物奖品
     */
    private Integer prizeType;
    
    /**
     * 状态：0-下架，1-上架
     */
    private Integer status;
    
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
} 