package com.jens.green.service;

import com.jens.green.entity.JENSUser;
import com.jens.green.model.request.JENSRegisterRequest;

/**
 * 用户服务接口
 *
 * @author JENKENSSQ(JENS)
 */
public interface JENSUserService extends JENSBaseService<JENSUser> {
    
    /**
     * 根据用户名查询用户
     *
     * @param username 用户名
     * @return 用户对象
     */
    JENSUser getUserByUsername(String username);
    
    /**
     * 根据用户名查询用户ID
     *
     * @param username 用户名
     * @return 用户ID，如果用户不存在则返回null
     */
    Long getUserIdByUsername(String username);
    
    /**
     * 用户注册
     *
     * @param user 用户信息
     * @return 是否成功
     */
    boolean register(JENSUser user);
    
    /**
     * 从注册请求创建用户
     *
     * @param registerRequest 注册请求
     * @return 是否成功
     */
    boolean register(JENSRegisterRequest registerRequest);
    
    /**
     * 用户登录
     *
     * @param username 用户名
     * @param password 密码
     * @return 用户对象（登录成功）或null（登录失败）
     */
    JENSUser login(String username, String password);
    
    /**
     * 更新用户积分信息
     *
     * @param userId 用户ID
     * @param carbonReduced 碳减排量
     * @param pointsEarned 获得积分
     * @return 是否成功
     */
    boolean updateUserPoints(Long userId, java.math.BigDecimal carbonReduced, Integer pointsEarned);
    
    /**
     * 消费用户积分（用于兑换奖品）
     *
     * @param userId 用户ID
     * @param points 消费积分
     * @return 是否成功
     */
    boolean consumePoints(Long userId, Integer points);
    
    /**
     * 检查用户积分是否足够
     *
     * @param userId 用户ID
     * @param points 所需积分
     * @return 是否足够
     */
    boolean checkPointsEnough(Long userId, Integer points);
    
    /**
     * 检查用户名是否已存在
     *
     * @param username 用户名
     * @return 是否存在
     */
    boolean existsByUsername(String username);
    
    /**
     * 检查邮箱是否已存在
     *
     * @param email 邮箱
     * @return 是否存在
     */
    boolean existsByEmail(String email);
    
    /**
     * 更新用户最后登录时间
     *
     * @param userId 用户ID
     * @return 是否成功
     */
    boolean updateLastLoginTime(Long userId);
    
    /**
     * 获取用户的角色列表
     *
     * @param userId 用户ID
     * @return 角色列表
     */
    java.util.List<String> getUserRoles(Long userId);
    
    /**
     * 获取用户的权限列表
     *
     * @param userId 用户ID
     * @return 权限列表
     */
    java.util.List<String> getUserPermissions(Long userId);
} 