package com.jens.green;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * JENS碳积分游戏化系统应用启动类
 * 
 * @author JENKENSSQ(JENS)
 */
@SpringBootApplication
@EnableTransactionManagement
@EnableScheduling
public class JENSGreenApplication {

    public static void main(String[] args) {
        SpringApplication.run(JENSGreenApplication.class, args);
    }

} 