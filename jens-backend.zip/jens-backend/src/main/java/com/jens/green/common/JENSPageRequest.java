package com.jens.green.common;

import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.io.Serializable;

/**
 * 分页请求对象
 *
 * @author JENKENSSQ(JENS)
 */
@Data
public class JENSPageRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 当前页码，从1开始
     */
    @Min(value = 1, message = "页码最小为1")
    private Integer current = 1;

    /**
     * 每页大小
     */
    @Min(value = 1, message = "每页条数最小为1")
    @Max(value = 100, message = "每页条数最大为100")
    private Integer size = 10;

    /**
     * 排序字段
     */
    private String orderField;

    /**
     * 排序方式，true为升序，false为降序
     */
    private Boolean isAsc = true;

    /**
     * 根据当前页码和每页大小计算偏移量
     *
     * @return 偏移量
     */
    public long getOffset() {
        return (long) (current - 1) * size;
    }

    /**
     * 构造函数
     */
    public JENSPageRequest() {
    }

    /**
     * 构造函数
     *
     * @param current 当前页码
     * @param size 每页记录数
     */
    public JENSPageRequest(Integer current, Integer size) {
        this.current = current;
        this.size = size;
    }

    /**
     * 构造函数
     *
     * @param current 当前页码
     * @param size 每页记录数
     * @param orderField 排序字段
     * @param isAsc 是否升序
     */
    public JENSPageRequest(Integer current, Integer size, String orderField, Boolean isAsc) {
        this.current = current;
        this.size = size;
        this.orderField = orderField;
        this.isAsc = isAsc;
    }
} 