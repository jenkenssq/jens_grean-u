package com.jens.green.exception;

import com.jens.green.common.JENSResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.stream.Collectors;

/**
 * 全局异常处理器
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@RestControllerAdvice
public class JENSGlobalExceptionHandler {

    /**
     * 处理业务异常
     *
     * @param e 业务异常
     * @return 错误信息
     */
    @ExceptionHandler(JENSServiceException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public JENSResult<Void> handleServiceException(JENSServiceException e) {
        log.error("业务异常: {}", e.getMessage(), e);
        return JENSResult.error(e.getCode(), e.getMessage());
    }

    /**
     * 处理请求参数验证异常（表单提交）
     *
     * @param e 请求参数验证异常
     * @return 错误信息
     */
    @ExceptionHandler(BindException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public JENSResult<Void> handleBindException(BindException e) {
        BindingResult bindingResult = e.getBindingResult();
        String errorMsg = bindingResult.getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .collect(Collectors.joining(", "));
        log.error("参数验证异常: {}", errorMsg, e);
        return JENSResult.paramError(errorMsg);
    }

    /**
     * 处理请求参数验证异常（JSON提交）
     *
     * @param e 请求参数验证异常
     * @return 错误信息
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public JENSResult<Void> handleMethodArgumentNotValidException(MethodArgumentNotValidException e) {
        BindingResult bindingResult = e.getBindingResult();
        String errorMsg = bindingResult.getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .collect(Collectors.joining(", "));
        log.error("参数验证异常: {}", errorMsg, e);
        return JENSResult.paramError(errorMsg);
    }

    /**
     * 处理请求参数验证异常（单个参数）
     *
     * @param e 请求参数验证异常
     * @return 错误信息
     */
    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public JENSResult<Void> handleConstraintViolationException(ConstraintViolationException e) {
        String errorMsg = e.getConstraintViolations().stream()
                .map(ConstraintViolation::getMessage)
                .collect(Collectors.joining(", "));
        log.error("参数验证异常: {}", errorMsg, e);
        return JENSResult.paramError(errorMsg);
    }

    /**
     * 处理所有未处理的异常
     *
     * @param e 异常
     * @return 错误信息
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public JENSResult<Void> handleException(Exception e) {
        log.error("系统异常: {}", e.getMessage(), e);
        return JENSResult.serverError("系统异常，请联系管理员");
    }
} 