package com.jens.green.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 成就实体类
 *
 * @author JENKENSSQ(JENS)
 */
@Data
@Accessors(chain = true)
@TableName("jens_achievement")
public class JENSAchievement implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 成就ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    
    /**
     * 成就名称
     */
    private String name;
    
    /**
     * 成就描述
     */
    private String description;
    
    /**
     * 成就图标URL
     */
    private String iconUrl;
    
    /**
     * 成就类型：carbon-减碳量，walking-步行，running-跑步，cycling-骑行，login-登录打卡
     * 数据库中对应的字段名为type
     */
    @TableField("type")
    private String achievementType;
    
    /**
     * 达成条件值（对应的减碳量或活动次数等）
     * 数据库中对应的字段名为condition_value
     */
    @TableField("condition_value")
    private Integer conditionValue;
    
    /**
     * 奖励积分
     */
    private Integer rewardPoints;
    
    /**
     * 难度级别：1-简单，2-中等，3-困难，4-专家，5-大师
     * 此字段在数据库表中不存在
     */
    @TableField(exist = false)
    private Integer difficultyLevel;
    
    /**
     * 成就状态：0-禁用，1-启用
     */
    private Integer status;
    
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
} 