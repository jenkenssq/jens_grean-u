package com.jens.green.service;

import com.jens.green.entity.JENSTrackPoint;

import java.util.List;

/**
 * 轨迹点服务接口
 *
 * @author JENKENSSQ(JENS)
 */
public interface JENSTrackPointService extends JENSBaseService<JENSTrackPoint> {
    
    /**
     * 根据活动记录ID查询轨迹点列表
     *
     * @param recordId 活动记录ID
     * @return 轨迹点列表
     */
    List<JENSTrackPoint> getTrackPointsByRecordId(Long recordId);
    
    /**
     * 批量保存轨迹点
     *
     * @param trackPoints 轨迹点列表
     * @return 是否成功
     */
    boolean saveBatchTrackPoints(List<JENSTrackPoint> trackPoints);
} 