package com.jens.green.controller;

import com.jens.green.common.JENSResult;
import com.jens.green.constants.JENSConstants;
import com.jens.green.entity.JENSSensorConfig;
import com.jens.green.service.JENSSensorConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 传感器模拟控制器
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@RestController
@RequestMapping("/api/sensor")
public class JENSSensorController extends JENSBaseController {

    @Autowired
    private JENSSensorConfigService sensorConfigService;

    // 用于存储虚拟传感器配置的Map
    private final Map<Long, Map<String, Object>> virtualConfigMap = new HashMap<>();

    /**
     * 获取用户传感器配置
     *
     * @return 传感器配置
     */
    @GetMapping("/config")
    public JENSResult<Object> getSensorConfig() {
        Long userId = getCurrentUserId();
        
        // 获取用户所有传感器配置
        List<JENSSensorConfig> configs = sensorConfigService.getConfigsByUserId(userId);
        
        // 如果没有配置，创建默认配置
        if (CollectionUtils.isEmpty(configs)) {
            JENSSensorConfig config = createDefaultConfig(userId);
            configs = Collections.singletonList(config);
        } else {
            // 为每个配置设置sensorType字段值（根据activityType映射）
            for (JENSSensorConfig config : configs) {
                String activityType = config.getActivityType();
                if (activityType != null) {
                    if ("walking".equals(activityType) || "running".equals(activityType)) {
                        config.setSensorType(JENSConstants.SensorType.HEART_RATE); // 1
                    } else if ("cycling".equals(activityType) || "hiking".equals(activityType)) {
                        config.setSensorType(JENSConstants.SensorType.ACCELEROMETER); // 2
                    } else if ("swimming".equals(activityType) || "gym".equals(activityType)) {
                        config.setSensorType(JENSConstants.SensorType.GPS); // 3
                    } else {
                        config.setSensorType(JENSConstants.SensorType.HEART_RATE); // 默认设置为心率传感器
                    }
                }
                // 同样设置其他非数据库字段的默认值
                if (config.getSamplingRate() == null) {
                    config.setSamplingRate(5);
                }
                if (config.getPrecision() == null) {
                    config.setPrecision(2);
                }
                if (config.getHardwareId() == null) {
                    config.setHardwareId("simulator-" + UUID.randomUUID().toString().substring(0, 8));
                }
                if (config.getExtraConfig() == null) {
                    config.setExtraConfig("{\"simulationMode\":1,\"noiseValue\":0.05}");
                }
            }
        }

        // 获取或创建虚拟配置
        Map<String, Object> virtualConfig = getOrCreateVirtualConfig(userId);
        
        // 合并实际配置和虚拟配置
        Map<String, Object> result = new HashMap<>();
        result.put("configs", configs);
        result.put("virtualConfig", virtualConfig);
        
        return JENSResult.success("获取成功", result);
    }

    /**
     * 更新用户虚拟传感器配置
     *
     * @param params 配置参数
     * @return 更新结果
     */
    @PutMapping("/config")
    public JENSResult<Object> updateSensorConfig(@RequestBody Map<String, Object> params) {
        Long userId = getCurrentUserId();
        
        // 更新虚拟配置
        Map<String, Object> virtualConfig = getOrCreateVirtualConfig(userId);
        
        // 更新配置
        Boolean locationEnabled = (Boolean) params.get("locationEnabled");
        Boolean motionEnabled = (Boolean) params.get("motionEnabled");
        Boolean heartRateEnabled = (Boolean) params.get("heartRateEnabled");
        Object noiseValue = params.get("noiseValue");
        Integer updateInterval = (Integer) params.get("updateInterval");
        Integer simulationMode = (Integer) params.get("simulationMode");
        String activityType = (String) params.get("activityType");
        
        if (locationEnabled != null) {
            virtualConfig.put("locationEnabled", locationEnabled);
        }
        if (motionEnabled != null) {
            virtualConfig.put("motionEnabled", motionEnabled);
        }
        if (heartRateEnabled != null) {
            virtualConfig.put("heartRateEnabled", heartRateEnabled);
        }
        if (noiseValue != null) {
            virtualConfig.put("noiseValue", convertToBigDecimal(noiseValue));
        }
        if (updateInterval != null) {
            virtualConfig.put("updateInterval", updateInterval);
        }
        if (simulationMode != null) {
            virtualConfig.put("simulationMode", simulationMode);
        }
        if (StringUtils.hasText(activityType)) {
            virtualConfig.put("activityType", activityType);
        }
        
        // 保存到内存中
        virtualConfigMap.put(userId, virtualConfig);
        
        return JENSResult.success("更新成功", virtualConfig);
    }

    /**
     * 生成模拟传感器数据
     *
     * @param seconds 模拟时间（秒）
     * @return 模拟数据
     */
    @GetMapping("/simulate")
    public JENSResult<Object> generateSimulationData(
            @RequestParam(defaultValue = "60") Integer seconds
    ) {
        if (seconds > 3600) {
            return JENSResult.paramError("模拟时间不能超过1小时");
        }
        
        Long userId = getCurrentUserId();
        Map<String, Object> virtualConfig = getOrCreateVirtualConfig(userId);
        
        // 根据配置生成模拟数据
        List<Map<String, Object>> simulationData = generateSensorData(virtualConfig, seconds);
        
        Map<String, Object> result = new HashMap<>();
        result.put("config", virtualConfig);
        result.put("data", simulationData);
        result.put("startTime", LocalDateTime.now().minusSeconds(seconds));
        result.put("endTime", LocalDateTime.now());
        result.put("duration", seconds);
        
        return JENSResult.success("生成成功", result);
    }

    /**
     * 创建默认传感器配置
     *
     * @param userId 用户ID
     * @return 默认配置
     */
    private JENSSensorConfig createDefaultConfig(Long userId) {
        JENSSensorConfig config = new JENSSensorConfig();
        config.setUserId(userId);
        // 设置sensorType仅用于前端显示，不影响数据库操作
        config.setSensorType(JENSConstants.SensorType.HEART_RATE); // 心率传感器
        config.setSamplingRate(5); // 5秒一次
        config.setPrecision(2); // 精度2位小数
        config.setEnabled(JENSConstants.CommonStatus.ENABLED); // 启用
        config.setHardwareId("simulator-" + UUID.randomUUID().toString().substring(0, 8));
        config.setExtraConfig("{\"simulationMode\":1,\"noiseValue\":0.05}");
        config.setHeartRateMin(60);
        config.setHeartRateMax(180);
        config.setSpeedMin(0.5);
        config.setSpeedMax(3.0);
        config.setStepFrequency(1.8);
        // 确保设置activityType，这是数据库中存在的字段
        config.setActivityType("walking");
        config.setCreateTime(LocalDateTime.now());
        config.setUpdateTime(LocalDateTime.now());
        
        // 保存到数据库
        sensorConfigService.saveConfig(config);
        return config;
    }

    /**
     * 获取或创建虚拟配置
     *
     * @param userId 用户ID
     * @return 虚拟配置
     */
    private Map<String, Object> getOrCreateVirtualConfig(Long userId) {
        Map<String, Object> virtualConfig = virtualConfigMap.get(userId);
        
        if (virtualConfig == null) {
            virtualConfig = new HashMap<>();
            virtualConfig.put("locationEnabled", true);
            virtualConfig.put("motionEnabled", true);
            virtualConfig.put("heartRateEnabled", true);
            virtualConfig.put("noiseValue", new BigDecimal("0.05"));
            virtualConfig.put("updateInterval", 5);
            virtualConfig.put("simulationMode", 1);
            virtualConfig.put("activityType", "walking");
            
            virtualConfigMap.put(userId, virtualConfig);
        }
        
        return virtualConfig;
    }

    /**
     * 将对象转换为BigDecimal
     *
     * @param value 待转换值
     * @return BigDecimal值，转换失败返回null
     */
    private BigDecimal convertToBigDecimal(Object value) {
        if (value == null) {
            return null;
        }
        
        try {
            if (value instanceof BigDecimal) {
                return (BigDecimal) value;
            } else if (value instanceof Number) {
                return new BigDecimal(value.toString());
            } else if (value instanceof String) {
                return new BigDecimal((String) value);
            }
        } catch (Exception e) {
            log.warn("转换BigDecimal异常: {}", e.getMessage());
        }
        
        return null;
    }

    /**
     * 生成模拟传感器数据
     *
     * @param config  传感器配置
     * @param seconds 模拟时间（秒）
     * @return 模拟数据列表
     */
    private List<Map<String, Object>> generateSensorData(Map<String, Object> config, Integer seconds) {
        List<Map<String, Object>> data = new ArrayList<>();
        ThreadLocalRandom random = ThreadLocalRandom.current();
        
        int updateInterval = (int) config.getOrDefault("updateInterval", 5);
        int samples = seconds / updateInterval;
        BigDecimal noiseValueBd = (BigDecimal) config.getOrDefault("noiseValue", new BigDecimal("0.05"));
        double noiseValue = noiseValueBd.doubleValue();
        boolean locationEnabled = (boolean) config.getOrDefault("locationEnabled", true);
        boolean motionEnabled = (boolean) config.getOrDefault("motionEnabled", true);
        boolean heartRateEnabled = (boolean) config.getOrDefault("heartRateEnabled", true);
        String activityType = (String) config.getOrDefault("activityType", "walking");
        
        // 基准值，根据活动类型设置不同的基准值
        double baseLatitude = 39.90469;  // 北京为例
        double baseLongitude = 116.40717;
        double baseAltitude = 50.0;
        int baseHeartRate = getBaseHeartRate(activityType);
        double baseSpeed = getBaseSpeed(activityType);
        
        // 模拟轨迹，生成合理的位置变化
        for (int i = 0; i < samples; i++) {
            Map<String, Object> point = new HashMap<>();
            
            LocalDateTime timestamp = LocalDateTime.now()
                    .minusSeconds(seconds - i * updateInterval);
            point.put("timestamp", timestamp);
            
            // 模拟位置数据
            if (locationEnabled) {
                // 添加随机噪声和方向性变化
                double direction = (double) i / samples * 2 * Math.PI; // 模拟圆形轨迹
                double distance = baseSpeed * updateInterval / 1000.0; // 米转千米
                
                double latChange = distance * 0.009 * Math.cos(direction); // 大约0.009度=1千米
                double lngChange = distance * 0.009 * Math.sin(direction) / Math.cos(Math.toRadians(baseLatitude));
                
                double latitude = baseLatitude + i * latChange + random.nextGaussian() * noiseValue;
                double longitude = baseLongitude + i * lngChange + random.nextGaussian() * noiseValue;
                double altitude = baseAltitude + random.nextGaussian() * 2;
                
                point.put("latitude", latitude);
                point.put("longitude", longitude);
                point.put("altitude", altitude);
                point.put("accuracy", 5.0 + random.nextDouble() * 5.0);
            }
            
            // 模拟运动数据
            if (motionEnabled) {
                // 速度随时间略有变化
                double speedVariation = Math.sin((double) i / samples * Math.PI) * 0.2;
                double speed = baseSpeed + speedVariation + random.nextGaussian() * noiseValue;
                speed = Math.max(0.1, speed); // 确保速度为正
                
                point.put("speed", speed);
                
                // 根据活动类型设置步频
                int cadence = getBaseCadence(activityType);
                cadence += (int) (random.nextGaussian() * 5);
                point.put("cadence", cadence);
            }
            
            // 模拟心率数据
            if (heartRateEnabled) {
                // 心率随时间略有变化
                double heartRateVariation = Math.sin((double) i / samples * Math.PI * 2) * 5;
                int heartRate = baseHeartRate + (int) heartRateVariation + (int) (random.nextGaussian() * 3);
                heartRate = Math.max(60, Math.min(200, heartRate)); // 限制在合理范围内
                
                point.put("heartRate", heartRate);
            }
            
            data.add(point);
        }
        
        return data;
    }

    /**
     * 根据活动类型获取基准心率
     *
     * @param activityType 活动类型
     * @return 基准心率
     */
    private int getBaseHeartRate(String activityType) {
        switch (activityType) {
            case "walking":
                return 100;
            case "running":
                return 140;
            case "cycling":
                return 130;
            default:
                return 90;
        }
    }

    /**
     * 根据活动类型获取基准速度（米/秒）
     *
     * @param activityType 活动类型
     * @return 基准速度
     */
    private double getBaseSpeed(String activityType) {
        switch (activityType) {
            case "walking":
                return 1.4; // 约5km/h
            case "running":
                return 3.1; // 约11km/h
            case "cycling":
                return 5.5; // 约20km/h
            default:
                return 1.0;
        }
    }

    /**
     * 根据活动类型获取基准步频（步/分钟）
     *
     * @param activityType 活动类型
     * @return 基准步频
     */
    private int getBaseCadence(String activityType) {
        switch (activityType) {
            case "walking":
                return 110;
            case "running":
                return 170;
            case "cycling":
                return 80; // 踏频
            default:
                return 100;
        }
    }
} 