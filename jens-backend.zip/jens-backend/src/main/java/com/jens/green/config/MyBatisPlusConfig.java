package com.jens.green.config;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import java.io.IOException;
import java.util.Arrays;

/**
 * MyBatis-Plus配置类
 *
 * @author JENKENSSQ(JENS)
 */
@Configuration
@MapperScan("com.jens.green.mapper")
public class MyBatisPlusConfig {

    private static final Logger log = LoggerFactory.getLogger(MyBatisPlusConfig.class);

    /**
     * 分页插件
     */
    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        // 添加分页插件
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.MYSQL));
        return interceptor;
    }
    
    /**
     * 在初始化时检查XML映射文件
     */
    @Bean
    public void checkMybatisXmlMappings() {
        try {
            PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
            // 检查XML映射文件是否存在
            Resource[] resources = resolver.getResources("classpath*:/mapper/**/*.xml");
            log.info("发现 {} 个XML映射文件", resources.length);
            for (Resource resource : resources) {
                log.info("XML映射文件: {}", resource.getFilename());
            }
            
            // 检查是否有关键的Mapper XML
            String[] requiredMappers = {
                "JENSCarbonFactorMapper.xml",
                "JENSActivityRecordMapper.xml",
                "JENSPrizeMapper.xml",
                "JENSAchievementMapper.xml"
            };
            
            for (String mapperName : requiredMappers) {
                boolean found = Arrays.stream(resources)
                    .anyMatch(r -> r.getFilename().equals(mapperName));
                if (found) {
                    log.info("关键Mapper XML '{}' 已找到", mapperName);
                } else {
                    log.warn("关键Mapper XML '{}' 未找到!", mapperName);
                }
            }
        } catch (IOException e) {
            log.error("检查XML映射文件时出错", e);
        }
    }
} 