package com.jens.green.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jens.green.entity.JENSPrizeExchange;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 奖品兑换Mapper接口
 *
 * @author JENKENSSQ(JENS)
 */
@Mapper
public interface JENSPrizeExchangeMapper extends BaseMapper<JENSPrizeExchange> {
    
    /**
     * 分页查询用户奖品兑换记录
     *
     * @param page      分页参数
     * @param userId    用户ID
     * @param status    状态，null则查询全部
     * @return 分页结果
     */
    IPage<JENSPrizeExchange> selectUserExchanges(Page<JENSPrizeExchange> page, 
                                         @Param("userId") Long userId, 
                                         @Param("status") Integer status);
    
    /**
     * 更新奖品兑换状态
     *
     * @param id        记录ID
     * @param oldStatus 原状态
     * @param newStatus 新状态
     * @return 影响行数
     */
    int updateStatus(@Param("id") Long id, 
                    @Param("oldStatus") Integer oldStatus, 
                    @Param("newStatus") Integer newStatus);
} 