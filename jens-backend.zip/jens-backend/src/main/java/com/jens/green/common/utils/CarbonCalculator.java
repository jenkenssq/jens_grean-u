package com.jens.green.common.utils;

import com.jens.green.entity.CarbonFactor;
import org.springframework.stereotype.Component;

/**
 * 碳减排计算工具类
 * 
 * @author JENKENSSQ(JENS)
 */
@Component
public class CarbonCalculator {
    
    /**
     * 计算碳减排量
     * 
     * @param activityType 活动类型
     * @param distance 距离(米)
     * @param factor 碳减排因子
     * @return 碳减排量(kg)
     */
    public double calculateCarbonReduction(String activityType, double distance, CarbonFactor factor) {
        if (factor == null) {
            return 0.0;
        }
        
        // 计算碳减排量 = 距离 * 碳减排因子
        return distance * factor.getFactorValue();
    }
    
    /**
     * 计算步行活动的碳减排量
     * 
     * @param distance 距离(米)
     * @param steps 步数
     * @param factor 碳减排因子
     * @return 碳减排量(kg)
     */
    public double calculateWalkingCarbonReduction(double distance, int steps, CarbonFactor factor) {
        if (factor == null) {
            return 0.0;
        }
        
        // 计算碳减排量 = 距离 * 碳减排因子
        return distance * factor.getFactorValue();
    }
    
    /**
     * 计算跑步活动的碳减排量
     * 
     * @param distance 距离(米)
     * @param duration 时长(秒)
     * @param factor 碳减排因子
     * @return 碳减排量(kg)
     */
    public double calculateRunningCarbonReduction(double distance, int duration, CarbonFactor factor) {
        if (factor == null) {
            return 0.0;
        }
        
        // 计算碳减排量 = 距离 * 碳减排因子
        return distance * factor.getFactorValue();
    }
    
    /**
     * 计算骑行活动的碳减排量
     * 
     * @param distance 距离(米)
     * @param duration 时长(秒)
     * @param factor 碳减排因子
     * @return 碳减排量(kg)
     */
    public double calculateCyclingCarbonReduction(double distance, int duration, CarbonFactor factor) {
        if (factor == null) {
            return 0.0;
        }
        
        // 计算碳减排量 = 距离 * 碳减排因子
        return distance * factor.getFactorValue();
    }
    
    /**
     * 计算获得的碳积分
     * 
     * @param carbonReduction 碳减排量(kg)
     * @param pointsRule 积分规则(每kg碳减排对应的积分)
     * @return 积分数量
     */
    public int calculateCarbonPoints(double carbonReduction, int pointsRule) {
        // 积分 = 碳减排量 * 积分规则
        // 四舍五入取整
        return (int) Math.round(carbonReduction * pointsRule);
    }
    
    /**
     * 计算步数对应的距离(米)
     * 
     * @param steps 步数
     * @param stepLength 步长(米)，默认0.7米
     * @return 距离(米)
     */
    public double calculateDistance(int steps, double stepLength) {
        if (stepLength <= 0) {
            stepLength = 0.7; // 默认步长0.7米
        }
        return steps * stepLength;
    }
    
    /**
     * 计算消耗的卡路里(kcal)
     * 
     * @param activityType 活动类型
     * @param distance 距离(米)
     * @param duration 时长(秒)
     * @param weight 体重(kg)，默认60kg
     * @return 消耗卡路里(kcal)
     */
    public double calculateCalories(String activityType, double distance, int duration, double weight) {
        if (weight <= 0) {
            weight = 60.0; // 默认体重60kg
        }
        
        // 转换时长为小时
        double hours = duration / 3600.0;
        
        // 根据活动类型计算消耗的卡路里
        switch (activityType) {
            case "walking":
                // 步行MET值约为3.5
                return 3.5 * weight * hours;
            case "running":
                // 跑步MET值约为8.0
                return 8.0 * weight * hours;
            case "cycling":
                // 骑行MET值约为5.0
                return 5.0 * weight * hours;
            default:
                return 0.0;
        }
    }
} 