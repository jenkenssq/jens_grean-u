package com.jens.green.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;
import com.jens.green.entity.JENSPointsRecord;
import com.jens.green.entity.JENSUser;
import com.jens.green.exception.JENSServiceException;
import com.jens.green.mapper.JENSPointsRecordMapper;
import com.jens.green.service.JENSPointsRecordService;
import com.jens.green.service.JENSUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/**
 * 积分记录服务实现类
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@Service
public class JENSPointsRecordServiceImpl extends JENSBaseServiceImpl<JENSPointsRecordMapper, JENSPointsRecord> implements JENSPointsRecordService {

    @Autowired
    private JENSUserService userService;

    @Override
    public JENSPageResult<JENSPointsRecord> getUserPointsRecords(Long userId, Integer recordType, JENSPageRequest pageRequest) {
        // 直接使用通用查询
        QueryWrapper<JENSPointsRecord> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId);
        
        if (recordType != null) {
            queryWrapper.eq("points_type", recordType);
        }
        
        if (pageRequest.getOrderField() != null && !pageRequest.getOrderField().isEmpty()) {
            queryWrapper.orderBy(true, pageRequest.getIsAsc(), pageRequest.getOrderField());
        } else {
            // 默认按创建时间降序排序
            queryWrapper.orderByDesc("create_time");
        }
        
        return page(pageRequest, queryWrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean addPointsRecord(Long userId, Integer points, Integer recordType, String description, Long relatedId) {
        if (points == 0) {
            return true; // 积分为0，不需要记录
        }
        
        // 查询用户
        JENSUser user = userService.getById(userId);
        if (user == null) {
            throw new JENSServiceException("用户不存在");
        }
        
        // 如果是扣减积分，先检查积分是否足够
        if (points < 0 && !checkPointsEnough(userId, Math.abs(points))) {
            throw new JENSServiceException("积分不足");
        }
        
        // 计算更新后的积分
        Integer newBalance = user.getCarbonPoints() + points;
        
        // 创建积分记录
        JENSPointsRecord record = new JENSPointsRecord();
        record.setUserId(userId);
        record.setPointsType(recordType);
        record.setPointsChange(points);
        record.setPointsBalance(newBalance);
        record.setBusinessId(relatedId);
        record.setRemark(description);
        record.setCreateTime(LocalDateTime.now());
        
        boolean saveResult = save(record);
        if (!saveResult) {
            throw new JENSServiceException("保存积分记录失败");
        }
        
        // 更新用户积分
        user.setCarbonPoints(newBalance);
        user.setTotalPoints(user.getTotalPoints() + (points > 0 ? points : 0)); // 总积分只增不减
        boolean updateResult = userService.updateById(user);
        
        if (!updateResult) {
            throw new JENSServiceException("更新用户积分失败");
        }
        
        return true;
    }

    @Override
    public Integer calculateAvailablePoints(Long userId) {
        // 直接从用户表查询当前积分
        JENSUser user = userService.getById(userId);
        return user != null ? user.getCarbonPoints() : 0;
    }

    @Override
    public boolean checkPointsEnough(Long userId, Integer points) {
        Integer availablePoints = calculateAvailablePoints(userId);
        return availablePoints >= points;
    }
} 