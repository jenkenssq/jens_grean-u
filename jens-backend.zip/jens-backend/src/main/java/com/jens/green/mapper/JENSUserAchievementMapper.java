package com.jens.green.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jens.green.entity.JENSUserAchievement;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 用户成就Mapper接口
 *
 * @author JENKENSSQ(JENS)
 */
@Mapper
public interface JENSUserAchievementMapper extends BaseMapper<JENSUserAchievement> {
    
    /**
     * 查询用户获得的成就列表
     *
     * @param userId 用户ID
     * @return 用户成就列表
     */
    List<JENSUserAchievement> selectByUserId(@Param("userId") Long userId);
    
    /**
     * 查询用户是否已获得指定成就
     *
     * @param userId        用户ID
     * @param achievementId 成就ID
     * @return 用户成就
     */
    JENSUserAchievement selectByUserIdAndAchievementId(@Param("userId") Long userId, 
                                               @Param("achievementId") Long achievementId);
    
    /**
     * 更新成就奖励领取状态
     *
     * @param id         记录ID
     * @param isRewarded 是否已领取奖励
     * @return 影响行数
     */
    int updateRewardStatus(@Param("id") Long id, @Param("isRewarded") Integer isRewarded);
} 