package com.jens.green.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 跨域配置
 *
 * @author JENKENSSQ(JENS)
 */
@Configuration
public class JENSCorsConfig implements WebMvcConfigurer {

    @Value("${jens.cors.allowed-origins:*}")
    private String allowedOrigins;

    @Value("${jens.cors.allowed-methods:GET,POST,PUT,DELETE,OPTIONS}")
    private String allowedMethods;

    @Value("${jens.cors.allowed-headers:*}")
    private String allowedHeaders;

    @Value("${jens.cors.max-age:3600}")
    private Long maxAge;

    /**
     * WebMvc配置跨域（确保更全面的CORS支持）
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOriginPatterns("*")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(false)
                .maxAge(3600);
    }

    /**
     * 跨域过滤器（确保在Spring Security之前应用）
     */
    @Bean
    public CorsFilter corsFilter() {
        CorsConfiguration config = new CorsConfiguration();
        
        // 允许所有来源
        config.addAllowedOriginPattern("*");
        
        // 允许所有HTTP方法
        config.addAllowedMethod("*");
        
        // 允许所有头信息
        config.addAllowedHeader("*");
        
        // 不允许发送Cookie
        config.setAllowCredentials(false);
        
        // 预检请求的有效期，单位：秒
        config.setMaxAge(maxAge);
        
        // 对所有接口应用CORS配置
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return new CorsFilter(source);
    }
} 