package com.jens.green.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jens.green.entity.JENSSensorConfig;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 传感器配置Mapper接口
 *
 * @author JENKENSSQ(JENS)
 */
@Mapper
public interface JENSSensorConfigMapper extends BaseMapper<JENSSensorConfig> {
    
    /**
     * 查询用户启用的传感器配置列表
     *
     * @param userId 用户ID
     * @return 传感器配置列表
     */
    List<JENSSensorConfig> selectEnabledByUserId(@Param("userId") Long userId);
    
    /**
     * 根据用户ID和传感器类型查询配置
     *
     * @param userId     用户ID
     * @param sensorType 传感器类型
     * @return 传感器配置
     */
    JENSSensorConfig selectByUserIdAndType(@Param("userId") Long userId, @Param("sensorType") Integer sensorType);
    
    /**
     * 更新传感器启用状态
     *
     * @param id      配置ID
     * @param enabled 启用状态
     * @return 影响行数
     */
    int updateEnabled(@Param("id") Long id, @Param("enabled") Integer enabled);
} 