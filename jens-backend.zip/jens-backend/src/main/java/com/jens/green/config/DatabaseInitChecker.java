package com.jens.green.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * 数据库初始化检查器
 * 用于验证数据库连接和表结构
 *
 * @author JENKENSSQ(JENS)
 */
@Component
public class DatabaseInitChecker implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DatabaseInitChecker.class);
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void run(String... args) {
        try {
            // 检查数据库连接
            Integer result = jdbcTemplate.queryForObject("SELECT 1", Integer.class);
            log.info("数据库连接检查: {}", result != null ? "成功" : "失败");
            
            // 检查表结构
            List<Map<String, Object>> tables = jdbcTemplate.queryForList(
                "SHOW TABLES LIKE 'jens\\_%'"
            );
            log.info("发现表数量: {}", tables.size());
            for (Map<String, Object> table : tables) {
                log.info("表名: {}", table.values().iterator().next());
            }
            
            // 检查碳因子表
            try {
                List<Map<String, Object>> carbonFactors = jdbcTemplate.queryForList(
                    "SELECT * FROM jens_carbon_factor LIMIT 1"
                );
                log.info("碳因子表检查: {}", !carbonFactors.isEmpty() ? "成功" : "表为空");
            } catch (Exception e) {
                log.error("碳因子表检查失败: {}", e.getMessage());
            }
            
            // 检查其他关键表
            checkTable("jens_activity_record");
            checkTable("jens_track_point");
            checkTable("jens_prize");
            checkTable("jens_achievement");
            checkTable("jens_sensor_config");
        } catch (Exception e) {
            log.error("数据库初始化检查失败", e);
        }
    }
    
    private void checkTable(String tableName) {
        try {
            jdbcTemplate.queryForObject("SELECT COUNT(*) FROM " + tableName, Integer.class);
            log.info("表 {} 检查: 成功", tableName);
        } catch (Exception e) {
            log.error("表 {} 检查失败: {}", tableName, e.getMessage());
        }
    }
} 