package com.jens.green.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 用户成就实体类
 *
 * @author JENKENSSQ(JENS)
 */
@Data
@Accessors(chain = true)
@TableName("jens_user_achievement")
public class JENSUserAchievement implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 记录ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    
    /**
     * 用户ID
     */
    private Long userId;
    
    /**
     * 成就ID
     */
    private Long achievementId;
    
    /**
     * 成就名称（冗余存储）
     */
    private String achievementName;
    
    /**
     * 获得时间
     */
    private LocalDateTime achieveTime;
    
    /**
     * 是否已领取奖励：0-未领取，1-已领取
     */
    private Integer isRewarded;
    
    /**
     * 状态：0-未达成，1-已达成
     * 临时兼容旧表结构
     */
    private Integer status;
    
    /**
     * 奖励积分
     */
    private Integer rewardPoints;
    
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
} 