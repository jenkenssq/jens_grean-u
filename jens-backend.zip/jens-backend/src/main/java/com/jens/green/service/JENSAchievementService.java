package com.jens.green.service;

import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;
import com.jens.green.entity.JENSAchievement;

import java.util.List;

/**
 * 成就服务接口
 *
 * @author JENKENSSQ(JENS)
 */
public interface JENSAchievementService extends JENSBaseService<JENSAchievement> {

    /**
     * 获取所有可用的成就
     *
     * @return 成就列表
     */
    List<JENSAchievement> getAllEnabledAchievements();

    /**
     * 根据成就类型获取成就列表
     *
     * @param achievementType 成就类型
     * @return 成就列表
     */
    List<JENSAchievement> getAchievementsByType(String achievementType);

    /**
     * 分页查询成就列表
     *
     * @param achievementType 成就类型（可选）
     * @param pageRequest     分页请求
     * @return 分页结果
     */
    JENSPageResult<JENSAchievement> getAchievementList(String achievementType, JENSPageRequest pageRequest);

    /**
     * 获取成就详情
     *
     * @param achievementId 成就ID
     * @return 成就详情
     */
    JENSAchievement getAchievementDetail(Long achievementId);

    /**
     * 创建成就
     *
     * @param achievement 成就信息
     * @return 是否成功
     */
    boolean createAchievement(JENSAchievement achievement);

    /**
     * 更新成就
     *
     * @param achievement 成就信息
     * @return 是否成功
     */
    boolean updateAchievement(JENSAchievement achievement);

    /**
     * 更新成就状态
     *
     * @param achievementId 成就ID
     * @param status        状态
     * @return 是否成功
     */
    boolean updateStatus(Long achievementId, Integer status);
} 