package com.jens.green.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jens.green.entity.JENSAchievement;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 成就Mapper接口
 *
 * @author JENKENSSQ(JENS)
 */
@Mapper
public interface JENSAchievementMapper extends BaseMapper<JENSAchievement> {
    
    /**
     * 查询所有启用的成就
     * @return 成就列表
     */
    List<JENSAchievement> selectAllEnabled();
    
    /**
     * 根据类型查询成就
     * @param type 成就类型
     * @param status 状态
     * @return 成就列表
     */
    List<JENSAchievement> selectByTypeAndStatus(
        @Param("type") String type, 
        @Param("status") Integer status);
    
    /**
     * 根据条件值范围查询成就
     * @param type 类型
     * @param minValue 最小条件值
     * @param maxValue 最大条件值
     * @return 成就列表
     */
    List<JENSAchievement> selectByConditionRange(
        @Param("type") String type, 
        @Param("minValue") Integer minValue, 
        @Param("maxValue") Integer maxValue);
    
    /**
     * 分页查询成就列表
     * @param page 分页对象
     * @param status 状态
     * @return 分页后的成就列表
     */
    IPage<JENSAchievement> selectAchievementPage(
        IPage<JENSAchievement> page, 
        @Param("status") Integer status);
} 