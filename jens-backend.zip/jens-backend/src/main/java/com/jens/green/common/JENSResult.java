package com.jens.green.common;

import com.jens.green.constants.JENSConstants;
import lombok.Data;

import java.io.Serializable;

/**
 * 统一API响应结果
 *
 * @author JENKENSSQ(JENS)
 */
@Data
public class JENSResult<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 状态码
     */
    private Integer code;

    /**
     * 提示信息
     */
    private String message;

    /**
     * 响应数据
     */
    private T data;

    /**
     * 时间戳
     */
    private long timestamp;

    private JENSResult() {
        this.timestamp = System.currentTimeMillis();
    }

    private JENSResult(Integer code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
        this.timestamp = System.currentTimeMillis();
    }

    /**
     * 成功响应（无数据）
     */
    public static <T> JENSResult<T> success() {
        return success(null);
    }

    /**
     * 成功响应（有数据）
     */
    public static <T> JENSResult<T> success(T data) {
        return success("操作成功", data);
    }

    /**
     * 成功响应（自定义消息和数据）
     */
    public static <T> JENSResult<T> success(String message, T data) {
        JENSResult<T> result = new JENSResult<>();
        result.setCode(JENSConstants.StatusCode.SUCCESS);
        result.setMessage(message);
        result.setData(data);
        return result;
    }

    /**
     * 失败响应（自定义状态码和消息）
     */
    public static <T> JENSResult<T> error(Integer code, String message) {
        JENSResult<T> result = new JENSResult<>();
        result.setCode(code);
        result.setMessage(message);
        return result;
    }

    /**
     * 参数错误响应
     */
    public static <T> JENSResult<T> paramError(String message) {
        return error(JENSConstants.StatusCode.PARAM_ERROR, message);
    }

    /**
     * 未授权响应
     */
    public static <T> JENSResult<T> unauthorized(String message) {
        return error(JENSConstants.StatusCode.UNAUTHORIZED, message);
    }

    /**
     * 禁止访问响应
     */
    public static <T> JENSResult<T> forbidden(String message) {
        return error(JENSConstants.StatusCode.FORBIDDEN, message);
    }

    /**
     * 资源不存在响应
     */
    public static <T> JENSResult<T> notFound(String message) {
        return error(JENSConstants.StatusCode.NOT_FOUND, message);
    }

    /**
     * 服务器内部错误响应
     */
    public static <T> JENSResult<T> serverError(String message) {
        return error(JENSConstants.StatusCode.SERVER_ERROR, message);
    }
} 