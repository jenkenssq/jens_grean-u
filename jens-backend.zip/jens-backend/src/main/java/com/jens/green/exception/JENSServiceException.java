package com.jens.green.exception;

import com.jens.green.constants.JENSConstants;
import lombok.Getter;

/**
 * 业务异常类
 *
 * @author JENKENSSQ(JENS)
 */
@Getter
public class JENSServiceException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * 错误码
     */
    private Integer code;

    /**
     * 错误消息
     */
    private String message;

    /**
     * 构造业务异常
     *
     * @param message 错误消息
     */
    public JENSServiceException(String message) {
        super(message);
        this.code = JENSConstants.StatusCode.PARAM_ERROR;
        this.message = message;
    }

    /**
     * 构造业务异常
     *
     * @param code    错误码
     * @param message 错误消息
     */
    public JENSServiceException(Integer code, String message) {
        super(message);
        this.code = code;
        this.message = message;
    }

    /**
     * 构造参数错误异常
     *
     * @param message 错误消息
     * @return 参数错误异常
     */
    public static JENSServiceException paramError(String message) {
        return new JENSServiceException(JENSConstants.StatusCode.PARAM_ERROR, message);
    }

    /**
     * 构造未授权异常
     *
     * @return 未授权异常
     */
    public static JENSServiceException unauthorized() {
        return new JENSServiceException(JENSConstants.StatusCode.UNAUTHORIZED, "未授权，请先登录");
    }

    /**
     * 构造禁止访问异常
     *
     * @return 禁止访问异常
     */
    public static JENSServiceException forbidden() {
        return new JENSServiceException(JENSConstants.StatusCode.FORBIDDEN, "没有权限，禁止访问");
    }

    /**
     * 构造资源不存在异常
     *
     * @return 资源不存在异常
     */
    public static JENSServiceException notFound() {
        return new JENSServiceException(JENSConstants.StatusCode.NOT_FOUND, "请求的资源不存在");
    }

    /**
     * 构造资源不存在异常（带详细信息）
     *
     * @param message 错误详细信息
     * @return 资源不存在异常
     */
    public static JENSServiceException notFound(String message) {
        return new JENSServiceException(JENSConstants.StatusCode.NOT_FOUND, message);
    }
} 