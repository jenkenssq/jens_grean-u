package com.jens.green.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.jens.green.constants.JENSConstants;
import com.jens.green.entity.JENSCarbonFactor;
import com.jens.green.mapper.JENSCarbonFactorMapper;
import com.jens.green.service.JENSCarbonFactorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * 碳因子服务实现类
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@Service
public class JENSCarbonFactorServiceImpl extends JENSBaseServiceImpl<JENSCarbonFactorMapper, JENSCarbonFactor> implements JENSCarbonFactorService {

    @Override
    public JENSCarbonFactor getByActivityType(String activityType) {
        // 优先使用Mapper中自定义的方法
        try {
            List<JENSCarbonFactor> factors = baseMapper.selectByActivityType(activityType);
            if (!CollectionUtils.isEmpty(factors)) {
                return factors.get(0);
            }
            return null;
        } catch (Exception e) {
            log.warn("调用selectByActivityType方法失败，使用通用查询方法：", e);
            // 如果Mapper方法未实现，使用通用查询
            LambdaQueryWrapper<JENSCarbonFactor> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(JENSCarbonFactor::getActivityType, activityType)
                    .eq(JENSCarbonFactor::getStatus, JENSConstants.CommonStatus.ENABLED)
                    .last("LIMIT 1");
            return getOne(queryWrapper);
        }
    }

    @Override
    public List<JENSCarbonFactor> getAllEnabledFactors() {
        try {
            // 优先使用自定义方法
            return baseMapper.selectAllEnabled();
        } catch (Exception e) {
            log.warn("调用selectAllEnabled方法失败，使用通用查询方法：", e);
            // 如果自定义方法失败，使用通用查询
            LambdaQueryWrapper<JENSCarbonFactor> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(JENSCarbonFactor::getStatus, JENSConstants.CommonStatus.ENABLED)
                    .orderByAsc(JENSCarbonFactor::getActivityType);
            return list(queryWrapper);
        }
    }
}