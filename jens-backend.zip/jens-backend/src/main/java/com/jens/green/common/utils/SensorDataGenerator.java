package com.jens.green.common.utils;

import com.jens.green.entity.SensorConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Random;

/**
 * 模拟传感器数据生成器
 * 
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@Component
public class SensorDataGenerator {
    
    private final Random random = new Random();
    
    /**
     * 地球半径(米)
     */
    private static final double EARTH_RADIUS = 6378137.0;
    
    /**
     * 生成模拟心率数据
     * 
     * @param config 传感器配置
     * @return 心率值
     */
    public int generateHeartRate(SensorConfig config) {
        int min = config.getHeartRateMin();
        int max = config.getHeartRateMax();
        return random.nextInt(max - min + 1) + min;
    }
    
    /**
     * 生成模拟速度数据
     * 
     * @param config 传感器配置
     * @return 速度(米/秒)
     */
    public double generateSpeed(SensorConfig config) {
        double min = config.getSpeedMin();
        double max = config.getSpeedMax();
        return min + (max - min) * random.nextDouble();
    }
    
    /**
     * 生成随机方向(弧度)
     * 
     * @return 方向(弧度)
     */
    public double generateDirection() {
        // 0到2π之间的随机角度
        return 2 * Math.PI * random.nextDouble();
    }
    
    /**
     * 生成模拟GPS位置数据
     * 
     * @param lastLat 上次纬度
     * @param lastLng 上次经度
     * @param speed 速度(米/秒)
     * @param direction 方向(弧度)
     * @param timeInterval 时间间隔(秒)
     * @return 新位置[纬度,经度]
     */
    public double[] generateGpsPosition(double lastLat, double lastLng, double speed, double direction, int timeInterval) {
        // 计算时间间隔内的移动距离(米)
        double distance = speed * timeInterval;
        
        // 计算新位置
        double latRad = Math.toRadians(lastLat);
        double lngRad = Math.toRadians(lastLng);
        
        double newLat = Math.asin(Math.sin(latRad) * Math.cos(distance / EARTH_RADIUS) + 
                    Math.cos(latRad) * Math.sin(distance / EARTH_RADIUS) * Math.cos(direction));
        double newLng = lngRad + Math.atan2(Math.sin(direction) * Math.sin(distance / EARTH_RADIUS) * Math.cos(latRad),
                    Math.cos(distance / EARTH_RADIUS) - Math.sin(latRad) * Math.sin(newLat));
        
        return new double[] {Math.toDegrees(newLat), Math.toDegrees(newLng)};
    }
    
    /**
     * 生成模拟步数数据
     * 
     * @param config 传感器配置
     * @param timeInterval 时间间隔(秒)
     * @return 时间间隔内的步数
     */
    public int generateSteps(SensorConfig config, int timeInterval) {
        // 根据步频计算步数
        double stepFrequency = config.getStepFrequency();
        if (config.getActivityType().equals("cycling")) {
            return 0; // 骑行活动没有步数
        }
        
        // 基础步数
        int baseSteps = (int) Math.round(stepFrequency * timeInterval);
        
        // 添加一些随机波动(-10%到+10%)
        double variation = 0.2 * random.nextDouble() - 0.1; // -0.1到0.1之间
        return (int) Math.round(baseSteps * (1 + variation));
    }
    
    /**
     * 生成模拟海拔数据
     * 
     * @param lastAltitude 上次海拔(米)
     * @return 新海拔(米)
     */
    public double generateAltitude(double lastAltitude) {
        // 海拔变化在-2米到2米之间
        double change = 4 * random.nextDouble() - 2;
        return lastAltitude + change;
    }
    
    /**
     * 生成初始GPS位置
     * 
     * @param cityCenter 城市中心坐标[纬度,经度]，默认为北京市中心
     * @return 初始位置[纬度,经度]
     */
    public double[] generateInitialPosition(double[] cityCenter) {
        if (cityCenter == null || cityCenter.length != 2) {
            // 默认使用北京市中心坐标
            cityCenter = new double[] {39.9042, 116.4074};
        }
        
        // 在城市中心周围5公里范围内随机生成一个位置
        double lat = cityCenter[0];
        double lng = cityCenter[1];
        
        // 计算5公里对应的经纬度变化
        double latChange = 5000.0 / (EARTH_RADIUS * Math.PI / 180.0);
        double lngChange = 5000.0 / (EARTH_RADIUS * Math.cos(Math.toRadians(lat)) * Math.PI / 180.0);
        
        // 随机生成-1到1之间的系数
        double latFactor = 2 * random.nextDouble() - 1;
        double lngFactor = 2 * random.nextDouble() - 1;
        
        // 计算新位置
        double newLat = lat + latChange * latFactor;
        double newLng = lng + lngChange * lngFactor;
        
        return new double[] {newLat, newLng};
    }
} 