package com.jens.green.controller;

import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;
import com.jens.green.common.JENSResult;
import com.jens.green.entity.JENSPrize;
import com.jens.green.entity.JENSPrizeExchange;
import com.jens.green.entity.JENSUser;
import com.jens.green.service.JENSPrizeExchangeService;
import com.jens.green.service.JENSPrizeService;
import com.jens.green.service.JENSUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * 奖品控制器
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@RestController
@RequestMapping("/api/prize")
public class JENSPrizeController extends JENSBaseController {

    @Autowired
    private JENSPrizeService prizeService;

    @Autowired
    private JENSPrizeExchangeService prizeExchangeService;

    @Autowired
    private JENSUserService userService;

    /**
     * 获取奖品列表（分页）
     *
     * @param prizeType 奖品类型（可选）
     * @param page      页码
     * @param pageSize  每页大小
     * @return 奖品列表
     */
    @GetMapping("/list")
    public JENSResult<Object> getPrizeList(
            @RequestParam(required = false) Integer prizeType,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer pageSize
    ) {
        JENSPageRequest pageRequest = new JENSPageRequest();
        pageRequest.setCurrent(page);
        pageRequest.setSize(pageSize);

        JENSPageResult<JENSPrize> prizePage = prizeService.getOnSalePrizes(prizeType, pageRequest);
        
        Map<String, Object> result = new HashMap<>();
        result.put("total", prizePage.getTotal());
        result.put("pages", prizePage.getPages());
        result.put("current", prizePage.getCurrent());
        result.put("records", prizePage.getRecords());
        
        return JENSResult.success("获取成功", result);
    }

    /**
     * 获取奖品详情
     *
     * @param prizeId 奖品ID
     * @return 奖品详情
     */
    @GetMapping("/{prizeId}")
    public JENSResult<Object> getPrizeDetail(@PathVariable Long prizeId) {
        JENSPrize prize = prizeService.getById(prizeId);
        if (prize == null) {
            return JENSResult.notFound("奖品不存在");
        }
        return JENSResult.success("获取成功", prize);
    }

    /**
     * 兑换奖品
     *
     * @param params 兑换参数
     * @return 兑换结果
     */
    @PostMapping("/exchange")
    public JENSResult<Object> exchangePrize(@RequestBody Map<String, Object> params) {
        Long userId = getCurrentUserId();
        Long prizeId = Long.parseLong(params.get("prizeId").toString());
        Integer count = (Integer) params.get("count");
        String address = (String) params.get("address");
        String contactPhone = (String) params.get("contactPhone");
        String remark = (String) params.get("remark");
        
        // 参数校验
        if (prizeId == null) {
            return JENSResult.paramError("奖品ID不能为空");
        }
        if (count == null || count <= 0) {
            count = 1; // 默认兑换数量为1
        }
        
        // 校验库存
        if (!prizeService.checkStock(prizeId, count)) {
            return JENSResult.error(400, "库存不足");
        }
        
        // 获取奖品信息
        JENSPrize prize = prizeService.getById(prizeId);
        if (prize == null) {
            return JENSResult.notFound("奖品不存在");
        }
        
        // 获取用户信息
        JENSUser user = userService.getById(userId);
        if (user == null) {
            return JENSResult.notFound("用户不存在");
        }
        
        // 检查积分是否足够
        int totalPoints = prize.getPointsRequired() * count;
        if (user.getCarbonPoints() < totalPoints) {
            return JENSResult.error(400, "积分不足");
        }
        
        try {
            // 创建兑换记录
            Long exchangeId = prizeExchangeService.createExchange(
                    userId, prizeId, count, address, contactPhone, remark);
            
            if (exchangeId == null) {
                return JENSResult.serverError("兑换失败，请稍后重试");
            }
            
            // 构建返回数据
            Map<String, Object> result = new HashMap<>();
            result.put("exchangeId", exchangeId);
            result.put("pointsCost", totalPoints);
            result.put("remainingPoints", user.getCarbonPoints() - totalPoints);
            
            return JENSResult.success("兑换成功", result);
            
        } catch (Exception e) {
            log.error("兑换奖品异常", e);
            return JENSResult.serverError("兑换失败：" + e.getMessage());
        }
    }

    /**
     * 获取用户兑换记录
     *
     * @param status 记录状态（可选）
     * @param page     页码
     * @param pageSize 每页大小
     * @return 兑换记录列表
     */
    @GetMapping("/exchanges")
    public JENSResult<Object> getUserExchanges(
            @RequestParam(required = false) Integer status,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer pageSize
    ) {
        Long userId = getCurrentUserId();
        JENSPageRequest pageRequest = new JENSPageRequest();
        pageRequest.setCurrent(page);
        pageRequest.setSize(pageSize);
        
        JENSPageResult<JENSPrizeExchange> exchanges = prizeExchangeService.getUserExchanges(userId, status, pageRequest);
        
        Map<String, Object> result = new HashMap<>();
        result.put("total", exchanges.getTotal());
        result.put("pages", exchanges.getPages());
        result.put("current", exchanges.getCurrent());
        result.put("records", exchanges.getRecords());
        
        return JENSResult.success("获取成功", result);
    }

    /**
     * 获取兑换记录详情
     *
     * @param exchangeId 兑换记录ID
     * @return 兑换记录详情
     */
    @GetMapping("/exchange/{exchangeId}")
    public JENSResult<Object> getExchangeDetail(@PathVariable Long exchangeId) {
        Long userId = getCurrentUserId();
        JENSPrizeExchange exchange = prizeExchangeService.getById(exchangeId);
        
        if (exchange == null) {
            return JENSResult.notFound("兑换记录不存在");
        }
        
        // 验证记录归属权
        if (!userId.equals(exchange.getUserId())) {
            return JENSResult.forbidden("无权访问此记录");
        }
        
        return JENSResult.success("获取成功", exchange);
    }

    /**
     * 取消兑换申请（仅限待处理状态）
     *
     * @param exchangeId 兑换记录ID
     * @return 取消结果
     */
    @PostMapping("/exchange/{exchangeId}/cancel")
    public JENSResult<Object> cancelExchange(
            @PathVariable Long exchangeId,
            @RequestBody(required = false) Map<String, Object> params
    ) {
        Long userId = getCurrentUserId();
        JENSPrizeExchange exchange = prizeExchangeService.getById(exchangeId);
        
        if (exchange == null) {
            return JENSResult.notFound("兑换记录不存在");
        }
        
        // 验证记录归属权
        if (!userId.equals(exchange.getUserId())) {
            return JENSResult.forbidden("无权取消此记录");
        }
        
        // 验证记录状态
        if (exchange.getStatus() != 0) {
            return JENSResult.error(400, "只能取消待处理的记录");
        }
        
        try {
            String reason = params != null ? (String) params.get("reason") : "";
            boolean canceled = prizeExchangeService.cancelExchange(exchangeId, userId, reason);
            if (canceled) {
                return JENSResult.success("取消成功", null);
            } else {
                return JENSResult.serverError("取消失败，请稍后重试");
            }
        } catch (Exception e) {
            log.error("取消兑换异常", e);
            return JENSResult.serverError("取消失败：" + e.getMessage());
        }
    }
} 