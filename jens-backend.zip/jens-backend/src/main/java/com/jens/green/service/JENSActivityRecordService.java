package com.jens.green.service;

import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;
import com.jens.green.entity.JENSActivityRecord;
import com.jens.green.entity.JENSTrackPoint;

import java.util.List;
import java.util.Map;

/**
 * 活动记录服务接口
 *
 * @author JENKENSSQ(JENS)
 */
public interface JENSActivityRecordService extends JENSBaseService<JENSActivityRecord> {
    
    /**
     * 开始新活动
     *
     * @param userId       用户ID
     * @param activityType 活动类型
     * @param latitude     起始纬度
     * @param longitude    起始经度
     * @return 活动记录ID
     */
    Long startActivity(Long userId, String activityType, java.math.BigDecimal latitude, java.math.BigDecimal longitude);
    
    /**
     * 结束活动
     *
     * @param recordId     活动记录ID
     * @param trackPoints  轨迹点列表
     * @return 是否成功
     */
    boolean endActivity(Long recordId, List<JENSTrackPoint> trackPoints);
    
    /**
     * 获取用户活动记录列表
     *
     * @param userId       用户ID
     * @param activityType 活动类型，null则查询全部
     * @param pageRequest  分页请求
     * @return 分页结果
     */
    JENSPageResult<JENSActivityRecord> getUserActivityRecords(Long userId, String activityType, JENSPageRequest pageRequest);
    
    /**
     * 获取用户活动记录详情
     *
     * @param recordId 活动记录ID
     * @return 活动记录
     */
    JENSActivityRecord getActivityDetail(Long recordId);
    
    /**
     * 计算统计数据
     *
     * @param userId 用户ID
     * @return 统计数据，包含总活动次数、总距离、总减碳量、总积分等
     */
    java.util.Map<String, Object> calculateStatistics(Long userId);
    
    /**
     * 获取用户活动统计数据（按时间范围）
     *
     * @param userId    用户ID
     * @param timeRange 时间范围（day/week/month/year）
     * @return 统计数据
     */
    Map<String, Object> getUserActivityStatistics(Long userId, String timeRange);
    
    /**
     * 计算碳减排量和积分
     *
     * @param activityType 活动类型
     * @param distance     距离
     * @return 结果，包含碳减排量和积分两个键值
     */
    java.util.Map<String, Object> calculateCarbonAndPoints(String activityType, java.math.BigDecimal distance);
} 