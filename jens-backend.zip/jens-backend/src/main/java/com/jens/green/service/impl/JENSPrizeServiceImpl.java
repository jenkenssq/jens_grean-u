package com.jens.green.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;
import com.jens.green.constants.JENSConstants;
import com.jens.green.entity.JENSPrize;
import com.jens.green.exception.JENSServiceException;
import com.jens.green.mapper.JENSPrizeMapper;
import com.jens.green.service.JENSPrizeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 奖品服务实现类
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@Service
public class JENSPrizeServiceImpl extends JENSBaseServiceImpl<JENSPrizeMapper, JENSPrize> implements JENSPrizeService {

    @Override
    public JENSPageResult<JENSPrize> getOnSalePrizes(Integer prizeType, JENSPageRequest pageRequest) {
        // 优先使用Mapper中自定义的方法
        try {
            Page<JENSPrize> page = new Page<>(pageRequest.getCurrent(), pageRequest.getSize());
            if (pageRequest.getOrderField() != null && !pageRequest.getOrderField().isEmpty()) {
                page.addOrder(pageRequest.getIsAsc() 
                    ? new com.baomidou.mybatisplus.core.metadata.OrderItem(pageRequest.getOrderField(), true) 
                    : new com.baomidou.mybatisplus.core.metadata.OrderItem(pageRequest.getOrderField(), false));
            } else {
                // 默认按id降序排序
                page.addOrder(new com.baomidou.mybatisplus.core.metadata.OrderItem("id", false));
            }
            
            baseMapper.selectPrizesOnSale(page, prizeType);
            return new JENSPageResult<>(pageRequest, page.getTotal(), page.getRecords());
        } catch (Exception e) {
            log.warn("调用selectPrizesOnSale方法失败，使用通用查询方法：", e);
            // 如果Mapper方法未实现，使用通用查询
            QueryWrapper<JENSPrize> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("status", JENSConstants.CommonStatus.ENABLED)
                    .gt("stock", 0);
            
            if (prizeType != null) {
                queryWrapper.eq("prize_type", prizeType);
            }
            
            if (pageRequest.getOrderField() != null && !pageRequest.getOrderField().isEmpty()) {
                queryWrapper.orderBy(true, pageRequest.getIsAsc(), pageRequest.getOrderField());
            } else {
                // 默认按id降序排序
                queryWrapper.orderByDesc("id");
            }
            
            return page(pageRequest, queryWrapper);
        }
    }

    @Override
    public boolean checkStock(Long prizeId, Integer count) {
        JENSPrize prize = getById(prizeId);
        if (prize == null) {
            throw new JENSServiceException("奖品不存在");
        }
        
        if (prize.getStatus() != JENSConstants.CommonStatus.ENABLED) {
            throw new JENSServiceException("奖品已下架");
        }
        
        return prize.getStock() >= count;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean decreaseStock(Long prizeId, Integer count) {
        if (!checkStock(prizeId, count)) {
            throw new JENSServiceException("奖品库存不足");
        }
        
        // 优先使用Mapper中自定义的方法
        try {
            int rows = baseMapper.decreaseStock(prizeId, count);
            return rows > 0;
        } catch (Exception e) {
            log.warn("调用decreaseStock方法失败，使用通用更新方法：", e);
            // 如果Mapper方法未实现，使用通用更新
            JENSPrize prize = getById(prizeId);
            prize.setStock(prize.getStock() - count);
            return updateById(prize);
        }
    }
} 