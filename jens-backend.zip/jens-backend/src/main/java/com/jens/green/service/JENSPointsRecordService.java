package com.jens.green.service;

import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;
import com.jens.green.entity.JENSPointsRecord;

/**
 * 积分记录服务接口
 *
 * @author JENKENSSQ(JENS)
 */
public interface JENSPointsRecordService extends JENSBaseService<JENSPointsRecord> {

    /**
     * 获取用户积分记录
     *
     * @param userId       用户ID
     * @param recordType   记录类型（可选，对应pointsType）
     * @param pageRequest  分页请求
     * @return 分页结果
     */
    JENSPageResult<JENSPointsRecord> getUserPointsRecords(Long userId, Integer recordType, JENSPageRequest pageRequest);

    /**
     * 添加积分记录并更新用户积分
     *
     * @param userId      用户ID
     * @param points      积分数量变动
     * @param recordType  记录类型（对应pointsType）
     * @param description 描述（对应remark）
     * @param relatedId   关联业务ID（对应businessId）
     * @return 是否成功
     */
    boolean addPointsRecord(Long userId, Integer points, Integer recordType, String description, Long relatedId);

    /**
     * 计算用户可用积分
     *
     * @param userId 用户ID
     * @return 可用积分
     */
    Integer calculateAvailablePoints(Long userId);

    /**
     * 检查用户积分是否足够
     *
     * @param userId 用户ID
     * @param points 所需积分
     * @return 是否足够
     */
    boolean checkPointsEnough(Long userId, Integer points);
} 