package com.jens.green.entity;

import lombok.Data;
import java.math.BigDecimal;

/**
 * 碳减排因子实体类
 * 
 * @author JENKENSSQ(JENS)
 */
@Data
public class CarbonFactor {
    
    /**
     * 因子ID
     */
    private Long id;
    
    /**
     * 活动类型
     */
    private String activityType;
    
    /**
     * 碳减排因子值
     */
    private BigDecimal factorValue;
    
    /**
     * 描述
     */
    private String description;
    
    /**
     * 获取因子值(double类型)
     */
    public double getFactorValue() {
        return factorValue != null ? factorValue.doubleValue() : 0.0;
    }
} 