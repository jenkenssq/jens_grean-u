package com.jens.green.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jens.green.entity.JENSUser;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Map;

/**
 * 用户Mapper接口
 *
 * @author JENKENSSQ(JENS)
 */
@Mapper
public interface JENSUserMapper extends BaseMapper<JENSUser> {
    
    /**
     * 根据用户名查询用户
     *
     * @param username 用户名
     * @return 用户信息
     */
    JENSUser selectByUsername(String username);
    
    /**
     * 根据用户名和密码查询用户
     *
     * @param username 用户名
     * @param password 密码
     * @return 用户信息
     */
    JENSUser selectByUsernameAndPassword(@Param("username") String username, @Param("password") String password);
    
    /**
     * 分页查询用户列表
     *
     * @param page 分页参数
     * @param params 查询参数
     * @return 用户分页列表
     */
    IPage<JENSUser> selectUserPage(IPage<JENSUser> page, @Param("params") Map<String, Object> params);
    
    /**
     * 更新用户碳积分
     *
     * @param userId 用户ID
     * @param points 积分变动值（可正可负）
     * @return 影响行数
     */
    int updateCarbonPoints(@Param("userId") Long userId, @Param("points") int points);
    
    /**
     * 更新用户碳减排量
     *
     * @param userId 用户ID
     * @param carbon 碳减排量变动值
     * @return 影响行数
     */
    int updateTotalCarbon(@Param("userId") Long userId, @Param("carbon") double carbon);
    
    /**
     * 查询用户统计数据
     *
     * @return 用户统计信息
     */
    Map<String, Object> selectUserStats();
} 