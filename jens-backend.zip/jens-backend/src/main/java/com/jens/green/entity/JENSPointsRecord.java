package com.jens.green.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 积分记录实体类
 *
 * @author JENKENSSQ(JENS)
 */
@Data
@Accessors(chain = true)
@TableName("jens_points_record")
public class JENSPointsRecord implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 记录ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    
    /**
     * 用户ID
     */
    private Long userId;
    
    /**
     * 积分类型：1-减碳积分获取，2-奖品兑换，3-管理员调整
     */
    private Integer pointsType;
    
    /**
     * 积分变动数量
     */
    private Integer pointsChange;
    
    /**
     * 积分变动后总数
     */
    private Integer pointsBalance;
    
    /**
     * 关联业务ID
     */
    private Long businessId;
    
    /**
     * 备注
     */
    private String remark;
    
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
} 