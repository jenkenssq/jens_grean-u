package com.jens.green.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

/**
 * 基础服务接口
 *
 * @author JENKENSSQ(JENS)
 */
public interface JENSBaseService<T> {

    /**
     * 保存单个实体
     *
     * @param entity 实体对象
     * @return 是否成功
     */
    boolean save(T entity);

    /**
     * 批量保存实体
     *
     * @param entityList 实体列表
     * @return 是否成功
     */
    boolean saveBatch(Collection<T> entityList);

    /**
     * 根据ID获取实体
     *
     * @param id ID
     * @return 实体对象
     */
    T getById(Serializable id);

    /**
     * 根据ID更新实体
     *
     * @param entity 实体对象
     * @return 是否成功
     */
    boolean updateById(T entity);

    /**
     * 通用分页方法
     *
     * @param pageRequest 分页请求参数
     * @return 分页结果
     */
    JENSPageResult<T> page(JENSPageRequest pageRequest);

    /**
     * 自定义条件分页方法
     *
     * @param pageRequest 分页请求参数
     * @param queryWrapper 查询条件
     * @return 分页结果
     */
    JENSPageResult<T> page(JENSPageRequest pageRequest, Object queryWrapper);

    /**
     * 获取符合条件的所有记录
     *
     * @param queryWrapper 查询条件
     * @return 结果列表
     */
    List<T> list(Object queryWrapper);

    /**
     * 获取符合条件的单个记录
     *
     * @param queryWrapper 查询条件
     * @return 单个记录
     */
    T getOne(Object queryWrapper);

    /**
     * 使用更新条件进行更新
     *
     * @param updateWrapper 更新条件
     * @return 是否成功
     */
    boolean update(Object updateWrapper);

    /**
     * 根据实体和条件更新
     *
     * @param entity 实体对象
     * @param updateWrapper 更新条件
     * @return 是否成功
     */
    boolean update(T entity, Object updateWrapper);

    /**
     * 删除实体
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean removeById(Serializable id);

    /**
     * 批量删除实体
     *
     * @param idList 主键列表
     * @return 是否成功
     */
    boolean removeByIds(List<? extends Serializable> idList);

    /**
     * 查询所有实体
     *
     * @return 实体对象列表
     */
    List<T> list();

    /**
     * 条件查询实体列表
     *
     * @param queryWrapper 查询条件
     * @return 实体对象列表
     */
    List<T> list(QueryWrapper<T> queryWrapper);
}