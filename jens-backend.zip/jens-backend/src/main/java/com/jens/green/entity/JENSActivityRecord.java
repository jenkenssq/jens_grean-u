package com.jens.green.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 运动记录实体类
 *
 * @author JENKENSSQ(JENS)
 */
@Data
@Accessors(chain = true)
@TableName("jens_activity_record")
public class JENSActivityRecord implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 记录ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    
    /**
     * 用户ID
     */
    private Long userId;
    
    /**
     * 活动类型：walking-步行，running-跑步，cycling-骑行
     */
    private String activityType;
    
    /**
     * 开始时间
     */
    private LocalDateTime startTime;
    
    /**
     * 结束时间
     */
    private LocalDateTime endTime;
    
    /**
     * 持续时间(秒)
     */
    private Integer duration;
    
    /**
     * 距离(米)
     */
    private BigDecimal distance;
    
    /**
     * 步数
     */
    private Integer steps;
    
    /**
     * 消耗卡路里(kcal)
     */
    private BigDecimal calories;
    
    /**
     * 碳减排量(kg)
     */
    private BigDecimal carbonReduced;
    
    /**
     * 获得积分
     */
    private Integer pointsEarned;
    
    /**
     * 状态：0-无效，1-有效
     */
    private Integer status;
    
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
} 