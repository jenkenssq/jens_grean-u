package com.jens.green.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jens.green.entity.JENSTrackPoint;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 轨迹点Mapper接口
 *
 * @author JENKENSSQ(JENS)
 */
@Mapper
public interface JENSTrackPointMapper extends BaseMapper<JENSTrackPoint> {
    
    /**
     * 根据活动记录ID查询轨迹点
     * @param recordId 活动记录ID
     * @return 轨迹点列表
     */
    List<JENSTrackPoint> selectByRecordId(@Param("recordId") Long recordId);
    
    /**
     * 批量插入轨迹点
     * @param trackPoints 轨迹点列表
     * @return 插入行数
     */
    int batchInsert(@Param("list") List<JENSTrackPoint> trackPoints);
} 