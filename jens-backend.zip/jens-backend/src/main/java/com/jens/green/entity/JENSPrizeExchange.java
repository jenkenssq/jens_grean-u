package com.jens.green.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 奖品兑换记录实体类
 *
 * @author JENKENSSQ(JENS)
 */
@Data
@Accessors(chain = true)
@TableName("jens_prize_exchange")
public class JENSPrizeExchange implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 记录ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    
    /**
     * 用户ID
     */
    private Long userId;
    
    /**
     * 奖品ID
     */
    private Long prizeId;
    
    /**
     * 奖品名称（冗余存储，防止奖品名称修改）
     */
    private String prizeName;
    
    /**
     * 奖品类型：1-虚拟奖品，2-实物奖品
     */
    private Integer prizeType;
    
    /**
     * 消耗积分
     */
    private Integer pointsUsed;
    
    /**
     * 收货地址ID（实物奖品需要）
     */
    private Long addressId;
    
    /**
     * 状态：0-处理中，1-已发放，2-已取消
     */
    private Integer status;
    
    /**
     * 兑换时间
     */
    private LocalDateTime exchangeTime;
    
    /**
     * 发放时间
     */
    private LocalDateTime deliveryTime;
    
    /**
     * 备注
     */
    private String remark;
    
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
} 