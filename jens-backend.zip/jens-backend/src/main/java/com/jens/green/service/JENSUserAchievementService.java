package com.jens.green.service;

import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;
import com.jens.green.entity.JENSUserAchievement;

import java.util.List;
import java.util.Map;

/**
 * 用户成就服务接口
 *
 * @author JENKENSSQ(JENS)
 */
public interface JENSUserAchievementService extends JENSBaseService<JENSUserAchievement> {

    /**
     * 获取用户的成就列表
     *
     * @param userId        用户ID
     * @param achievedOnly  是否只查询已达成的成就
     * @return 用户成就列表
     */
    List<JENSUserAchievement> getUserAchievements(Long userId, Boolean achievedOnly);

    /**
     * 分页查询用户成就
     *
     * @param userId       用户ID
     * @param achievedOnly 是否只查询已达成的成就，null则查询全部
     * @param pageRequest  分页请求
     * @return 分页结果
     */
    JENSPageResult<JENSUserAchievement> getUserAchievementsByPage(Long userId, Boolean achievedOnly, JENSPageRequest pageRequest);

    /**
     * 获取用户成就详情
     *
     * @param userId        用户ID
     * @param achievementId 成就ID
     * @return 用户成就详情
     */
    JENSUserAchievement getUserAchievementDetail(Long userId, Long achievementId);

    /**
     * 授予用户成就
     *
     * @param userId        用户ID
     * @param achievementId 成就ID
     * @return 成就ID
     */
    Long grantAchievement(Long userId, Long achievementId);

    /**
     * 检查用户活动数据是否达成成就
     *
     * @param userId 用户ID
     * @return 新达成的成就列表
     */
    List<Long> checkUserAchievements(Long userId);

    /**
     * 获取用户成就统计信息
     *
     * @param userId 用户ID
     * @return 统计信息，包含总成就数、已解锁成就数、未解锁成就数等
     */
    Map<String, Object> getUserAchievementStatistics(Long userId);
} 