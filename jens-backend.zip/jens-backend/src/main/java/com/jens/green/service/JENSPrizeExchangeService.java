package com.jens.green.service;

import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;
import com.jens.green.entity.JENSPrizeExchange;

/**
 * 奖品兑换服务接口
 *
 * @author JENKENSSQ(JENS)
 */
public interface JENSPrizeExchangeService extends JENSBaseService<JENSPrizeExchange> {

    /**
     * 创建奖品兑换记录
     *
     * @param userId   用户ID
     * @param prizeId  奖品ID
     * @param count    兑换数量
     * @param address  收货地址（实物奖品需要）
     * @param phone    联系电话（实物奖品需要）
     * @param remark   备注
     * @return 兑换记录ID
     */
    Long createExchange(Long userId, Long prizeId, Integer count, String address, String phone, String remark);

    /**
     * 获取用户兑换记录
     *
     * @param userId       用户ID
     * @param status       状态（可选）
     * @param pageRequest  分页请求
     * @return 分页结果
     */
    JENSPageResult<JENSPrizeExchange> getUserExchanges(Long userId, Integer status, JENSPageRequest pageRequest);

    /**
     * 更新兑换记录状态
     *
     * @param exchangeId   兑换记录ID
     * @param status       新状态
     * @param operateNote  操作备注
     * @return 是否成功
     */
    boolean updateExchangeStatus(Long exchangeId, Integer status, String operateNote);

    /**
     * 取消兑换
     *
     * @param exchangeId 兑换记录ID
     * @param userId     用户ID（用于验证是否是用户自己的兑换记录）
     * @param reason     取消原因
     * @return 是否成功
     */
    boolean cancelExchange(Long exchangeId, Long userId, String reason);
} 