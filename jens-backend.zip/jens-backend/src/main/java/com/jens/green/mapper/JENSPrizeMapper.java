package com.jens.green.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jens.green.entity.JENSPrize;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * 奖品Mapper接口
 *
 * @author JENKENSSQ(JENS)
 */
@Mapper
public interface JENSPrizeMapper extends BaseMapper<JENSPrize> {
    
    /**
     * 分页查询上架的奖品
     *
     * @param page      分页参数
     * @param prizeType 奖品类型，null则查询全部
     * @return 分页结果
     */
    IPage<JENSPrize> selectPrizesOnSale(Page<JENSPrize> page, @Param("prizeType") Integer prizeType);
    
    /**
     * 减少奖品库存
     *
     * @param prizeId 奖品ID
     * @param count   减少数量
     * @return 影响行数
     */
    int decreaseStock(@Param("prizeId") Long prizeId, @Param("count") Integer count);
    
    /**
     * 根据奖品类型和状态查询奖品
     * @param type 奖品类型
     * @param status 状态
     * @return 奖品列表
     */
    List<JENSPrize> selectByTypeAndStatus(
        @Param("type") Integer type, 
        @Param("status") Integer status);
    
    /**
     * 根据ID查询并锁定奖品
     * @param id 奖品ID
     * @return 奖品信息
     */
    JENSPrize selectByIdForUpdate(@Param("id") Long id);
    
    /**
     * 更新奖品库存
     * @param id 奖品ID
     * @param stock 扣减数量
     * @return 影响行数
     */
    int updateStock(@Param("id") Long id, @Param("stock") Integer stock);
    
    /**
     * 分页查询奖品列表
     * @param page 分页对象
     * @param status 状态
     * @return 分页后的奖品列表
     */
    IPage<JENSPrize> selectPrizePage(IPage<JENSPrize> page, @Param("status") Integer status);
} 