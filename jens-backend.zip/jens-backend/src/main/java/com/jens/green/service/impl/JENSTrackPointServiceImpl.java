package com.jens.green.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.jens.green.entity.JENSTrackPoint;
import com.jens.green.mapper.JENSTrackPointMapper;
import com.jens.green.service.JENSTrackPointService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 轨迹点服务实现类
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@Service
public class JENSTrackPointServiceImpl extends JENSBaseServiceImpl<JENSTrackPointMapper, JENSTrackPoint> implements JENSTrackPointService {

    @Override
    public List<JENSTrackPoint> getTrackPointsByRecordId(Long recordId) {
        // 优先使用Mapper中自定义的方法
        try {
            return baseMapper.selectByRecordId(recordId);
        } catch (Exception e) {
            log.warn("调用selectByRecordId方法失败，使用通用查询方法：", e);
            // 如果Mapper方法未实现，使用通用查询
            LambdaQueryWrapper<JENSTrackPoint> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(JENSTrackPoint::getRecordId, recordId)
                    .orderByAsc(JENSTrackPoint::getTimestamp);
            return list(queryWrapper);
        }
    }

    @Override
    public boolean saveBatchTrackPoints(List<JENSTrackPoint> trackPoints) {
        // 优先使用Mapper中自定义的批量插入方法
        try {
            int rows = baseMapper.batchInsert(trackPoints);
            return rows > 0;
        } catch (Exception e) {
            log.warn("调用batchInsert方法失败，使用通用批量保存方法：", e);
            // 如果Mapper方法未实现，使用通用批量保存
            return saveBatch(trackPoints);
        }
    }
} 