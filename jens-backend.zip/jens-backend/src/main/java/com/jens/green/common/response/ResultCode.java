package com.jens.green.common.response;

import lombok.Getter;

/**
 * 响应码枚举
 * 
 * @author JENKENSSQ(JENS)
 */
@Getter
public enum ResultCode {
    
    /**
     * 操作成功
     */
    SUCCESS(200, "操作成功"),
    
    /**
     * 操作失败
     */
    FAILED(500, "操作失败"),
    
    /**
     * 参数检验失败
     */
    VALIDATE_FAILED(400, "参数检验失败"),
    
    /**
     * 暂未登录或token已经过期
     */
    UNAUTHORIZED(401, "暂未登录或token已经过期"),
    
    /**
     * 没有相关权限
     */
    FORBIDDEN(403, "没有相关权限"),
    
    /**
     * 资源不存在
     */
    NOT_FOUND(404, "资源不存在"),
    
    /**
     * 服务器内部错误
     */
    INTERNAL_SERVER_ERROR(500, "服务器内部错误"),
    
    /**
     * 用户名或密码错误
     */
    USERNAME_PASSWORD_ERROR(1001, "用户名或密码错误"),
    
    /**
     * 用户已存在
     */
    USER_EXISTED(1002, "用户已存在"),
    
    /**
     * 用户不存在
     */
    USER_NOT_EXISTED(1003, "用户不存在"),
    
    /**
     * 积分不足
     */
    INSUFFICIENT_POINTS(2001, "积分不足"),
    
    /**
     * 奖品库存不足
     */
    INSUFFICIENT_STOCK(2002, "奖品库存不足"),
    
    /**
     * 奖品不存在
     */
    PRIZE_NOT_EXISTED(2003, "奖品不存在"),
    
    /**
     * 运动记录不存在
     */
    ACTIVITY_NOT_EXISTED(3001, "运动记录不存在"),
    
    /**
     * 运动已结束
     */
    ACTIVITY_ALREADY_ENDED(3002, "运动已结束"),
    
    /**
     * 运动未开始
     */
    ACTIVITY_NOT_STARTED(3003, "运动未开始");
    
    /**
     * 状态码
     */
    private final Integer code;
    
    /**
     * 提示信息
     */
    private final String message;
    
    ResultCode(Integer code, String message) {
        this.code = code;
        this.message = message;
    }
} 