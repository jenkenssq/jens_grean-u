package com.jens.green.controller;

import com.jens.green.common.JENSPageRequest;
import com.jens.green.common.JENSPageResult;
import com.jens.green.common.JENSResult;
import com.jens.green.entity.JENSActivityRecord;
import com.jens.green.entity.JENSCarbonFactor;
import com.jens.green.entity.JENSTrackPoint;
import com.jens.green.service.JENSActivityRecordService;
import com.jens.green.service.JENSCarbonFactorService;
import com.jens.green.service.JENSTrackPointService;
import com.jens.green.service.JENSUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 活动数据控制器
 *
 * @author JENKENSSQ(JENS)
 */
@Slf4j
@RestController
@RequestMapping("/api/activity")
public class JENSActivityController extends JENSBaseController {

    @Autowired
    private JENSActivityRecordService activityRecordService;

    @Autowired
    private JENSTrackPointService trackPointService;

    @Autowired
    private JENSCarbonFactorService carbonFactorService;

    @Autowired
    private JENSUserService userService;

    /**
     * 获取用户活动记录（分页）
     *
     * @param activityType 活动类型（可选）
     * @param page 页码
     * @param pageSize 每页大小
     * @return 活动记录列表
     */
    @GetMapping("/records")
    public JENSResult<Object> getActivityRecords(
            @RequestParam(required = false) String activityType,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer pageSize
    ) {
        Long userId = getCurrentUserId();
        JENSPageRequest pageRequest = new JENSPageRequest();
        pageRequest.setCurrent(page);
        pageRequest.setSize(pageSize);
        
        JENSPageResult<JENSActivityRecord> recordPage = activityRecordService.getUserActivityRecords(
                userId, activityType, pageRequest);
        
        Map<String, Object> result = new HashMap<>();
        result.put("total", recordPage.getTotal());
        result.put("pages", recordPage.getPages());
        result.put("current", recordPage.getCurrent());
        result.put("records", recordPage.getRecords());
        
        return JENSResult.success("获取成功", result);
    }

    /**
     * 获取活动记录详情（包括轨迹点）
     *
     * @param recordId 活动记录ID
     * @return 活动记录详情
     */
    @GetMapping("/record/{recordId}")
    public JENSResult<Object> getActivityRecordDetail(@PathVariable Long recordId) {
        Long userId = getCurrentUserId();
        JENSActivityRecord record = activityRecordService.getById(recordId);
        
        if (record == null) {
            return JENSResult.notFound("活动记录不存在");
        }
        
        // 验证记录归属权
        if (!userId.equals(record.getUserId())) {
            return JENSResult.forbidden("无权访问此记录");
        }
        
        // 获取轨迹点
        List<JENSTrackPoint> trackPoints = trackPointService.getTrackPointsByRecordId(recordId);
        
        Map<String, Object> result = new HashMap<>();
        result.put("record", record);
        result.put("trackPoints", trackPoints);
        
        return JENSResult.success("获取成功", result);
    }

    /**
     * 提交活动记录
     *
     * @param params 活动记录数据
     * @return 提交结果
     */
    @PostMapping("/record")
    public JENSResult<Object> submitActivityRecord(@RequestBody Map<String, Object> params) {
        Long userId = getCurrentUserId();
        
        // 提取基本活动信息
        String activityType = (String) params.get("activityType");
        String startTimeStr = (String) params.get("startTime");
        String endTimeStr = (String) params.get("endTime");
        Integer duration = (Integer) params.get("duration");
        Object distanceObj = params.get("distance");
        Integer steps = (Integer) params.get("steps");
        Object caloriesObj = params.get("calories");
        
        // 参数校验
        if (!StringUtils.hasText(activityType)) {
            return JENSResult.paramError("活动类型不能为空");
        }
        if (duration == null || duration <= 0) {
            return JENSResult.paramError("活动时长必须大于0");
        }
        
        // 提取轨迹点数据
        List<Map<String, Object>> trackPointsData = (List<Map<String, Object>>) params.get("trackPoints");
        
        try {
            // 创建活动记录
            JENSActivityRecord record = new JENSActivityRecord();
            record.setUserId(userId);
            record.setActivityType(activityType);
            
            // 处理时间
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime startTime;
            LocalDateTime endTime;
            
            if (StringUtils.hasText(startTimeStr)) {
                try {
                    startTime = LocalDateTime.parse(startTimeStr, DateTimeFormatter.ISO_DATE_TIME);
                } catch (DateTimeParseException e) {
                    return JENSResult.paramError("开始时间格式错误，请使用ISO格式");
                }
            } else {
                startTime = now.minusMinutes(duration);
            }
            
            if (StringUtils.hasText(endTimeStr)) {
                try {
                    endTime = LocalDateTime.parse(endTimeStr, DateTimeFormatter.ISO_DATE_TIME);
                } catch (DateTimeParseException e) {
                    return JENSResult.paramError("结束时间格式错误，请使用ISO格式");
                }
            } else {
                endTime = now;
            }
            
            record.setStartTime(startTime);
            record.setEndTime(endTime);
            record.setDuration(duration);
            
            // 处理距离
            if (distanceObj != null) {
                BigDecimal distance;
                if (distanceObj instanceof BigDecimal) {
                    distance = (BigDecimal) distanceObj;
                } else if (distanceObj instanceof Double) {
                    distance = BigDecimal.valueOf((Double) distanceObj);
                } else if (distanceObj instanceof Integer) {
                    distance = BigDecimal.valueOf((Integer) distanceObj);
                } else if (distanceObj instanceof String) {
                    distance = new BigDecimal((String) distanceObj);
                } else {
                    return JENSResult.paramError("距离格式错误");
                }
                record.setDistance(distance);
            }
            
            // 设置步数
            record.setSteps(steps);
            
            // 处理卡路里
            if (caloriesObj != null) {
                BigDecimal calories;
                if (caloriesObj instanceof BigDecimal) {
                    calories = (BigDecimal) caloriesObj;
                } else if (caloriesObj instanceof Double) {
                    calories = BigDecimal.valueOf((Double) caloriesObj);
                } else if (caloriesObj instanceof Integer) {
                    calories = BigDecimal.valueOf((Integer) caloriesObj);
                } else if (caloriesObj instanceof String) {
                    calories = new BigDecimal((String) caloriesObj);
                } else {
                    return JENSResult.paramError("卡路里格式错误");
                }
                record.setCalories(calories);
            }
            
            // 计算减碳量和积分
            JENSCarbonFactor factor = carbonFactorService.getByActivityType(activityType);
            BigDecimal carbonReduced = BigDecimal.ZERO;
            int pointsEarned = 0;
            
            if (factor != null && factor.getFactorValue() != null) {
                // 根据活动类型计算减碳量（示例：根据距离或时长）
                if (record.getDistance() != null && record.getDistance().compareTo(BigDecimal.ZERO) > 0) {
                    carbonReduced = record.getDistance().multiply(factor.getFactorValue());
                } else {
                    // 使用时长计算
                    BigDecimal durationInHours = BigDecimal.valueOf(duration / 60.0);
                    carbonReduced = durationInHours.multiply(factor.getFactorValue());
                }
                
                // 计算积分（示例：1kg碳减排=10积分）
                pointsEarned = carbonReduced.multiply(BigDecimal.TEN).intValue();
            }
            
            record.setCarbonReduced(carbonReduced);
            record.setPointsEarned(pointsEarned);
            record.setStatus(1); // 有效状态
            
            // 保存活动记录
            boolean saved = activityRecordService.save(record);
            if (!saved) {
                return JENSResult.serverError("保存活动记录失败");
            }
            
            // 更新用户积分和碳减排量
            try {
                userService.updateUserPoints(userId, carbonReduced, pointsEarned);
                log.info("用户积分更新成功: 用户ID={}, 碳减排={}kg, 积分={}", userId, carbonReduced, pointsEarned);
            } catch (Exception e) {
                log.error("更新用户积分失败", e);
                // 继续执行，不影响主流程
            }
            
            // 处理轨迹点
            if (!CollectionUtils.isEmpty(trackPointsData)) {
                List<JENSTrackPoint> trackPoints = trackPointsData.stream().map(pointData -> {
                    JENSTrackPoint point = new JENSTrackPoint();
                    point.setRecordId(record.getId());
                    
                    // 设置坐标等数据
                    Object latObj = pointData.get("latitude");
                    Object lngObj = pointData.get("longitude");
                    Object altObj = pointData.get("altitude");
                    Object hrObj = pointData.get("heartRate");
                    Object spdObj = pointData.get("speed");
                    String timestamp = (String) pointData.get("timestamp");
                    
                    // 处理纬度
                    if (latObj != null) {
                        BigDecimal latitude;
                        if (latObj instanceof BigDecimal) {
                            latitude = (BigDecimal) latObj;
                        } else if (latObj instanceof Double) {
                            latitude = BigDecimal.valueOf((Double) latObj);
                        } else if (latObj instanceof String) {
                            latitude = new BigDecimal((String) latObj);
                        } else {
                            latitude = null;
                        }
                        point.setLatitude(latitude);
                    }
                    
                    // 处理经度
                    if (lngObj != null) {
                        BigDecimal longitude;
                        if (lngObj instanceof BigDecimal) {
                            longitude = (BigDecimal) lngObj;
                        } else if (lngObj instanceof Double) {
                            longitude = BigDecimal.valueOf((Double) lngObj);
                        } else if (lngObj instanceof String) {
                            longitude = new BigDecimal((String) lngObj);
                        } else {
                            longitude = null;
                        }
                        point.setLongitude(longitude);
                    }
                    
                    // 处理海拔
                    if (altObj != null) {
                        BigDecimal altitude;
                        if (altObj instanceof BigDecimal) {
                            altitude = (BigDecimal) altObj;
                        } else if (altObj instanceof Double) {
                            altitude = BigDecimal.valueOf((Double) altObj);
                        } else if (altObj instanceof String) {
                            altitude = new BigDecimal((String) altObj);
                        } else {
                            altitude = null;
                        }
                        point.setAltitude(altitude);
                    }
                    
                    // 处理心率
                    if (hrObj != null) {
                        if (hrObj instanceof Integer) {
                            point.setHeartRate((Integer) hrObj);
                        } else if (hrObj instanceof Double) {
                            point.setHeartRate(((Double) hrObj).intValue());
                        } else if (hrObj instanceof String) {
                            try {
                                point.setHeartRate(Integer.parseInt((String) hrObj));
                            } catch (NumberFormatException e) {
                                // 忽略转换错误
                            }
                        }
                    }
                    
                    // 处理速度
                    if (spdObj != null) {
                        BigDecimal speed;
                        if (spdObj instanceof BigDecimal) {
                            speed = (BigDecimal) spdObj;
                        } else if (spdObj instanceof Double) {
                            speed = BigDecimal.valueOf((Double) spdObj);
                        } else if (spdObj instanceof String) {
                            speed = new BigDecimal((String) spdObj);
                        } else {
                            speed = null;
                        }
                        point.setSpeed(speed);
                    }
                    
                    // 处理时间戳
                    if (StringUtils.hasText(timestamp)) {
                        try {
                            point.setTimestamp(LocalDateTime.parse(timestamp, DateTimeFormatter.ISO_DATE_TIME));
                        } catch (DateTimeParseException e) {
                            point.setTimestamp(LocalDateTime.now());
                        }
                    } else {
                        point.setTimestamp(LocalDateTime.now());
                    }
                    
                    return point;
                }).collect(Collectors.toList());
                
                // 批量保存轨迹点
                trackPointService.saveBatch(trackPoints);
            }
            
            // 构建返回数据
            Map<String, Object> result = new HashMap<>();
            result.put("recordId", record.getId());
            result.put("carbonReduced", record.getCarbonReduced());
            result.put("pointsEarned", record.getPointsEarned());
            
            return JENSResult.success("提交成功", result);
            
        } catch (Exception e) {
            log.error("提交活动记录异常", e);
            return JENSResult.serverError("提交失败：" + e.getMessage());
        }
    }

    /**
     * 获取用户活动统计数据
     *
     * @param timeRange 时间范围（day/week/month/year），默认为week
     * @return 统计数据
     */
    @GetMapping("/stats")
    public JENSResult<Object> getActivityStats(
            @RequestParam(defaultValue = "week") String timeRange
    ) {
        Long userId = getCurrentUserId();
        
        try {
            Map<String, Object> stats = activityRecordService.getUserActivityStatistics(userId, timeRange);
            if (stats == null) {
                // 如果服务层没有实现该方法，则调用基础统计方法
                stats = activityRecordService.calculateStatistics(userId);
            }
            return JENSResult.success("获取成功", stats);
        } catch (Exception e) {
            log.error("获取活动统计数据异常", e);
            return JENSResult.serverError("获取统计数据失败：" + e.getMessage());
        }
    }

    /**
     * 获取碳减排因子列表
     *
     * @return 碳减排因子列表
     */
    @GetMapping("/factors")
    public JENSResult<Object> getCarbonFactors() {
        List<JENSCarbonFactor> factors = carbonFactorService.getAllEnabledFactors();
        return JENSResult.success("获取成功", factors);
    }

    /**
     * 预估活动奖励（碳减排量和积分）
     *
     * @param params 请求参数，包含 activityType、distance 和 duration
     * @return 预估的碳减排量和积分
     */
    @PostMapping("/estimate")
    public JENSResult<Object> estimateActivityReward(@RequestBody Map<String, Object> params) {
        try {
            String activityType = (String) params.get("activityType");
            Object distanceObj = params.get("distance");
            Object durationObj = params.get("duration");
            
            // 参数校验
            if (!StringUtils.hasText(activityType)) {
                return JENSResult.paramError("活动类型不能为空");
            }
            
            // 处理距离
            BigDecimal distance = BigDecimal.ZERO;
            if (distanceObj != null) {
                if (distanceObj instanceof BigDecimal) {
                    distance = (BigDecimal) distanceObj;
                } else if (distanceObj instanceof Double) {
                    distance = BigDecimal.valueOf((Double) distanceObj);
                } else if (distanceObj instanceof Integer) {
                    distance = BigDecimal.valueOf((Integer) distanceObj);
                } else if (distanceObj instanceof String) {
                    distance = new BigDecimal((String) distanceObj);
                } else {
                    return JENSResult.paramError("距离格式错误");
                }
            }
            
            // 计算碳减排量和积分
            Map<String, Object> result = activityRecordService.calculateCarbonAndPoints(activityType, distance);
            
            return JENSResult.success("预估成功", result);
        } catch (Exception e) {
            log.error("预估活动奖励失败", e);
            return JENSResult.serverError(e.getMessage());
        }
    }
} 