package com.jens.green.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 运动轨迹点实体类
 *
 * @author JENKENSSQ(JENS)
 */
@Data
@Accessors(chain = true)
@TableName("jens_track_point")
public class JENSTrackPoint implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 轨迹点ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    
    /**
     * 运动记录ID
     */
    private Long recordId;
    
    /**
     * 纬度
     */
    private BigDecimal latitude;
    
    /**
     * 经度
     */
    private BigDecimal longitude;
    
    /**
     * 海拔(米)
     */
    private BigDecimal altitude;
    
    /**
     * 心率(次/分)
     */
    private Integer heartRate;
    
    /**
     * 速度(米/秒)
     */
    private BigDecimal speed;
    
    /**
     * 时间戳
     */
    private LocalDateTime timestamp;
    
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
} 