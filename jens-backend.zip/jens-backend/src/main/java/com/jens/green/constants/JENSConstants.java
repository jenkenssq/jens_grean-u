package com.jens.green.constants;

/**
 * 系统常量类
 *
 * @author JENKENSSQ(JENS)
 */
public class JENSConstants {

    /**
     * 系统状态码
     */
    public static class StatusCode {
        /**
         * 成功状态码
         */
        public static final int SUCCESS = 200;
        
        /**
         * 参数错误状态码
         */
        public static final int PARAM_ERROR = 400;
        
        /**
         * 未授权状态码
         */
        public static final int UNAUTHORIZED = 401;
        
        /**
         * 禁止访问状态码
         */
        public static final int FORBIDDEN = 403;
        
        /**
         * 资源不存在状态码
         */
        public static final int NOT_FOUND = 404;
        
        /**
         * 服务器内部错误状态码
         */
        public static final int SERVER_ERROR = 500;
    }
    
    /**
     * 活动类型常量
     */
    public static class ActivityType {
        /**
         * 步行活动类型
         */
        public static final int WALKING = 1;
        
        /**
         * 跑步活动类型
         */
        public static final int RUNNING = 2;
        
        /**
         * 骑行活动类型
         */
        public static final int CYCLING = 3;
    }
    
    /**
     * 记录状态常量
     */
    public static class RecordStatus {
        /**
         * 进行中状态
         */
        public static final int IN_PROGRESS = 0;
        
        /**
         * 已完成状态
         */
        public static final int COMPLETED = 1;
        
        /**
         * 已取消状态
         */
        public static final int CANCELLED = 2;
    }
    
    /**
     * 传感器类型常量
     */
    public static class SensorType {
        /**
         * 心率传感器
         */
        public static final int HEART_RATE = 1;
        
        /**
         * 加速度计传感器
         */
        public static final int ACCELEROMETER = 2;
        
        /**
         * GPS传感器
         */
        public static final int GPS = 3;
    }
    
    /**
     * 积分类型常量
     */
    public static class PointsType {
        /**
         * 减碳积分获取
         */
        public static final int CARBON_REDUCTION = 1;
        
        /**
         * 奖品兑换
         */
        public static final int PRIZE_EXCHANGE = 2;
        
        /**
         * 管理员调整
         */
        public static final int ADMIN_ADJUSTMENT = 3;
        
        /**
         * 成就奖励
         */
        public static final int ACHIEVEMENT_REWARD = 4;
    }
    
    /**
     * 奖品类型常量
     */
    public static class PrizeType {
        /**
         * 虚拟奖品
         */
        public static final int VIRTUAL = 1;
        
        /**
         * 实物奖品
         */
        public static final int PHYSICAL = 2;
    }
    
    /**
     * 成就类型常量
     */
    public static class AchievementType {
        /**
         * 减碳量成就
         */
        public static final String CARBON_REDUCTION = "carbon";
        
        /**
         * 步行步数成就
         */
        public static final String STEP = "step";
        
        /**
         * 跑步距离成就
         */
        public static final String RUN_DISTANCE = "run_distance";
        
        /**
         * 连续打卡成就
         */
        public static final String CONSECUTIVE_CHECK_IN = "login";
        
        /**
         * 特殊成就
         */
        public static final String SPECIAL = "special";
    }
    
    /**
     * 通用状态常量
     */
    public static class CommonStatus {
        /**
         * 禁用状态
         */
        public static final int DISABLED = 0;
        
        /**
         * 启用状态
         */
        public static final int ENABLED = 1;
    }
} 