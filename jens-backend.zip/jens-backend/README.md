# JENS碳积分游戏化系统 - 后端项目

本项目是JENS碳积分游戏化系统的后端部分，基于Spring Boot + MyBatis-Plus + MySQL开发。

## 技术栈

- JDK 17
- Spring Boot 2.7.x
- MyBatis-Plus 3.5.x
- MySQL 9.2.0
- Spring Security + JWT
- Swagger/OpenAPI 3.0
- Logback
- Maven

## 功能模块

1. 用户管理模块
   - 用户注册/登录/登出
   - 用户信息管理
   - 权限控制

2. 运动数据模块
   - 运动数据接收与存储
   - 运动轨迹记录
   - 运动数据统计分析

3. 碳积分计算模块
   - 碳减排量计算
   - 积分规则管理
   - 积分记录管理

4. 奖品管理模块
   - 奖品信息管理
   - 兑换处理
   - 库存管理

5. 成就系统模块
   - 成就条件管理
   - 成就判定
   - 奖励发放

6. 模拟传感器模块
   - 模拟运动数据生成
   - 传感器配置管理
   - 实时数据推送

## 项目结构

```
jens-backend/
├── src/                                 # 源码目录
│   ├── main/                            # 主代码
│   │   ├── java/com/jens/green/         # Java代码
│   │   │   ├── config/                  # 配置类
│   │   │   ├── controller/              # 控制器
│   │   │   ├── entity/                  # 实体类
│   │   │   ├── mapper/                  # MyBatis映射接口
│   │   │   ├── service/                 # 服务接口
│   │   │   │   └── impl/                # 服务实现
│   │   │   ├── common/                  # 公共类
│   │   │   │   ├── exception/           # 异常处理
│   │   │   │   ├── utils/               # 工具类
│   │   │   │   └── response/            # 响应对象
│   │   │   ├── dto/                     # 数据传输对象
│   │   │   ├── vo/                      # 视图对象
│   │   │   ├── enums/                   # 枚举类
│   │   │   ├── task/                    # 定时任务
│   │   │   └── JENSGreenApplication.java # 应用程序入口
│   │   └── resources/                   # 资源文件
│   │       ├── application.yml          # 应用配置
│   │       ├── application-dev.yml      # 开发环境配置
│   │       ├── application-prod.yml     # 生产环境配置
│   │       ├── mapper/                  # MyBatis XML映射文件
│   │       └── logback-spring.xml       # 日志配置
│   └── test/                            # 测试代码
├── pom.xml                              # Maven配置
└── README.md                            # 说明文档
```

## 开发环境准备

确保已安装以下软件：
- JDK 17
- Maven 3.6+
- MySQL 9.2.0

## 项目构建与运行

```bash
# 编译项目
mvn clean package

# 运行项目（开发模式）
mvn spring-boot:run -Dspring-boot.run.profiles=dev

# 运行项目（生产模式）
mvn spring-boot:run -Dspring-boot.run.profiles=prod

# 部署方式
java -jar target/jens-green-0.0.1-SNAPSHOT.jar --spring.profiles.active=prod
```

## 数据库配置

数据库配置在`application-dev.yml`中：

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3308/jens_green?useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai
    username: root
    password: 1223456
    driver-class-name: com.mysql.cj.jdbc.Driver
```

数据库初始化SQL脚本位于项目根目录下的`docs/JENS_db_design.md`文件中。

## API文档

项目集成了Swagger，启动后可通过以下地址访问API文档：

```
http://localhost:8080/swagger-ui/index.html
```

也可以查看项目根目录下的`docs/JENS_api_design.md`文档获取详细API说明。

## 核心功能实现

### 碳积分计算算法

```java
/**
 * 计算碳减排量
 * @param activityType 活动类型
 * @param distance 距离(米)
 * @return 碳减排量(kg)
 */
public double calculateCarbonReduction(String activityType, double distance) {
    // 根据活动类型获取碳减排因子
    CarbonFactor factor = carbonFactorService.getByActivityType(activityType);
    if (factor == null) {
        throw new BusinessException("碳减排因子不存在");
    }
    
    // 计算碳减排量
    return distance * factor.getFactorValue();
}

/**
 * 计算获得的碳积分
 * @param carbonReduction 碳减排量(kg)
 * @return 积分数量
 */
public int calculateCarbonPoints(double carbonReduction) {
    // 积分规则：1kg碳减排 = 100积分
    return (int) Math.round(carbonReduction * 100);
}
```

### 模拟传感器数据生成

```java
/**
 * 生成模拟心率数据
 * @param config 传感器配置
 * @return 心率值
 */
public int generateHeartRate(SensorConfig config) {
    int min = config.getHeartRateMin();
    int max = config.getHeartRateMax();
    return random.nextInt(max - min + 1) + min;
}

/**
 * 生成模拟GPS位置数据
 * @param lastLat 上次纬度
 * @param lastLng 上次经度
 * @param speed 速度(米/秒)
 * @param direction 方向(弧度)
 * @return 新位置[纬度,经度]
 */
public double[] generateGpsPosition(double lastLat, double lastLng, double speed, double direction) {
    // 地球半径(米)
    final double EARTH_RADIUS = 6378137.0;
    
    // 计算1秒内的移动距离(米)
    double distance = speed;
    
    // 计算新位置
    double latRad = Math.toRadians(lastLat);
    double lngRad = Math.toRadians(lastLng);
    
    double newLat = Math.asin(Math.sin(latRad) * Math.cos(distance / EARTH_RADIUS) + 
                    Math.cos(latRad) * Math.sin(distance / EARTH_RADIUS) * Math.cos(direction));
    double newLng = lngRad + Math.atan2(Math.sin(direction) * Math.sin(distance / EARTH_RADIUS) * Math.cos(latRad),
                    Math.cos(distance / EARTH_RADIUS) - Math.sin(latRad) * Math.sin(newLat));
    
    return new double[] {Math.toDegrees(newLat), Math.toDegrees(newLng)};
}
```

## 作者信息

- 作者：JENKENSSQ(JENS)
- GitHub: https://github.com/jenkenssq
- Email: JENKENS@qq.com 