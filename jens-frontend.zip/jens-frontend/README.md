# JENS Green-U 前端项目

这是Green-U项目的前端部分，基于Vue 3、TypeScript和Element Plus构建。

## 项目说明

Green-U是一个鼓励绿色出行、追踪碳排放减少量的应用。该项目前端部分提供了用户交互界面，包括活动记录、碳减排统计、奖品兑换等功能。

## 特性

- 用户认证与管理
- 活动记录与统计
- 传感器数据模拟
- 碳减排因子查询
- 成就与奖品系统

## 安装与运行

```bash
# 安装依赖
npm install

# 启动开发服务器
npm run dev

# 构建生产版本
npm run build
```

## 环境变量配置

项目使用 `.env` 文件配置环境变量：

- `VITE_API_BASE_URL`: API 基础URL
- `VITE_APP_TITLE`: 应用标题

## API 测试工具使用指南

项目包含了一个API测试工具，位于 `/src/views/ApiTest.vue`，可用于测试和验证后端API功能。

### 使用步骤

1. 启动前端开发服务器 `npm run dev`
2. 访问 `/api-test` 路径
3. 使用用户名/密码登录（默认提供了admin/123456）
4. 选择相应的API模块标签页
5. 填写所需参数并点击相应按钮进行测试
6. 查看页面底部的API响应结果

### 注意事项

- **JWT认证**：
  - 登录成功后会自动保存token到localStorage
  - token会在每次API请求时自动添加到请求头
  - 如遇到认证问题，请检查token格式或使用"退出登录"按钮后重新登录

- **错误处理**：
  - 工具会显示详细的错误信息，包括后端返回的错误消息
  - 对特定错误（如JWT格式错误、数据库表不存在等）提供了更友好的提示
  - 开发环境下可在控制台查看完整的请求和响应信息

- **数据库依赖**：
  - 提交活动记录等功能依赖后端数据库表结构
  - 确保后端数据库已完成初始化并创建了所需表结构
  - 如遇到"表不存在"错误，请联系后端开发人员

- **权限控制**：
  - 某些API操作可能需要特定权限
  - 默认admin账户应具有所有权限
  - 如遇到权限问题，请检查用户角色配置

## 项目结构

```
src/
├── api/                # API接口定义
├── assets/             # 静态资源
├── components/         # 通用组件
├── router/             # 路由配置
├── stores/             # 状态管理
├── styles/             # 全局样式
├── types/              # TypeScript类型定义
├── utils/              # 工具函数
└── views/              # 页面组件
    └── ApiTest.vue     # API测试工具
```

## 技术栈

- Vue 3 - 渐进式JavaScript框架
- TypeScript - 带类型系统的JavaScript超集
- Element Plus - UI组件库
- Axios - HTTP客户端
- Pinia - 状态管理
- Vue Router - 路由管理

## 开发者

- 项目作者：JENKENSSQ(JENS)
- GitHub: https://github.com/AAASS554
- Email: JENKENS@qq.com 