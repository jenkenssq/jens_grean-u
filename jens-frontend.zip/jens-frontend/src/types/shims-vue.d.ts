// Vue文件声明
declare module '*.vue' {
  import { DefineComponent } from 'vue'
  const component: DefineComponent<{}, {}, any>
  export default component
}

// Element Plus相关
declare module '@element-plus/icons-vue'; 