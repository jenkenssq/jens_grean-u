// 这个文件确保Element Plus组件的类型被正确识别

declare module 'element-plus/es/components/message' {
  export const ElMessage: {
    success(message: string): void;
    warning(message: string): void;
    info(message: string): void;
    error(message: string): void;
  };
}

declare module 'element-plus/es/components/notification' {
  export const ElNotification: {
    success(options: any): void;
    warning(options: any): void;
    info(options: any): void;
    error(options: any): void;
  };
}

// 如有需要，可以添加更多Element Plus组件的类型定义 