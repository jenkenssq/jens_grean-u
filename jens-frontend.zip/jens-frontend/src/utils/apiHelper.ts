/**
 * JENS API辅助工具
 * 
 * 用于处理API响应数据的通用函数
 * 
 * @author JENKENSSQ(JENS)
 * @email JENKENS@qq.com
 * @github https://github.com/AAASS554
 */

/**
 * 解析API响应并提取列表数据
 * 
 * 支持多种格式的响应数据:
 * 1. 标准JENSResponse格式: { code: 200, message: "success", data: any }
 * 2. 分页数据: { total: 10, pages: 2, current: 1, records: [] }
 * 3. 直接响应数组: []
 * 4. 单个对象: {}
 * 
 * @param response API响应数据
 * @param defaultValue 默认值，当解析失败时返回
 * @param debug 是否输出调试日志
 * @returns 提取的列表数据
 */
export function parseApiResponseList<T = any>(
  response: any, 
  defaultValue: T[] = [],
  debug: boolean = false
): T[] {
  if (debug) {
    console.log('API原始响应数据:', response);
  }
  
  // 响应为空，直接返回默认值
  if (!response) {
    if (debug) console.log('响应数据为空');
    return defaultValue;
  }
  
  // 处理各种可能的响应格式
  try {
    let resultList: T[] = [];
    
    // 不是对象类型，直接返回默认值
    if (typeof response !== 'object') {
      if (debug) console.log('响应不是对象类型:', typeof response);
      return defaultValue;
    }
    
    // 处理标准JENSResponse格式
    if ('code' in response && 'data' in response) {
      if (debug) console.log('检测到标准JENSResponse格式');
      
      // 检查响应状态码
      if (response.code !== 200) {
        if (debug) console.log('响应状态码不是200:', response.code);
        return defaultValue;
      }
      
      const responseData = response.data;
      
      // responseData为空的情况
      if (!responseData) {
        if (debug) console.log('data字段为空');
        return defaultValue;
      }
      
      // 分页格式: { records: [], total: 10, ... }
      if (typeof responseData === 'object' && 'records' in responseData) {
        if (debug) console.log('data是分页对象');
        resultList = Array.isArray(responseData.records) ? responseData.records : [];
      }
      // 直接是数组
      else if (Array.isArray(responseData)) {
        if (debug) console.log('data直接是数组');
        resultList = responseData;
      }
      // 单个对象，转为数组
      else if (typeof responseData === 'object' && responseData !== null) {
        if (debug) console.log('data是单个对象，转为数组');
        resultList = [responseData];
      }
    }
    // 直接分页格式: { records: [], total: 10, ...}
    else if ('records' in response && ('total' in response || 'pages' in response)) {
      if (debug) console.log('检测到直接分页格式');
      resultList = Array.isArray(response.records) ? response.records : [];
    }
    // 直接是数组
    else if (Array.isArray(response)) {
      if (debug) console.log('响应直接是数组');
      resultList = response;
    }
    
    if (debug) console.log('解析后的列表数据:', resultList);
    return resultList;
  } catch (error) {
    console.error('解析API响应出错:', error);
    return defaultValue;
  }
}

/**
 * 解析API响应并提取单个对象数据
 * 
 * @param response API响应数据
 * @param defaultValue 默认值，当解析失败时返回
 * @param debug 是否输出调试日志
 * @returns 提取的对象数据
 */
export function parseApiResponseObject<T = any>(
  response: any, 
  defaultValue: T | null = null,
  debug: boolean = false
): T | null {
  if (debug) {
    console.log('API原始响应数据:', response);
  }
  
  // 响应为空，直接返回默认值
  if (!response) {
    if (debug) console.log('响应数据为空');
    return defaultValue;
  }
  
  try {
    // 处理标准JENSResponse格式
    if ('code' in response && 'data' in response) {
      if (debug) console.log('检测到标准JENSResponse格式');
      
      // 检查响应状态码
      if (response.code !== 200) {
        if (debug) console.log('响应状态码不是200:', response.code);
        return defaultValue;
      }
      
      return response.data || defaultValue;
    }
    
    // 其他情况，尝试将整个响应作为对象返回
    if (typeof response === 'object' && !Array.isArray(response)) {
      if (debug) console.log('响应直接是对象');
      return response;
    }
    
    if (debug) console.log('无法解析为对象');
    return defaultValue;
  } catch (error) {
    console.error('解析API响应出错:', error);
    return defaultValue;
  }
}

/**
 * 格式化响应消息
 * 根据列表长度返回适当的消息
 * 
 * @param list 列表数据
 * @param successTemplate 成功模板，使用{count}表示列表长度
 * @param emptyMessage 空列表消息
 * @returns 格式化后的消息
 */
export function formatListResultMessage(
  list: any[],
  successTemplate: string = '获取成功，共{count}条记录',
  emptyMessage: string = '暂无数据'
): string {
  if (!list || list.length === 0) {
    return emptyMessage;
  }
  
  return successTemplate.replace('{count}', list.length.toString());
} 