import axios from 'axios';

/**
 * 文件上传工具
 * 提供图片上传功能
 */
export interface UploadResult {
  code: number;
  message: string;
  data?: string;
}

/**
 * 上传图片文件
 * @param file 图片文件
 * @returns Promise<UploadResult> 上传结果
 */
export const uploadImage = async (file: File): Promise<UploadResult> => {
  try {
    // 验证文件类型
    const validImageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!validImageTypes.includes(file.type)) {
      return {
        code: 400,
        message: '只支持上传JPG、PNG、GIF和WEBP格式的图片'
      };
    }
    
    // 验证文件大小
    const maxSize = 5 * 1024 * 1024; // 5MB
    if (file.size > maxSize) {
      return {
        code: 400,
        message: '图片大小不能超过5MB'
      };
    }
    
    // 创建FormData对象
    const formData = new FormData();
    formData.append('file', file);
    
    // 发送上传请求
    const token = localStorage.getItem('JENS_TOKEN');
    const response = await axios.post('/api/file/upload/image', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
        'Authorization': token ? `Bearer ${token}` : ''
      }
    });
    
    return response.data;
  } catch (error: any) {
    console.error('图片上传失败:', error);
    return {
      code: 500,
      message: error.message || '图片上传失败，请稍后再试'
    };
  }
};

/**
 * 获取完整的图片URL
 * @param path 图片路径
 * @returns 完整的图片URL
 */
export const getImageUrl = (path: string): string => {
  if (!path) return '';
  
  // 如果是完整URL或数据URL，直接返回
  if (path.startsWith('http') || path.startsWith('data:')) {
    return path;
  }
  
  // 确保路径以斜杠开头
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  
  // 获取基础URL
  const baseUrl = import.meta.env.VITE_API_BASE_URL || '';
  
  return `${baseUrl}${normalizedPath}`;
};

/**
 * 删除已上传的图片
 * @param filename 图片文件名
 * @returns Promise<UploadResult> 删除结果
 */
export const deleteImage = async (filename: string): Promise<UploadResult> => {
  try {
    if (!filename) {
      return {
        code: 400,
        message: '文件名不能为空'
      };
    }
    
    // 提取文件名
    const extractedFilename = filename.includes('/') 
      ? filename.substring(filename.lastIndexOf('/') + 1) 
      : filename;
      
    // 发送删除请求
    const token = localStorage.getItem('JENS_TOKEN');
    const response = await axios.delete(`/api/file/image/${extractedFilename}`, {
      headers: {
        'Authorization': token ? `Bearer ${token}` : ''
      }
    });
    
    return response.data;
  } catch (error: any) {
    console.error('图片删除失败:', error);
    return {
      code: 500,
      message: error.message || '图片删除失败，请稍后再试'
    };
  }
}; 