import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';
import { ElMessage } from 'element-plus';

// 创建axios实例
const service = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080', // API的base_url
  timeout: 15000, // 请求超时时间
  headers: {
    'Content-Type': 'application/json;charset=utf-8'
  },
  withCredentials: false // 不允许携带cookie，避免跨域问题
});

// 请求拦截器
service.interceptors.request.use(
  (config) => {
    // 添加时间戳，防止浏览器缓存
    if (config.method === 'get') {
      config.params = {
        ...config.params,
        _t: new Date().getTime()
      };
    }
    
    // 从localStorage获取token
    const token = localStorage.getItem('JENS_TOKEN');
    // 如果token存在，则添加到请求头，不强制要求JWT格式
    if (token) {
      // 检查token格式是否符合JWT标准，但无论如何都添加到请求头
      if (token.includes('.') && token.split('.').length === 3) {
        config.headers['Authorization'] = `Bearer ${token}`;
      } else {
        console.warn('Token不是标准JWT格式，正在尝试使用简单Token格式');
        // 不使用Bearer前缀，直接设置Token
        config.headers['Authorization'] = token;
      }
    }
    
    // 开发环境下打印请求信息
    if (import.meta.env.DEV) {
      console.log('API请求:', {
        url: config.url,
        method: config.method,
        // 不打印完整的授权头，避免泄露敏感信息
        headers: { ...config.headers, Authorization: config.headers?.Authorization ? '已设置(详情已隐藏)' : '未设置' },
        params: config.params,
        data: config.data
      });
    }
    
    return config;
  },
  (error) => {
    console.error('请求错误:', error);
    return Promise.reject(error);
  }
);

// 响应拦截器
service.interceptors.response.use(
  (response: AxiosResponse) => {
    const res = response.data;
    
    // 开发环境下打印响应信息
    if (import.meta.env.DEV) {
      console.log('API响应:', {
        url: response.config.url,
        status: response.status,
        data: res
      });
    }
    
    // 检查响应是否包含code字段，确定是否是标准响应格式
    if (res && typeof res.code !== 'undefined') {
      // 如果返回的状态码不是200，则判断为错误
      if (res.code !== 200) {
        // 显示错误消息
        ElMessage.error(res.message || '系统错误');
        
        // 401: 未登录或token过期
        if (res.code === 401) {
          // 清除token并跳转到登录页
          localStorage.removeItem('JENS_TOKEN');
          ElMessage.warning('登录已过期，请重新登录');
        }
        
        return Promise.reject(new Error(res.message || '系统错误'));
      } else {
        return res; // 直接返回标准响应格式，包含code、message、data等
      }
    } else {
      // 直接返回数据，没有遵循标准响应格式的情况
      return res;
    }
  },
  (error) => {
    console.error('响应错误:', error);
    
    if (error.response) {
      // 服务器返回了错误状态码
      const { status, data } = error.response;
      switch (status) {
        case 401:
          // 未授权，清除token并跳转到登录页
          localStorage.removeItem('JENS_TOKEN');
          ElMessage.error(data?.message || '登录已过期，请重新登录');
          setTimeout(() => {
            window.location.href = '/login';
          }, 1500);
          break;
        case 403:
          ElMessage.error(data?.message || '没有权限访问该资源');
          break;
        case 404:
          ElMessage.error('请求的资源不存在');
          break;
        case 500:
          ElMessage.error('服务器内部错误');
          break;
        default:
          ElMessage.error(data?.message || `请求失败(${status})`);
      }
    } else if (error.message.includes('Network Error')) {
      ElMessage.error('网络连接失败，请检查您的网络连接或联系管理员');
    } else if (error.message.includes('timeout')) {
      ElMessage.error('请求超时，请稍后重试');
    } else {
      ElMessage.error(error.message || '请求失败');
    }
    
    return Promise.reject(error);
  }
);

// 封装GET请求
export function get<T>(url: string, params?: any, config?: AxiosRequestConfig): Promise<T> {
  return service.get(url, { params, ...config });
}

// 封装POST请求
export function post<T>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> {
  return service.post(url, data, config);
}

// 封装PUT请求
export function put<T>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> {
  return service.put(url, data, config);
}

// 封装DELETE请求
export function del<T>(url: string, params?: any, config?: AxiosRequestConfig): Promise<T> {
  return service.delete(url, { params, ...config });
}

export default service; 