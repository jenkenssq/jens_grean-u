/**
 * 全局退出登录函数
 * 清除所有用户凭证并刷新页面
 */
export function logoutAndRefresh() {
  // 清除所有用户相关的存储信息
  localStorage.removeItem('JENS_TOKEN');
  localStorage.removeItem('JENS_USERNAME');
  
  // 刷新页面以确保所有组件状态重置
  window.location.reload();
} 