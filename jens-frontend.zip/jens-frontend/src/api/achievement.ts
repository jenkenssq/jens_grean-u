import { get } from '@/utils/request';
import type { JENSResponse, PageResult } from './types';

/**
 * 获取成就列表
 * 对应API设计文档: 4.1 获取成就列表 GET /api/achievement/list
 *
 * @param params 查询参数
 * @returns 成就列表
 */
export function getAchievementList(params?: {
  achievementType?: string;
  page?: number;
  pageSize?: number;
}): Promise<JENSResponse<PageResult<any>>> {
  return get<JENSResponse<PageResult<any>>>('/api/achievement/list', params);
}

/**
 * 获取用户成就列表
 * 对应API设计文档: 4.2 获取用户成就列表 GET /api/achievement/user
 *
 * @returns 用户成就列表
 */
export function getUserAchievements(): Promise<JENSResponse<any[]>> {
  return get<JENSResponse<any[]>>('/api/achievement/user');
}

/**
 * 获取成就详情
 * 对应API设计文档: 4.3 获取成就详情 GET /api/achievement/{achievementId}
 *
 * @param achievementId 成就ID
 * @returns 成就详情
 */
export function getAchievementDetail(achievementId: number): Promise<JENSResponse<any>> {
  return get<JENSResponse<any>>(`/api/achievement/${achievementId}`);
}

/**
 * 获取用户成就统计数据
 * 对应API设计文档: 4.4 获取用户成就统计数据 GET /api/achievement/stats
 *
 * @returns 成就统计数据
 */
export function getAchievementStats(): Promise<JENSResponse<any>> {
  return get<JENSResponse<any>>('/api/achievement/stats');
} 