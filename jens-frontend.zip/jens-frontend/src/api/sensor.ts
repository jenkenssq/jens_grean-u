import { get, put } from '@/utils/request';
import type { JENSResponse, SensorConfig } from './types';

/**
 * 获取传感器配置
 * 对应API设计文档: 5.1 获取传感器配置 GET /api/sensor/config
 *
 * @returns 传感器配置
 */
export function getSensorConfig(): Promise<JENSResponse<SensorConfig>> {
  return get<JENSResponse<SensorConfig>>('/api/sensor/config');
}

/**
 * 更新传感器配置
 * 对应API设计文档: 5.2 更新传感器配置 PUT /api/sensor/config
 *
 * @param data 传感器配置
 * @returns 更新结果
 */
export function updateSensorConfig(data: Partial<SensorConfig>): Promise<JENSResponse<SensorConfig>> {
  return put<JENSResponse<SensorConfig>>('/api/sensor/config', data);
}

/**
 * 生成模拟数据
 * 对应API设计文档: 5.3 生成模拟数据 GET /api/sensor/simulate
 *
 * @param seconds 模拟时间（秒）
 * @returns 模拟数据
 */
export function generateSimulationData(seconds: number = 60): Promise<JENSResponse<any>> {
  return get<JENSResponse<any>>('/api/sensor/simulate', { seconds });
} 