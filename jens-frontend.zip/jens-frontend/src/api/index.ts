// 导出所有API模块
export * from './auth';
export * from './user';
export * from './activity';
export * from './sensor';
export * from './carbonFactor';
export * from './prize';
export * from './achievement';
export * from './types';

// 导出请求工具
export { default as request } from '@/utils/request';
export { get, post, put, del } from '@/utils/request'; 