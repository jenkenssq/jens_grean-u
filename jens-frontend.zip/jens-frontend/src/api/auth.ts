import { get, post } from '@/utils/request';
import type { JENSResponse, LoginRequest, RegisterRequest, AuthResponse } from './types';

/**
 * 用户登录
 *
 * @param data 登录参数
 * @returns 认证信息
 */
export function login(data: LoginRequest): Promise<JENSResponse<AuthResponse> | AuthResponse> {
  return post<JENSResponse<AuthResponse> | AuthResponse>('/api/user/login', data);
}

/**
 * 用户注册
 *
 * @param data 注册参数
 * @returns 注册结果
 */
export function register(data: RegisterRequest): Promise<JENSResponse<any>> {
  return post<JENSResponse<any>>('/api/user/register', data);
}

/**
 * 获取当前用户信息
 * 注意：文档中这个接口是在/api/user/info路径下，已移至user.ts中
 */

/**
 * 退出登录
 * 注意：API设计文档未定义此接口
 */
export function logout(): Promise<JENSResponse<any>> {
  // 实际可能需要自定义实现，例如清除本地token等
  return Promise.resolve({
    code: 200,
    message: '注销成功',
    data: null,
    timestamp: Date.now()
  });
} 