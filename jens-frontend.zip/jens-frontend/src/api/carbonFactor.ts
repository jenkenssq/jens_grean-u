import { get, post, put, del } from '@/utils/request';
import type { JENSResponse, CarbonFactor, PageRequest, PageResult } from './types';

/**
 * 获取所有启用的碳因子
 * 对应API设计文档: 2.5 获取碳减排因子列表 GET /api/activity/factors
 *
 * @returns 碳因子列表
 */
export function getAllEnabledFactors(): Promise<JENSResponse<CarbonFactor[]>> {
  return get<JENSResponse<CarbonFactor[]>>('/api/activity/factors');
}

// 以下API在设计文档中没有明确定义，是管理后台扩展功能

/**
 * 分页查询碳因子（管理后台扩展API，文档中未定义）
 *
 * @param params 分页参数
 * @returns 分页结果
 */
export function getCarbonFactorPage(params: PageRequest): Promise<JENSResponse<PageResult<CarbonFactor>>> {
  return get<JENSResponse<PageResult<CarbonFactor>>>('/api/carbon-factor/page', params);
}

/**
 * 根据ID获取碳因子（管理后台扩展API，文档中未定义）
 *
 * @param id 碳因子ID
 * @returns 碳因子
 */
export function getCarbonFactorById(id: number): Promise<JENSResponse<CarbonFactor>> {
  return get<JENSResponse<CarbonFactor>>(`/api/carbon-factor/${id}`);
}

/**
 * 新增碳因子（管理后台扩展API，文档中未定义）
 *
 * @param data 碳因子数据
 * @returns 新增结果
 */
export function addCarbonFactor(data: Partial<CarbonFactor>): Promise<JENSResponse<any>> {
  return post<JENSResponse<any>>('/api/carbon-factor', data);
}

/**
 * 更新碳因子（管理后台扩展API，文档中未定义）
 *
 * @param id 碳因子ID
 * @param data 碳因子数据
 * @returns 更新结果
 */
export function updateCarbonFactor(id: number, data: Partial<CarbonFactor>): Promise<JENSResponse<any>> {
  return put<JENSResponse<any>>(`/api/carbon-factor/${id}`, data);
}

/**
 * 删除碳因子（管理后台扩展API，文档中未定义）
 *
 * @param id 碳因子ID
 * @returns 删除结果
 */
export function deleteCarbonFactor(id: number): Promise<JENSResponse<any>> {
  return del<JENSResponse<any>>(`/api/carbon-factor/${id}`);
} 