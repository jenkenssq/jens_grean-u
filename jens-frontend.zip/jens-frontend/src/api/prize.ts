import { get, post } from '@/utils/request';
import type { JENSResponse, PageResult } from './types';

/**
 * 获取奖品列表
 * 对应API设计文档: 3.1 获取奖品列表 GET /api/prize/list
 *
 * @param params 查询参数
 * @returns 奖品列表
 */
export function getPrizeList(params?: {
  prizeType?: number;
  page?: number;
  pageSize?: number;
}): Promise<JENSResponse<PageResult<any>>> {
  return get<JENSResponse<PageResult<any>>>('/api/prize/list', params);
}

/**
 * 获取奖品详情
 * 对应API设计文档: 3.2 获取奖品详情 GET /api/prize/{prizeId}
 *
 * @param prizeId 奖品ID
 * @returns 奖品详情
 */
export function getPrizeDetail(prizeId: number): Promise<JENSResponse<any>> {
  return get<JENSResponse<any>>(`/api/prize/${prizeId}`);
}

/**
 * 兑换奖品
 * 对应API设计文档: 3.3 兑换奖品 POST /api/prize/exchange
 *
 * @param data 兑换参数
 * @returns 兑换结果
 */
export function exchangePrize(data: {
  prizeId: number;
  count: number;
  address?: string;
  contactPhone?: string;
  remark?: string;
}): Promise<JENSResponse<any>> {
  return post<JENSResponse<any>>('/api/prize/exchange', data);
}

/**
 * 获取用户兑换记录
 * 对应API设计文档: 3.4 获取用户兑换记录 GET /api/prize/exchanges
 *
 * @param params 查询参数
 * @returns 兑换记录列表
 */
export function getExchangeRecords(params?: {
  status?: number;
  page?: number;
  pageSize?: number;
}): Promise<JENSResponse<PageResult<any>>> {
  return get<JENSResponse<PageResult<any>>>('/api/prize/exchanges', params);
}

/**
 * 获取兑换记录详情
 * 对应API设计文档: 3.5 获取兑换记录详情 GET /api/prize/exchange/{exchangeId}
 *
 * @param exchangeId 兑换记录ID
 * @returns 兑换记录详情
 */
export function getExchangeDetail(exchangeId: number): Promise<JENSResponse<any>> {
  return get<JENSResponse<any>>(`/api/prize/exchange/${exchangeId}`);
}

/**
 * 取消兑换申请
 * 对应API设计文档: 3.6 取消兑换申请 POST /api/prize/exchange/{exchangeId}/cancel
 *
 * @param exchangeId 兑换记录ID
 * @param reason 取消原因
 * @returns 取消结果
 */
export function cancelExchange(exchangeId: number, reason: string): Promise<JENSResponse<any>> {
  return post<JENSResponse<any>>(`/api/prize/exchange/${exchangeId}/cancel`, { reason });
} 