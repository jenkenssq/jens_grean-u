import { get, post, put } from '@/utils/request';
import type { JENSResponse, UserInfo } from './types';

/**
 * 获取当前用户信息
 * 对应API设计文档: 1.3 获取用户信息 GET /api/user/info
 *
 * @returns 用户信息
 */
export function getCurrentUser(): Promise<JENSResponse<UserInfo>> {
  return get<JENSResponse<UserInfo>>('/api/user/info');
}

/**
 * 更新用户信息
 * 对应API设计文档: 1.4 更新用户信息 PUT /api/user/info
 *
 * @param data 用户信息
 * @returns 更新结果
 */
export function updateUserInfo(data: Partial<UserInfo>): Promise<JENSResponse<any>> {
  return put<JENSResponse<any>>('/api/user/info', data);
}

/**
 * 更新用户密码（扩展API，文档中未定义）
 *
 * @param oldPassword 旧密码
 * @param newPassword 新密码
 * @returns 更新结果
 */
export function updatePassword(oldPassword: string, newPassword: string): Promise<JENSResponse<any>> {
  return put<JENSResponse<any>>('/api/user/password', { oldPassword, newPassword });
}

/**
 * 获取用户统计数据（扩展API，文档中未定义）
 * 可能对应API设计文档中的2.4 获取活动统计数据
 *
 * @returns 用户统计数据
 */
export function getUserStats(): Promise<JENSResponse<any>> {
  return get<JENSResponse<any>>('/api/activity/stats');
}

/**
 * 获取用户碳积分统计（扩展API，文档中未定义）
 *
 * @param params 查询参数
 * @returns 碳积分统计信息
 */
export function getCarbonStats(params?: { period?: string }): Promise<JENSResponse<any>> {
  return get<JENSResponse<any>>('/api/user/carbon-stats', params);
}

/**
 * 获取用户积分信息
 * 对应用户积分查询接口
 *
 * @returns 用户积分信息
 */
export function getUserPoints(): Promise<JENSResponse<{points: number}>> {
  return get<JENSResponse<{points: number}>>('/api/user/points');
}

/**
 * 上传用户头像
 * 
 * @param formData FormData对象，包含文件字段file
 * @returns 上传结果，包含头像URL
 */
export function uploadAvatar(formData: FormData): Promise<JENSResponse<{avatarUrl: string}>> {
  return post<JENSResponse<{avatarUrl: string}>>('/api/user/avatar', formData, {
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  });
} 