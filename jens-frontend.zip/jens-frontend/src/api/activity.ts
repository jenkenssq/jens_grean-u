import { get, post } from '@/utils/request';
import type { JENSResponse, ActivityRecord, PageRequest, PageResult } from './types';

/**
 * 获取活动记录列表
 * 对应API设计文档: 2.1 获取活动记录列表 GET /api/activity/records
 *
 * @param params 查询参数
 * @returns 活动记录列表
 */
export function getActivityRecords(params?: {
  activityType?: string; 
  page?: number;
  pageSize?: number;
}): Promise<JENSResponse<PageResult<ActivityRecord>>> {
  return get<JENSResponse<PageResult<ActivityRecord>>>('/api/activity/records', params);
}

/**
 * 获取活动记录详情
 * 对应API设计文档: 2.2 获取活动记录详情 GET /api/activity/record/{recordId}
 *
 * @param recordId 活动记录ID
 * @returns 活动记录详情
 */
export function getActivityRecord(recordId: number): Promise<JENSResponse<any>> {
  return get<JENSResponse<any>>(`/api/activity/record/${recordId}`);
}

/**
 * 提交活动记录
 * 对应API设计文档: 2.3 提交活动记录 POST /api/activity/record
 *
 * @param data 活动记录数据
 * @returns 提交结果
 */
export function submitActivityRecord(data: any): Promise<JENSResponse<any>> {
  return post<JENSResponse<any>>('/api/activity/record', data);
}

/**
 * 预估活动奖励
 * 根据活动类型、时长和距离等预估减碳量和积分奖励
 *
 * @param data 活动数据
 * @returns 预估结果
 */
export function estimateActivityReward(data: {
  activityType: string;
  distance: number;
  duration: number;
}): Promise<JENSResponse<{
  carbonReduced: number;
  pointsEarned: number;
}>> {
  return post<JENSResponse<{
    carbonReduced: number;
    pointsEarned: number;
  }>>('/api/activity/estimate', data);
}

/**
 * 获取活动统计数据
 * 对应API设计文档: 2.4 获取活动统计数据 GET /api/activity/stats
 *
 * @param timeRange 时间范围（day/week/month/year，默认week）
 * @returns 统计数据
 */
export function getActivityStats(timeRange: string = 'week'): Promise<JENSResponse<any>> {
  return get<JENSResponse<any>>('/api/activity/stats', { timeRange });
}

/**
 * 获取碳减排因子列表
 * 对应API设计文档: 2.5 获取碳减排因子列表 GET /api/activity/factors
 * 
 * 注：该方法已在carbonFactor.ts中实现为getAllEnabledFactors()
 */ 