/**
 * 标准API响应格式
 */
export interface JENSResponse<T> {
  code: number;
  message: string;
  data: T;
  timestamp: number;
}

/**
 * 登录请求参数
 */
export interface LoginRequest {
  username: string;
  password: string;
}

/**
 * 注册请求参数
 */
export interface RegisterRequest {
  username: string;
  password: string;
  email?: string;
  phone?: string;
  mobile?: string;
  nickname?: string;
}

/**
 * 认证结果
 */
export interface AuthResponse {
  token: string;
  userId: number;
  username: string;
  nickname: string;
  avatar?: string;
}

/**
 * 用户信息
 */
export interface UserInfo {
  userId: number;
  username: string;
  nickname: string;
  avatar?: string;
  email?: string;
  phone?: string;
  mobile?: string;
  gender?: number;
  birthday?: string;
  totalCarbon: number;
  carbonPoints: number;
  totalPoints: number;
  status?: number;
  createTime?: string;
  updateTime?: string;
}

/**
 * 分页请求参数
 */
export interface PageRequest {
  current: number;
  size: number;
  orderField?: string;
  isAsc?: boolean;
}

/**
 * 分页结果
 */
export interface PageResult<T> {
  total: number;
  pages: number;
  current: number;
  records: T[];
}

/**
 * 活动记录
 */
export interface ActivityRecord {
  id: number;
  userId: number;
  activityType: string;
  startTime: string;
  endTime: string;
  duration: number;
  distance: number;
  steps: number;
  calories: number;
  carbonReduced: number;
  pointsEarned: number;
  status: number;
  createTime: string;
}

/**
 * 传感器配置
 */
export interface SensorConfig {
  locationEnabled: boolean;
  motionEnabled: boolean;
  heartRateEnabled: boolean;
  noiseValue: number;
  updateInterval: number;
  simulationMode: number;
  activityType: string;
}

/**
 * 碳因子
 */
export interface CarbonFactor {
  id: number;
  activityType: string;
  factorName: string;
  factorValue: number;
  unit: string;
  description: string;
  status: number;
} 