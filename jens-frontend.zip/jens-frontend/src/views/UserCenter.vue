<template>
  <div class="user-center-container">
    <el-card class="user-profile-card">
      <template #header>
        <div class="card-header">
          <h2>个人中心</h2>
        </div>
      </template>
      
      <el-row :gutter="20">
        <el-col :span="8">
          <div class="user-avatar-section">
            <div class="avatar-upload">
              <el-avatar :size="120" :src="userInfo.avatar ? (userInfo.avatar.startsWith('http') ? userInfo.avatar : API_BASE_URL + userInfo.avatar) : defaultAvatar"></el-avatar>
              <div class="avatar-upload-mask" @click="triggerAvatarUpload">
                <el-icon><Upload /></el-icon>
                <span>更换头像</span>
              </div>
            </div>
            <input
              type="file"
              ref="avatarInputRef"
              @change="handleAvatarChange"
              accept="image/*"
              style="display: none"
            />
            <h3>{{ userInfo.nickname || userInfo.username || '用户' }}</h3>
            <p class="user-role">{{ userRoleName }}</p>
            <el-progress 
              type="circle" 
              :percentage="carbonProgressPercentage" 
              :color="customColors"
              status="success"
              :stroke-width="10"
              :width="100"
            ></el-progress>
            <p class="carbon-progress-info">碳减排进度</p>
          </div>
        </el-col>
        
        <el-col :span="16">
          <el-tabs v-model="activeTab">
            <el-tab-pane label="基本信息" name="profile">
              <div v-if="!isEditing">
                <!-- 只读信息表单 -->
                <el-descriptions title="个人基本信息" :column="1" border>
                  <el-descriptions-item label="用户名">{{ userInfo.username }}</el-descriptions-item>
                  <el-descriptions-item label="昵称">{{ userInfo.nickname }}</el-descriptions-item>
                  <el-descriptions-item label="手机号">{{ userInfo.phone }}</el-descriptions-item>
                  <el-descriptions-item label="邮箱">{{ userInfo.email }}</el-descriptions-item>
                  <el-descriptions-item label="性别">
                    {{ userInfo.gender === 1 ? '男' : (userInfo.gender === 2 ? '女' : '保密') }}
                  </el-descriptions-item>
                  <el-descriptions-item label="出生日期">
                    {{ userInfo.birthday ? userInfo.birthday : '未设置' }}
                  </el-descriptions-item>
                </el-descriptions>
                
                <div style="margin-top: 20px; text-align: center;">
                  <el-button type="primary" @click="startEditing">编辑信息</el-button>
                </div>
              </div>

              <div v-else>
                <!-- 编辑表单 -->
                <el-form :model="userFormData" label-width="100px">
                  <el-form-item label="用户名">
                    <el-input v-model="userFormData.username" disabled></el-input>
                  </el-form-item>
                  <el-form-item label="昵称">
                    <el-input v-model="userFormData.nickname"></el-input>
                  </el-form-item>
                  <el-form-item label="手机号">
                    <el-input v-model="userFormData.phone"></el-input>
                  </el-form-item>
                  <el-form-item label="邮箱">
                    <el-input v-model="userFormData.email"></el-input>
                  </el-form-item>
                  <el-form-item label="性别">
                    <el-select v-model="userFormData.gender" placeholder="请选择性别">
                      <el-option label="男" :value="1"></el-option>
                      <el-option label="女" :value="2"></el-option>
                      <el-option label="保密" :value="0"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="出生日期">
                    <el-date-picker v-model="userFormData.birthday" type="date" placeholder="选择日期"></el-date-picker>
                  </el-form-item>
                  <el-form-item>
                    <el-button type="success" @click="saveUserInfo">保存</el-button>
                    <el-button @click="cancelEditing">取消</el-button>
                  </el-form-item>
                </el-form>
              </div>
            </el-tab-pane>
            
            <el-tab-pane label="积分信息" name="points">
              <el-descriptions border :column="1">
                <el-descriptions-item label="当前积分">
                  <el-text type="primary" size="large">{{ userInfo.carbonPoints }} 分</el-text>
                </el-descriptions-item>
                <el-descriptions-item label="累计积分">
                  <el-text type="info" size="large">{{ userInfo.totalPoints }} 分</el-text>
                </el-descriptions-item>
                <el-descriptions-item label="累计减碳量">
                  <el-text type="success" size="large">{{ userInfo.totalCarbon }} kg</el-text>
                </el-descriptions-item>
                <el-descriptions-item label="积分排名">
                  <el-text size="large">{{ pointsRank }}</el-text>
                </el-descriptions-item>
              </el-descriptions>
              
              <div class="points-actions">
                <el-divider content-position="center">积分操作</el-divider>
                <el-button type="primary" @click="$router.push('/prize')">积分兑换</el-button>
                <el-button type="success" @click="$router.push('/activity-submit')">获取更多积分</el-button>
                <el-button type="warning" @click="$router.push('/carbon-points-table')">出行方式-积分对照表</el-button>
              </div>
            </el-tab-pane>
            
            <el-tab-pane label="个人成就" name="achievements">
              <div class="achievements-container">
                <div class="achievements-stats">
                  <el-card shadow="hover" class="stats-card">
                    <div class="stats-info">
                      <div class="stat-item">
                        <h4>获得成就</h4>
                        <div class="stat-value">{{ achievementStats.achievedCount || 0 }}</div>
                        <div class="stat-desc">/ {{ achievementStats.totalAchievements || 0 }} 总成就</div>
                      </div>
                      <div class="progress-bar">
                        <el-progress 
                          :percentage="achievementCompletionRate" 
                          :format="formatProgressPercentage"
                          :color="customColors">
                        </el-progress>
                      </div>
                    </div>
                    <div class="stats-actions">
                      <el-button type="primary" @click="activeTab = 'achievements'">查看所有成就</el-button>
                    </div>
                  </el-card>
                </div>

                <h3 class="section-title">已获得的成就</h3>
                <div v-loading="achievementsLoading" class="achievements-grid">
                  <div v-if="userAchievements.length === 0" class="no-achievements">
                    <el-empty description="暂无已获得的成就"></el-empty>
                  </div>
                  <div v-else class="achievements-list">
                    <el-row :gutter="20">
                      <el-col :xs="12" :sm="8" :md="6" v-for="achievement in userAchievements.filter(a => a.isAchieved)" :key="achievement.id">
                        <el-card shadow="hover" class="achievement-card" @click="showAchievementDetail(achievement)">
                          <div class="achievement-icon">
                            <el-avatar :size="60" :src="achievement.icon || defaultAchievementIcon" />
                            <div v-if="achievement.isAchieved" class="achieved-badge">
                              <el-icon><Check /></el-icon>
                            </div>
                          </div>
                          <div class="achievement-info">
                            <h4>{{ achievement.name }}</h4>
                            <p>{{ achievement.description }}</p>
                            <div class="achievement-points">
                              <el-tag size="small" type="success">+{{ achievement.pointsReward }} 积分</el-tag>
                            </div>
                            <div v-if="achievement.isAchieved" class="achievement-date">
                              {{ formatDate(achievement.achievedTime) }}
                            </div>
                          </div>
                        </el-card>
                      </el-col>
                    </el-row>
                  </div>
                </div>

                <el-divider></el-divider>

                <h3 class="section-title">未获得的成就</h3>
                <div v-loading="achievementsLoading" class="achievements-grid">
                  <div v-if="userAchievements.filter(a => !a.isAchieved).length === 0" class="no-achievements">
                    <el-empty description="恭喜！您已获得所有成就"></el-empty>
                  </div>
                  <div v-else class="achievements-list">
                    <el-row :gutter="20">
                      <el-col :xs="12" :sm="8" :md="6" v-for="achievement in userAchievements.filter(a => !a.isAchieved)" :key="achievement.id">
                        <el-card shadow="hover" class="achievement-card gray-filter" @click="showAchievementDetail(achievement)">
                          <div class="achievement-icon">
                            <el-avatar :size="60" :src="achievement.icon || defaultAchievementIcon" />
                          </div>
                          <div class="achievement-info">
                            <h4>{{ achievement.name }}</h4>
                            <p>{{ achievement.description }}</p>
                            <div class="achievement-points">
                              <el-tag size="small" type="info">+{{ achievement.pointsReward }} 积分</el-tag>
                            </div>
                          </div>
                        </el-card>
                      </el-col>
                    </el-row>
                  </div>
                </div>
              </div>
            </el-tab-pane>
            
            <el-tab-pane label="安全设置" name="security">
              <el-form label-width="100px">
                <el-form-item label="修改密码">
                  <el-button type="primary" @click="showChangePasswordDialog">修改密码</el-button>
                </el-form-item>
                <el-form-item label="绑定手机">
                  <div v-if="userInfo.phone">
                    {{ maskPhoneNumber(userInfo.phone) }}
                    <el-button type="primary" size="small" style="margin-left: 10px;">更换手机</el-button>
                  </div>
                  <el-button v-else type="primary">绑定手机</el-button>
                </el-form-item>
                <el-form-item label="绑定邮箱">
                  <div v-if="userInfo.email">
                    {{ maskEmail(userInfo.email) }}
                    <el-button type="primary" size="small" style="margin-left: 10px;">更换邮箱</el-button>
                  </div>
                  <el-button v-else type="primary">绑定邮箱</el-button>
                </el-form-item>
                <el-form-item label="退出登录">
                  <el-button type="danger" @click="handleLogout">退出登录</el-button>
                </el-form-item>
              </el-form>
            </el-tab-pane>
          </el-tabs>
        </el-col>
      </el-row>
    </el-card>
    
    <!-- 修改密码对话框 -->
    <el-dialog v-model="passwordDialogVisible" title="修改密码" width="30%">
      <el-form :model="passwordForm" :rules="passwordRules" ref="passwordFormRef" label-width="100px">
        <el-form-item label="当前密码" prop="oldPassword">
          <el-input v-model="passwordForm.oldPassword" type="password" show-password></el-input>
        </el-form-item>
        <el-form-item label="新密码" prop="newPassword">
          <el-input v-model="passwordForm.newPassword" type="password" show-password></el-input>
        </el-form-item>
        <el-form-item label="确认密码" prop="confirmPassword">
          <el-input v-model="passwordForm.confirmPassword" type="password" show-password></el-input>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="passwordDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="handleUpdatePassword">确认修改</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 成就详情对话框 -->
    <el-dialog v-model="achievementDetailVisible" title="成就详情" width="30%">
      <div v-if="currentAchievement" class="achievement-detail">
        <div class="achievement-detail-header">
          <el-avatar :size="80" :src="currentAchievement.icon || defaultAchievementIcon"></el-avatar>
          <div class="achievement-status">
            <el-tag v-if="currentAchievement.isAchieved" type="success">已获得</el-tag>
            <el-tag v-else type="info">未获得</el-tag>
          </div>
        </div>
        <h3>{{ currentAchievement.name }}</h3>
        <p class="achievement-description">{{ currentAchievement.description }}</p>
        
        <el-divider></el-divider>
        
        <el-descriptions :column="1" border>
          <el-descriptions-item label="奖励积分">
            <el-tag type="success">+{{ currentAchievement.pointsReward }}</el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="难度级别">
            <el-rate
              v-model="currentAchievement.difficultyLevel"
              disabled
              :max="5"
              text-color="#ff9900"
            ></el-rate>
          </el-descriptions-item>
          <el-descriptions-item v-if="currentAchievement.isAchieved" label="获得时间">
            {{ formatDateTime(currentAchievement.achievedTime) }}
          </el-descriptions-item>
        </el-descriptions>
      </div>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue';
import { ElMessage } from 'element-plus';
import { getCurrentUser, updateUserInfo, updatePassword, uploadAvatar } from '@/api/user';
import { getUserAchievements, getAchievementStats, getAchievementDetail } from '@/api/achievement';
import { logoutAndRefresh } from '@/utils/auth';
import defaultAvatar from '@/assets/default-avatar.png';
import { Check, Upload } from '@element-plus/icons-vue';
import { useRouter } from 'vue-router';
import service from '@/utils/request';

const activeTab = ref('profile');
const isEditing = ref(false);
const passwordDialogVisible = ref(false);
const passwordFormRef = ref();
const pointsRank = ref('--');

// API基础URL（从axios配置中获取）
const API_BASE_URL = service.defaults.baseURL || 'http://localhost:8080';

// 默认成就图标
const defaultAchievementIcon = 'https://cdn-icons-png.flaticon.com/512/3176/3176516.png';

// 默认用户信息
const userInfo = reactive({
  userId: 0,
  username: '',
  nickname: '',
  phone: '',
  email: '',
  gender: 0,
  birthday: '',
  avatar: '',
  carbonPoints: 0,
  totalPoints: 0,
  totalCarbon: 0,
  roles: [] as string[]
});

// 用户表单数据
const userFormData = reactive({
  username: '',
  nickname: '',
  phone: '',
  email: '',
  gender: 0,
  birthday: ''
});

// 成就相关数据
const userAchievements = ref<any[]>([]);
const achievementsLoading = ref(false);
const achievementStats = reactive({
  totalAchievements: 0,
  achievedCount: 0,
  completionRate: 0,
  totalPointsEarned: 0,
  achievementsByType: {} as Record<string, number>
});

// 成就详情
const achievementDetailVisible = ref(false);
const currentAchievement = ref<any>(null);

// 密码修改表单
const passwordForm = reactive({
  oldPassword: '',
  newPassword: '',
  confirmPassword: ''
});

// 密码校验规则
const validateConfirmPassword = (rule: any, value: string, callback: any) => {
  if (value === '') {
    callback(new Error('请再次输入密码'));
  } else if (value !== passwordForm.newPassword) {
    callback(new Error('两次输入密码不一致'));
  } else {
    callback();
  }
};

const passwordRules = {
  oldPassword: [
    { required: true, message: '请输入当前密码', trigger: 'blur' }
  ],
  newPassword: [
    { required: true, message: '请输入新密码', trigger: 'blur' },
    { min: 6, max: 20, message: '密码长度应为6到20个字符', trigger: 'blur' }
  ],
  confirmPassword: [
    { required: true, message: '请再次输入密码', trigger: 'blur' },
    { validator: validateConfirmPassword, trigger: 'blur' }
  ]
};

// 自定义颜色
const customColors = [
  { color: '#f56c6c', percentage: 20 },
  { color: '#e6a23c', percentage: 40 },
  { color: '#5cb87a', percentage: 60 },
  { color: '#1989fa', percentage: 80 },
  { color: '#6f7ad3', percentage: 100 }
];

// 计算用户角色名称
const userRoleName = computed(() => {
  if (!userInfo.roles || userInfo.roles.length === 0) {
    return '普通用户';
  }
  
  if (userInfo.roles.includes('admin')) {
    return '管理员';
  } else if (userInfo.roles.includes('user')) {
    return '普通用户';
  }
  
  return userInfo.roles[0];
});

// 计算碳减排进度百分比（示例，实际应根据用户目标计算）
const carbonProgressPercentage = computed(() => {
  const carbonTarget = 100; // 假设目标为100kg
  const current = userInfo.totalCarbon || 0;
  const percentage = Math.min(Math.round((current / carbonTarget) * 100), 100);
  return percentage;
});

// 计算成就完成率
const achievementCompletionRate = computed(() => {
  if (!achievementStats.totalAchievements) return 0;
  const rate = (achievementStats.achievedCount / achievementStats.totalAchievements) * 100;
  return Math.min(Math.round(rate), 100);
});

// 格式化进度百分比
const formatProgressPercentage = (percentage: number) => {
  return `${percentage}%`;
};

// 格式化日期
const formatDate = (dateStr: string) => {
  if (!dateStr) return '未知时间';
  const date = new Date(dateStr);
  return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
};

// 格式化日期时间
const formatDateTime = (dateStr: string) => {
  if (!dateStr) return '未知时间';
  const date = new Date(dateStr);
  return `${date.getFullYear()}-${padZero(date.getMonth() + 1)}-${padZero(date.getDate())} ${padZero(date.getHours())}:${padZero(date.getMinutes())}`;
};

// 补零
const padZero = (num: number) => {
  return num < 10 ? `0${num}` : num;
};

// 获取用户信息
const fetchUserInfo = async () => {
  try {
    console.log('开始获取用户信息...');
    const response = await getCurrentUser();
    console.log('原始响应:', response);
    
    if (response && response.code === 200) {
      const userData = response.data;
      console.log('用户数据:', userData);
      
      if (userData) {
        // 更新用户信息
        Object.assign(userInfo, userData);
        
        // 复制数据到表单
        Object.assign(userFormData, {
          username: userData.username,
          nickname: userData.nickname,
          phone: userData.phone,
          email: userData.email,
          gender: userData.gender,
          birthday: userData.birthday
        });
        
        // 获取用户排名（模拟数据，实际应从API获取）
        pointsRank.value = `${Math.floor(Math.random() * 100) + 1}`;
      } else {
        console.error('响应中缺少用户数据');
        ElMessage.warning('获取用户信息失败: 响应数据为空');
      }
    } else {
      console.error('响应格式错误或状态码非200:', response);
      ElMessage.warning('获取用户信息失败: ' + (response?.message || '未知错误'));
    }
  } catch (error: any) {
    console.error('获取用户信息错误:', error);
    ElMessage.error('获取用户信息失败: ' + (error.message || '未知错误'));
  }
};

// 获取用户成就
const fetchUserAchievements = async () => {
  achievementsLoading.value = true;
  try {
    const res = await getUserAchievements();
    if (res.code === 200 && res.data) {
      userAchievements.value = res.data;
    } else {
      ElMessage.warning('获取成就列表失败: ' + (res.message || '未知错误'));
      userAchievements.value = [];
    }
  } catch (error: any) {
    console.error('获取用户成就错误:', error);
    ElMessage.error('获取成就列表失败: ' + (error.message || '未知错误'));
    userAchievements.value = [];
  } finally {
    achievementsLoading.value = false;
  }
};

// 获取成就统计数据
const fetchAchievementStats = async () => {
  try {
    const res = await getAchievementStats();
    if (res.code === 200 && res.data) {
      Object.assign(achievementStats, res.data);
    } else {
      ElMessage.warning('获取成就统计失败: ' + (res.message || '未知错误'));
    }
  } catch (error: any) {
    console.error('获取成就统计错误:', error);
    ElMessage.error('获取成就统计失败: ' + (error.message || '未知错误'));
  }
};

// 显示成就详情
const showAchievementDetail = async (achievement: any) => {
  currentAchievement.value = achievement;
  achievementDetailVisible.value = true;
  
  // 如果需要获取额外详情，可以调用getAchievementDetail接口
  try {
    const res = await getAchievementDetail(achievement.id);
    if (res.code === 200 && res.data) {
      // 合并额外的详情数据
      currentAchievement.value = {
        ...currentAchievement.value,
        ...res.data.achievement,
        isAchieved: res.data.isAchieved,
        achievedTime: res.data.achievedTime
      };
    }
  } catch (error) {
    console.error('获取成就详情失败:', error);
  }
};

// 开始编辑
const startEditing = () => {
  console.log('开始编辑，之前isEditing状态:', isEditing.value);
  isEditing.value = true;
  console.log('设置isEditing为:', isEditing.value);
  
  // 添加延迟检查，确认状态已正确更新
  setTimeout(() => {
    console.log('延迟检查isEditing状态:', isEditing.value);
  }, 100);
};

// 取消编辑
const cancelEditing = () => {
  console.log('取消编辑，之前isEditing状态:', isEditing.value);
  isEditing.value = false;
  console.log('设置isEditing为:', isEditing.value);
  
  // 恢复原始数据
  Object.assign(userFormData, {
    username: userInfo.username,
    nickname: userInfo.nickname,
    phone: userInfo.phone,
    email: userInfo.email,
    gender: userInfo.gender,
    birthday: userInfo.birthday
  });
};

// 保存用户信息
const saveUserInfo = async () => {
  console.log('保存用户信息，当前表单数据:', userFormData);
  try {
    const res = await updateUserInfo(userFormData);
    console.log('用户信息更新响应:', res);
    if (res.code === 200) {
      ElMessage.success('用户信息更新成功');
      // 更新本地用户信息
      Object.assign(userInfo, userFormData);
      // 重置编辑状态
      isEditing.value = false;
      console.log('保存完成，设置isEditing为:', isEditing.value);
      // 刷新用户信息
      fetchUserInfo();
    } else {
      ElMessage.warning('用户信息更新失败: ' + (res.message || '未知错误'));
    }
  } catch (error: any) {
    console.error('更新用户信息错误:', error);
    ElMessage.error('更新用户信息失败: ' + (error.message || '未知错误'));
  }
};

// 显示修改密码对话框
const showChangePasswordDialog = () => {
  passwordDialogVisible.value = true;
  // 重置密码表单
  passwordForm.oldPassword = '';
  passwordForm.newPassword = '';
  passwordForm.confirmPassword = '';
};

// 修改密码
const handleUpdatePassword = () => {
  passwordFormRef.value.validate(async (valid: boolean) => {
    if (!valid) {
      return;
    }
    
    try {
      const res = await updatePassword(passwordForm.oldPassword, passwordForm.newPassword);
      if (res.code === 200) {
        ElMessage.success('密码修改成功');
        passwordDialogVisible.value = false;
      } else {
        ElMessage.warning('密码修改失败: ' + (res.message || '未知错误'));
      }
    } catch (error: any) {
      console.error('修改密码错误:', error);
      ElMessage.error('修改密码失败: ' + (error.message || '未知错误'));
    }
  });
};

// 手机号脱敏显示
const maskPhoneNumber = (phone: string) => {
  if (!phone || phone.length < 11) return phone;
  return phone.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2');
};

// 邮箱脱敏显示
const maskEmail = (email: string) => {
  if (!email || !email.includes('@')) return email;
  const [username, domain] = email.split('@');
  const maskedUsername = username.length > 2 
    ? username.substring(0, 2) + '****'
    : username + '****';
  return `${maskedUsername}@${domain}`;
};

// 退出登录处理
const handleLogout = () => {
  ElMessage.success('已退出登录');
  logoutAndRefresh();
};

// 修改引用变量名称以匹配模板中的ref
const avatarInputRef = ref<HTMLInputElement | null>(null);

// 触发头像上传
const triggerAvatarUpload = () => {
  if (avatarInputRef.value) {
    avatarInputRef.value.click();
  } else {
    console.error('未找到头像上传输入元素');
    ElMessage.error('头像上传功能初始化失败');
  }
};

// 处理头像变更
const handleAvatarChange = async (event: Event) => {
  const target = event.target as HTMLInputElement;
  const file = target.files?.[0];
  
  if (!file) {
    console.error('没有选择文件');
    return;
  }
  
  // 验证文件类型
  if (!file.type.startsWith('image/')) {
    ElMessage.error('请上传图片文件');
    return;
  }
  
  // 验证文件大小（限制为2MB）
  if (file.size > 2 * 1024 * 1024) {
    ElMessage.error('图片大小不能超过2MB');
    return;
  }
  
  // 准备表单数据
  const formData = new FormData();
  formData.append('file', file);
  console.log('准备上传文件:', file.name, file.type, file.size);
  
  try {
    console.log('开始上传头像...');
    const response = await uploadAvatar(formData);
    console.log('头像上传响应:', response);
    
    if (response && response.code === 200 && response.data) {
      ElMessage.success('头像上传成功');
      // 修复类型错误，确保正确处理返回的头像数据
      userInfo.avatar = typeof response.data === 'string' ? response.data : (response.data.avatarUrl || '');
      console.log('更新头像URL:', userInfo.avatar);
      console.log('完整头像URL:', userInfo.avatar.startsWith('http') ? userInfo.avatar : API_BASE_URL + userInfo.avatar);
      // 刷新用户信息
      await fetchUserInfo();
    } else {
      console.error('头像上传失败:', response);
      ElMessage.error('头像上传失败: ' + (response?.message || '未知错误'));
    }
  } catch (error: any) {
    console.error('头像上传出错:', error);
    ElMessage.error('头像上传失败: ' + (error.message || '未知错误'));
  } finally {
    // 清空文件输入，以便下次选择同一个文件时仍能触发change事件
    if (avatarInputRef.value) {
      avatarInputRef.value.value = '';
    }
  }
};

// 组件挂载时获取用户信息和成就
onMounted(() => {
  // 检查URL中是否有tab参数
  const route = useRouter().currentRoute.value;
  if (route.query.tab) {
    const tabValue = route.query.tab as string;
    if (['profile', 'points', 'achievements', 'security'].includes(tabValue)) {
      activeTab.value = tabValue;
    }
  }
  
  fetchUserInfo();
  fetchUserAchievements();
  fetchAchievementStats();
});
</script>

<style scoped>
.user-center-container {
  padding: 20px;
  background-color: #f5f7fa;
  min-height: calc(100vh - 60px); /* 减去头部高度 */
}

.user-profile-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.user-avatar-section {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px 0;
}

.avatar-upload {
  position: relative;
  cursor: pointer;
}

.avatar-upload-mask {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  border-radius: 50%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: white;
  opacity: 0;
  transition: opacity 0.3s;
}

.avatar-upload:hover .avatar-upload-mask {
  opacity: 1;
}

.avatar-upload-mask span {
  margin-top: 5px;
  font-size: 12px;
}

.user-avatar-section h3 {
  margin: 10px 0 5px;
  font-size: 18px;
}

.user-role {
  color: #909399;
  margin-bottom: 20px;
}

.carbon-progress-info {
  margin-top: 10px;
  color: #67c23a;
  font-size: 14px;
}

.points-actions {
  margin-top: 20px;
  text-align: center;
}

.el-divider {
  margin: 20px 0;
}

/* 成就相关样式 */
.achievements-container {
  padding: 10px;
}

.achievements-stats {
  margin-bottom: 20px;
}

.stats-card {
  padding: 15px;
}

.stats-info {
  display: flex;
  flex-direction: column;
  margin-bottom: 15px;
}

.stat-item {
  display: flex;
  align-items: baseline;
  margin-bottom: 10px;
}

.stat-item h4 {
  margin: 0;
  margin-right: 10px;
  font-size: 16px;
  color: #606266;
}

.stat-value {
  font-size: 22px;
  font-weight: bold;
  color: #409eff;
  margin-right: 5px;
}

.stat-desc {
  font-size: 14px;
  color: #909399;
}

.progress-bar {
  margin-top: 5px;
}

.stats-actions {
  text-align: center;
}

.section-title {
  margin: 20px 0 15px;
  font-size: 18px;
  color: #303133;
  font-weight: 500;
}

.achievements-grid {
  min-height: 150px;
}

.achievements-list {
  margin-bottom: 20px;
}

.achievement-card {
  margin-bottom: 20px;
  height: 220px;
  display: flex;
  flex-direction: column;
  transition: all 0.3s;
  cursor: pointer;
}

.achievement-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.achievement-icon {
  display: flex;
  justify-content: center;
  position: relative;
  margin-bottom: 10px;
}

.achieved-badge {
  position: absolute;
  right: 0;
  bottom: 0;
  background-color: #67c23a;
  color: white;
  border-radius: 50%;
  width: 22px;
  height: 22px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.achievement-info {
  text-align: center;
}

.achievement-info h4 {
  margin: 10px 0 5px;
  font-size: 16px;
  color: #303133;
}

.achievement-info p {
  margin: 0 0 10px;
  font-size: 12px;
  color: #606266;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-overflow: ellipsis;
  height: 36px;
}

.achievement-points {
  margin-bottom: 5px;
}

.achievement-date {
  font-size: 12px;
  color: #909399;
}

.gray-filter {
  filter: grayscale(100%);
  opacity: 0.7;
}

.no-achievements {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 150px;
}

/* 成就详情样式 */
.achievement-detail {
  text-align: center;
}

.achievement-detail-header {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 15px;
}

.achievement-status {
  margin-top: 10px;
}

.achievement-detail h3 {
  margin: 15px 0 10px;
  font-size: 20px;
}

.achievement-description {
  color: #606266;
  margin-bottom: 20px;
}
</style> 