<template>
  <div class="prize-exchange-container">
    <!-- 头部信息 -->
    <el-card class="user-points-card">
      <el-row :gutter="20">
        <el-col :span="12">
          <div class="user-points-info">
            <h2>我的积分</h2>
            <div class="points-amount">
              <span class="points-number">{{ userPoints }}</span>
              <span class="points-unit">积分</span>
            </div>
          </div>
        </el-col>
        <el-col :span="12">
          <div class="points-actions">
            <el-button type="primary" icon="PriceTag" @click="$router.push('/activity-submit')">获取更多积分</el-button>
            <el-button type="success" icon="List" @click="showExchangeRecords">查看兑换记录</el-button>
          </div>
        </el-col>
      </el-row>
    </el-card>
    
    <!-- 分类标签 -->
    <div class="category-tabs">
      <el-tabs v-model="activeCategory" @tab-click="handleCategoryChange">
        <el-tab-pane label="全部奖品" name="all"></el-tab-pane>
        <el-tab-pane label="实物奖品" name="physical"></el-tab-pane>
        <el-tab-pane label="虚拟奖品" name="virtual"></el-tab-pane>
        <el-tab-pane label="优惠券" name="coupon"></el-tab-pane>
      </el-tabs>
    </div>
    
    <!-- 筛选和排序 -->
    <div class="filter-sort-bar">
      <el-space wrap>
        <el-radio-group v-model="sortBy" size="small" @change="handleSortChange">
          <el-radio-button label="popular">人气优先</el-radio-button>
          <el-radio-button label="newest">最新上架</el-radio-button>
          <el-radio-button label="priceAsc">积分从低到高</el-radio-button>
          <el-radio-button label="priceDesc">积分从高到低</el-radio-button>
        </el-radio-group>
        
        <el-checkbox v-model="onlyAffordable">只看可兑换</el-checkbox>
      </el-space>
    </div>
    
    <!-- 奖品列表 -->
    <div v-loading="loading" class="prize-list">
      <el-row :gutter="20">
        <el-col :xs="24" :sm="12" :md="8" :lg="6" v-for="prize in filteredPrizes" :key="prize.id">
          <el-card shadow="hover" class="prize-card">
            <div class="prize-image">
              <img 
                :src="prize.imageUrl || defaultPrizeImage" 
                :alt="prize.name"
                @error="handleImageError($event, prize)" 
              />
              <div v-if="prize.stock <= 0" class="out-of-stock">已售罄</div>
              <div v-else-if="prize.type === 'virtual'" class="prize-type virtual">虚拟奖品</div>
              <div v-else-if="prize.type === 'physical'" class="prize-type physical">实物奖品</div>
              <div v-else-if="prize.type === 'coupon'" class="prize-type coupon">优惠券</div>
            </div>
            <div class="prize-details">
              <h3 class="prize-name">{{ prize.name }}</h3>
              <p class="prize-description">{{ prize.description }}</p>
              <div class="prize-info">
                <span class="prize-points">{{ getPrizePoints(prize) }} 积分</span>
                <span class="prize-stock">库存: {{ prize.stock || 0 }}</span>
              </div>
              <el-button 
                type="primary" 
                class="exchange-button"
                :disabled="prize.stock <= 0 || userPoints < getPrizePoints(prize)"
                @click="handleExchange(prize)"
              >
                {{ userPoints >= getPrizePoints(prize) ? '立即兑换' : '积分不足' }}
              </el-button>
            </div>
          </el-card>
        </el-col>
      </el-row>
      
      <!-- 空状态 -->
      <el-empty v-if="filteredPrizes.length === 0" description="暂无奖品"></el-empty>
    </div>
    
    <!-- 兑换确认对话框 -->
    <el-dialog v-model="exchangeDialogVisible" title="确认兑换" width="30%">
      <div class="exchange-confirm">
        <div class="exchange-prize-info">
          <img :src="currentPrize?.imageUrl || defaultPrizeImage" :alt="currentPrize?.name" class="exchange-prize-image" />
          <div class="exchange-prize-details">
            <h3>{{ currentPrize?.name }}</h3>
            <p class="exchange-points">{{ getPrizePoints(currentPrize) }} 积分</p>
          </div>
        </div>
        
        <div v-if="currentPrize?.type === 'physical'" class="address-form">
          <h4>收货信息</h4>
          <el-form :model="addressForm" :rules="addressRules" ref="addressFormRef" label-width="80px">
            <el-form-item label="收件人" prop="name">
              <el-input v-model="addressForm.name" placeholder="请输入收件人姓名"></el-input>
            </el-form-item>
            <el-form-item label="手机号" prop="phone">
              <el-input v-model="addressForm.phone" placeholder="请输入联系电话"></el-input>
            </el-form-item>
            <el-form-item label="收货地址" prop="address">
              <el-input v-model="addressForm.address" type="textarea" :rows="2" placeholder="请输入详细地址"></el-input>
            </el-form-item>
          </el-form>
        </div>
        
        <div class="exchange-confirm-footer">
          <p class="exchange-confirm-tip">确认兑换后，将从您的账户扣除 {{ getPrizePoints(currentPrize) }} 积分</p>
          <div class="exchange-confirm-buttons">
            <el-button @click="exchangeDialogVisible = false">取消</el-button>
            <el-button type="primary" :loading="exchangeLoading" @click="confirmExchange">确认兑换</el-button>
          </div>
        </div>
      </div>
    </el-dialog>
    
    <!-- 兑换记录对话框 -->
    <el-dialog v-model="recordsDialogVisible" title="兑换记录" width="60%">
      <el-table :data="exchangeRecords" stripe style="width: 100%">
        <el-table-column prop="createTime" label="兑换时间" width="180"></el-table-column>
        <el-table-column prop="prizeName" label="奖品名称"></el-table-column>
        <el-table-column prop="points" label="消耗积分" width="100"></el-table-column>
        <el-table-column prop="type" label="奖品类型" width="100">
          <template #default="scope">
            <el-tag :type="getPrizeTypeTag(scope.row.type)">
              {{ getPrizeTypeName(scope.row.type) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag :type="getStatusTag(scope.row.status)">
              {{ getStatusName(scope.row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="120">
          <template #default="scope">
            <el-button 
              v-if="scope.row.type === 'virtual' && scope.row.status === 'success'" 
              type="success" 
              size="small"
              @click="viewVirtualPrize(scope.row)"
            >
              查看
            </el-button>
            <el-button 
              v-if="scope.row.type === 'physical' && scope.row.status === 'shipping'" 
              type="info" 
              size="small"
              @click="viewShippingInfo(scope.row)"
            >
              物流
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
    
    <!-- 虚拟奖品查看对话框 -->
    <el-dialog v-model="virtualPrizeDialogVisible" title="虚拟奖品" width="30%">
      <div class="virtual-prize-info">
        <h3>{{ currentExchangeRecord?.prizeName }}</h3>
        <div class="virtual-prize-code">
          <p class="code-label">兑换码</p>
          <div class="code-value">
            <span>{{ currentExchangeRecord?.redeemCode || '暂无兑换码' }}</span>
            <el-button type="primary" size="small" icon="CopyDocument" @click="copyRedeemCode">复制</el-button>
          </div>
        </div>
        <div class="virtual-prize-instructions">
          <p class="instructions-label">使用说明</p>
          <p class="instructions-content">{{ currentExchangeRecord?.instructions || '暂无使用说明' }}</p>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue';
import { ElMessage } from 'element-plus';
import { PriceTag, List, CopyDocument } from '@element-plus/icons-vue';
import { getUserPoints } from '@/api/user';
import { getPrizeList, exchangePrize, getExchangeRecords } from '@/api/prize';
import defaultPrizeImage from '@/assets/default-avatar.png';

// 导入图片资源 - 使用静态导入以优化加载
import ecoBagImg from '@/image/Prize/eco_bag.png';
import videoVipImg from '@/image/Prize/video_vip.png';
import musicVipImg from '@/image/Prize/music_vip.png';
import certificateImg from '@/image/Prize/certificate.png';
import smartCupImg from '@/image/Prize/smart_cup.png';
import solarChargerImg from '@/image/Prize/solar_charger.png';

// 图片资源映射
const prizeImages = {
  ecoBag: ecoBagImg,
  videoVip: videoVipImg,
  musicVip: musicVipImg,
  certificate: certificateImg,
  smartCup: smartCupImg,
  solarCharger: solarChargerImg
};

// 数据加载状态
const loading = ref(false);
const exchangeLoading = ref(false);

// 对话框显示状态
const exchangeDialogVisible = ref(false);
const recordsDialogVisible = ref(false);
const virtualPrizeDialogVisible = ref(false);

// 用户积分
const userPoints = ref(0);

// 筛选和排序
const activeCategory = ref('all');
const sortBy = ref('popular');
const onlyAffordable = ref(false);

// 奖品列表
const prizeList = ref<any[]>([]);

// 当前选中的奖品
const currentPrize = ref<any>(null);

// 兑换记录
const exchangeRecords = ref<any[]>([]);
const currentExchangeRecord = ref<any>(null);

// 实物奖品收货地址表单
const addressFormRef = ref();
const addressForm = reactive({
  name: '',
  phone: '',
  address: ''
});

// 地址表单验证规则
const addressRules = {
  name: [
    { required: true, message: '请输入收件人姓名', trigger: 'blur' }
  ],
  phone: [
    { required: true, message: '请输入联系电话', trigger: 'blur' },
    { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号码', trigger: 'blur' }
  ],
  address: [
    { required: true, message: '请输入详细地址', trigger: 'blur' }
  ]
};

// 根据筛选条件过滤奖品
const filteredPrizes = computed(() => {
  let result = [...prizeList.value];
  
  // 按分类筛选
  if (activeCategory.value !== 'all') {
    result = result.filter(prize => prize.type === activeCategory.value);
  }
  
  // 只看可兑换
  if (onlyAffordable.value) {
    result = result.filter(prize => prize.stock > 0 && userPoints.value >= getPrizePoints(prize));
  }
  
  // 按条件排序
  switch (sortBy.value) {
    case 'newest':
      result.sort((a, b) => new Date(b.createTime).getTime() - new Date(a.createTime).getTime());
      break;
    case 'priceAsc':
      result.sort((a, b) => a.points - b.points);
      break;
    case 'priceDesc':
      result.sort((a, b) => b.points - a.points);
      break;
    case 'popular':
    default:
      result.sort((a, b) => b.exchangeCount - a.exchangeCount);
      break;
  }
  
  return result;
});

// 获取奖品类型标签样式
const getPrizeTypeTag = (type: string): 'success' | 'warning' | 'info' | 'primary' | 'danger' => {
  const typeMap: { [key: string]: 'success' | 'warning' | 'info' | 'primary' | 'danger' } = {
    'physical': 'warning',
    'virtual': 'success',
    'coupon': 'info'
  };
  return typeMap[type] || 'info';
};

// 获取奖品类型名称
const getPrizeTypeName = (type: string): string => {
  const typeMap: { [key: string]: string } = {
    'physical': '实物奖品',
    'virtual': '虚拟奖品',
    'coupon': '优惠券'
  };
  return typeMap[type] || '未知类型';
};

// 获取状态标签样式
const getStatusTag = (status: string): 'success' | 'warning' | 'info' | 'primary' | 'danger' => {
  const statusMap: { [key: string]: 'success' | 'warning' | 'info' | 'primary' | 'danger' } = {
    'pending': 'info',
    'success': 'success',
    'shipping': 'warning',
    'completed': 'success',
    'cancelled': 'danger'
  };
  return statusMap[status] || 'info';
};

// 获取状态名称
const getStatusName = (status: string): string => {
  const statusMap: { [key: string]: string } = {
    'pending': '处理中',
    'success': '兑换成功',
    'shipping': '配送中',
    'completed': '已完成',
    'cancelled': '已取消'
  };
  return statusMap[status] || '未知状态';
};

// 处理分类变更
const handleCategoryChange = () => {
  // 可以在此添加额外的处理逻辑
};

// 处理排序变更
const handleSortChange = () => {
  // 可以在此添加额外的处理逻辑
};

// 获取用户积分
const fetchUserPoints = async () => {
  try {
    const res = await getUserPoints();
    if (res.code === 200 && res.data) {
      userPoints.value = res.data.points || 0;
    } else {
      // 使用默认值
      userPoints.value = 1000;
    }
  } catch (error: any) {
    console.error('获取用户积分错误:', error);
    // 使用默认值
    userPoints.value = 1000;
  }
};

// 获取奖品积分 - 添加此新函数
const getPrizePoints = (prize: any): number => {
  if (!prize) return 0;
  // 优先返回points字段，其次是points_required，再次是pointsRequired
  return prize.points || prize.points_required || prize.pointsRequired || 0;
};

// 获取奖品列表
const fetchPrizeList = async () => {
  loading.value = true;
  try {
    const res = await getPrizeList();
    if (res.code === 200 && res.data) {
      let prizes = [];
      
      if (Array.isArray(res.data)) {
        prizes = res.data;
      } else if (res.data.records && Array.isArray(res.data.records)) {
        prizes = res.data.records;
      } else {
        prizes = [];
      }
      
      // 处理数据，确保字段名称统一
      prizeList.value = prizes.map(prize => ({
        ...prize,
        // 确保points字段存在，但不覆盖原始字段，以便在其他地方也能访问原始字段
        points: prize.points || prize.points_required || prize.pointsRequired || 0,
        // 确保type字段正确
        type: prize.prize_type === 1 || prize.prizeType === 1 ? 'virtual' : 
              prize.prize_type === 2 || prize.prizeType === 2 ? 'physical' : 'coupon',
        // 确保stock字段正确
        stock: typeof prize.stock === 'number' ? prize.stock : 0,
        // 如果没有图片URL，根据类型分配默认图片
        imageUrl: prize.image_url || prize.imageUrl || getDefaultImageByType(prize)
      }));
    } else {
      ElMessage.warning('获取奖品列表失败: ' + (res.message || '未知错误'));
      // 使用模拟数据
      prizeList.value = getMockPrizes();
    }
  } catch (error: any) {
    console.error('获取奖品列表错误:', error);
    // 使用模拟数据
    prizeList.value = getMockPrizes();
  } finally {
    loading.value = false;
  }
};

// 根据奖品类型获取默认图片
const getDefaultImageByType = (prize: any): string => {
  const type = prize.prize_type || prize.type;
  if (type === 2 || type === 'physical') {
    return prizeImages.smartCup;
  } else if (type === 1 || type === 'virtual') {
    return prizeImages.videoVip;
  } else {
    return prizeImages.certificate;
  }
};

// 获取兑换记录
const fetchExchangeRecords = async () => {
  try {
    const res = await getExchangeRecords();
    if (res.code === 200 && res.data) {
      if (Array.isArray(res.data)) {
        exchangeRecords.value = res.data;
      } else if (res.data.records && Array.isArray(res.data.records)) {
        exchangeRecords.value = res.data.records;
      } else {
        exchangeRecords.value = [];
      }
    } else {
      // 使用模拟数据
      exchangeRecords.value = getMockExchangeRecords();
    }
  } catch (error: any) {
    console.error('获取兑换记录错误:', error);
    // 使用模拟数据
    exchangeRecords.value = getMockExchangeRecords();
  }
};

// 处理兑换
const handleExchange = (prize: any) => {
  currentPrize.value = prize;
  
  // 重置地址表单
  if (prize.type === 'physical') {
    addressForm.name = '';
    addressForm.phone = '';
    addressForm.address = '';
  }
  
  exchangeDialogVisible.value = true;
};

// 确认兑换
const confirmExchange = async () => {
  // 检查奖品是否存在
  if (!currentPrize.value) {
    ElMessage.error('兑换失败：未选择奖品');
    return;
  }
  
  // 获取正确的积分值
  const prizePoints = getPrizePoints(currentPrize.value);
  
  // 检查积分是否足够
  if (userPoints.value < prizePoints) {
    ElMessage.error('兑换失败：积分不足');
    exchangeDialogVisible.value = false;
    return;
  }
  
  // 如果是实物奖品，验证地址表单
  if (currentPrize.value.type === 'physical') {
    const valid = await addressFormRef.value.validate().catch(() => false);
    if (!valid) {
      ElMessage.warning('请填写完整的收货信息');
      return;
    }
  }
  
  exchangeLoading.value = true;
  try {
    // 构造兑换参数
    const exchangeParams = {
      prizeId: currentPrize.value.id || currentPrize.value.prize_id,
      points: prizePoints,
      pointsRequired: prizePoints, // 添加pointsRequired字段，与后端参数名保持一致
      count: 1, // 添加count属性，默认兑换数量为1
      // 如果是实物奖品，附加地址信息
      ...(currentPrize.value.type === 'physical' ? {
        receiverName: addressForm.name,
        receiverPhone: addressForm.phone,
        receiverAddress: addressForm.address
      } : {})
    };
    
    const res = await exchangePrize(exchangeParams);
    
    if (res.code === 200) {
      ElMessage.success('兑换成功');
      
      // 扣除积分
      userPoints.value -= prizePoints;
      
      // 减少库存
      const prizeIndex = prizeList.value.findIndex(p => p.id === currentPrize.value.id);
      if (prizeIndex !== -1 && prizeList.value[prizeIndex].stock > 0) {
        prizeList.value[prizeIndex].stock--;
      }
      
      // 如果是虚拟奖品，可以立即显示兑换码
      if (currentPrize.value.type === 'virtual' && res.data && res.data.redeemCode) {
        currentExchangeRecord.value = {
          ...res.data,
          prizeName: currentPrize.value.name
        };
        exchangeDialogVisible.value = false;
        virtualPrizeDialogVisible.value = true;
      } else {
        exchangeDialogVisible.value = false;
      }
      
      // 刷新兑换记录
      fetchExchangeRecords();
    } else {
      ElMessage.error('兑换失败: ' + (res.message || '未知错误'));
    }
  } catch (error: any) {
    console.error('兑换错误:', error);
    ElMessage.error('兑换失败: ' + (error.message || '未知错误'));
  } finally {
    exchangeLoading.value = false;
  }
};

// 显示兑换记录
const showExchangeRecords = () => {
  fetchExchangeRecords();
  recordsDialogVisible.value = true;
};

// 查看虚拟奖品
const viewVirtualPrize = (record: any) => {
  currentExchangeRecord.value = record;
  virtualPrizeDialogVisible.value = true;
};

// 查看物流信息
const viewShippingInfo = (record: any) => {
  // 此功能可能需要单独的API
  ElMessage.info('物流信息功能暂未实现');
};

// 复制兑换码
const copyRedeemCode = () => {
  if (currentExchangeRecord.value && currentExchangeRecord.value.redeemCode) {
    const code = currentExchangeRecord.value.redeemCode;
    navigator.clipboard.writeText(code).then(() => {
      ElMessage.success('兑换码已复制到剪贴板');
    }).catch(() => {
      ElMessage.error('复制失败，请手动复制');
    });
  }
};

// 处理图片加载错误
const handleImageError = (event: Event, prize: any) => {
  const target = event.target as HTMLImageElement;
  // 根据奖品类型选择默认图片
  if (prize.type === 'physical') {
    target.src = prizeImages.smartCup;
  } else if (prize.type === 'virtual') {
    target.src = prizeImages.videoVip;
  } else if (prize.type === 'coupon') {
    target.src = prizeImages.certificate;
  } else {
    target.src = defaultPrizeImage;
  }
};

// 模拟奖品数据
const getMockPrizes = () => {
  return [
    {
      id: 1,
      name: '环保购物袋',
      description: '可重复使用的环保购物袋，减少塑料袋使用',
      points: 300,
      stock: 50,
      imageUrl: prizeImages.ecoBag,
      type: 'physical',
      createTime: '2023-09-01T10:00:00',
      exchangeCount: 120
    },
    {
      id: 2,
      name: '视频会员月卡',
      description: '知名视频平台会员月卡，享受无广告观影体验',
      points: 500,
      stock: 100,
      imageUrl: prizeImages.videoVip,
      type: 'virtual',
      createTime: '2023-09-05T14:30:00',
      exchangeCount: 230
    },
    {
      id: 3,
      name: '有机蔬菜券',
      description: '价值50元的有机蔬菜兑换券，可在指定商超使用',
      points: 450,
      stock: 30,
      imageUrl: prizeImages.certificate,
      type: 'coupon',
      createTime: '2023-09-10T09:15:00',
      exchangeCount: 85
    },
    {
      id: 4,
      name: '便携式水杯',
      description: '不锈钢保温杯，减少一次性杯子使用',
      points: 800,
      stock: 20,
      imageUrl: prizeImages.smartCup,
      type: 'physical',
      createTime: '2023-09-15T16:45:00',
      exchangeCount: 65
    },
    {
      id: 5,
      name: '环保公益捐赠',
      description: '捐赠到环保公益项目，获得电子捐赠证书',
      points: 1000,
      stock: 999,
      imageUrl: prizeImages.certificate,
      type: 'virtual',
      createTime: '2023-09-18T11:20:00',
      exchangeCount: 45
    },
    {
      id: 6,
      name: '共享单车月卡',
      description: '共享单车月卡，30天不限次骑行',
      points: 1200,
      stock: 40,
      imageUrl: prizeImages.musicVip,
      type: 'virtual',
      createTime: '2023-09-20T13:10:00',
      exchangeCount: 78
    }
  ];
};

// 模拟兑换记录数据
const getMockExchangeRecords = () => {
  return [
    {
      id: 1,
      prizeName: '环保购物袋',
      points: 300,
      type: 'physical',
      status: 'shipping',
      createTime: '2023-09-20 14:30:22'
    },
    {
      id: 2,
      prizeName: '视频会员月卡',
      points: 500,
      type: 'virtual',
      status: 'success',
      createTime: '2023-09-15 10:20:15',
      redeemCode: 'VIP-9876-5432-1098',
      instructions: '登录视频平台，进入会员中心，点击"兑换码"，输入此码即可激活。'
    },
    {
      id: 3,
      prizeName: '有机蔬菜券',
      points: 450,
      type: 'coupon',
      status: 'completed',
      createTime: '2023-09-05 09:15:30'
    }
  ];
};

// 组件挂载时获取数据
onMounted(() => {
  fetchUserPoints();
  fetchPrizeList();
});
</script>

<style scoped>
.prize-exchange-container {
  padding: 20px;
  background-color: #f5f7fa;
  min-height: calc(100vh - 60px); /* 减去头部高度 */
}

.user-points-card {
  margin-bottom: 20px;
  background-image: linear-gradient(to right, #4facfe 0%, #00f2fe 100%);
  color: white;
}

.user-points-info {
  padding: 10px 0;
}

.user-points-info h2 {
  margin: 0 0 10px 0;
  font-size: 18px;
  font-weight: 500;
}

.points-amount {
  display: flex;
  align-items: baseline;
}

.points-number {
  font-size: 36px;
  font-weight: bold;
  margin-right: 5px;
}

.points-unit {
  font-size: 16px;
}

.points-actions {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  height: 100%;
  gap: 10px;
}

.category-tabs {
  margin-bottom: 20px;
}

.filter-sort-bar {
  margin-bottom: 20px;
  padding: 10px 15px;
  background-color: white;
  border-radius: 4px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.prize-list {
  margin-bottom: 20px;
}

.prize-card {
  margin-bottom: 20px;
  height: 100%;
  display: flex;
  flex-direction: column;
  transition: transform 0.3s, box-shadow 0.3s;
  overflow: hidden;
  border-radius: 8px;
}

.prize-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
}

.prize-image {
  position: relative;
  height: 200px;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #f5f7fa;
  border-radius: 8px 8px 0 0;
}

.prize-image img {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
  padding: 10px;
  transition: transform 0.3s;
}

.prize-card:hover .prize-image img {
  transform: scale(1.05);
}

.out-of-stock {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: rgba(0, 0, 0, 0.5);
  color: white;
  font-size: 24px;
  font-weight: bold;
}

.prize-type {
  position: absolute;
  top: 10px;
  right: 10px;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  color: white;
  font-weight: 500;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  z-index: 1;
}

.prize-type.virtual {
  background-color: #67c23a;
}

.prize-type.physical {
  background-color: #e6a23c;
}

.prize-type.coupon {
  background-color: #909399;
}

.prize-details {
  padding: 15px;
  flex: 1;
  display: flex;
  flex-direction: column;
  background-color: white;
  border-radius: 0 0 8px 8px;
}

.prize-name {
  margin: 0 0 10px 0;
  font-size: 16px;
  font-weight: 600;
  color: #303133;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.prize-description {
  color: #606266;
  font-size: 14px;
  margin: 0 0 15px 0;
  flex: 1;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  overflow: hidden;
}

.prize-info {
  display: flex;
  justify-content: space-between;
  margin-bottom: 15px;
}

.prize-points {
  color: #f56c6c;
  font-weight: bold;
}

.prize-stock {
  color: #909399;
  font-size: 14px;
}

.exchange-button {
  width: 100%;
  border-radius: 4px;
  margin-top: auto;
  font-weight: 500;
}

.exchange-confirm {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.exchange-prize-info {
  display: flex;
  align-items: center;
  gap: 15px;
}

.exchange-prize-image {
  width: 80px;
  height: 80px;
  object-fit: cover;
  border-radius: 4px;
}

.exchange-prize-details h3 {
  margin: 0 0 5px 0;
  font-size: 16px;
}

.exchange-points {
  color: #f56c6c;
  font-weight: bold;
  margin: 0;
}

.address-form h4 {
  margin: 0 0 15px 0;
  font-size: 16px;
  font-weight: 500;
}

.exchange-confirm-footer {
  margin-top: 20px;
}

.exchange-confirm-tip {
  color: #e6a23c;
  font-size: 14px;
  margin: 0 0 15px 0;
}

.exchange-confirm-buttons {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

.virtual-prize-info {
  padding: 10px;
}

.virtual-prize-info h3 {
  margin: 0 0 20px 0;
  text-align: center;
}

.virtual-prize-code,
.virtual-prize-instructions {
  margin-bottom: 20px;
}

.code-label,
.instructions-label {
  font-weight: bold;
  margin-bottom: 10px;
}

.code-value {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px;
  background-color: #f5f7fa;
  border-radius: 4px;
}

.instructions-content {
  padding: 10px;
  background-color: #f5f7fa;
  border-radius: 4px;
  white-space: pre-line;
}
</style> 