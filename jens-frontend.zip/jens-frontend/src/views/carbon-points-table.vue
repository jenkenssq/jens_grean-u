<template>
  <div class="carbon-points-table-container">
    <!-- 页面顶部装饰元素 -->
    <div class="eco-decoration">
      <div class="eco-leaf leaf-1"></div>
      <div class="eco-leaf leaf-2"></div>
      <div class="eco-leaf leaf-3"></div>
    </div>

    <div class="page-header">
      <div class="header-content">
        <h1>出行方式-积分对照表</h1>
        <div class="eco-divider">
          <span class="divider-icon">🌍</span>
        </div>
        <p class="description">不同出行方式的碳减排量及积分奖励详情，选择更环保的出行方式可以获得更多积分！</p>
      </div>
    </div>

    <el-card shadow="hover" class="table-card">
      <div class="table-header">
        <h2><i class="eco-icon">🚶</i> 基础积分规则</h2>
        <el-alert
          title="积分计算规则说明"
          type="success"
          description="积分计算分两步：1. 计算预估减碳量（距离 * 碳减排因子）；2. 计算预估积分（减碳量 * 10，四舍五入取整）。每次出行的积分上限为每天每种方式200积分。"
          show-icon
          :closable="false"
          class="rule-alert"
        />
      </div>

      <el-table
        :data="carbonPointsTableData"
        stripe
        border
        style="width: 100%"
        :header-cell-style="{ background: '#e8f5e9', color: '#2e7d32', fontWeight: 'bold' }"
        :row-class-name="tableRowClassName"
      >
        <el-table-column prop="transportType" label="出行方式" align="center" min-width="120">
          <template #default="scope">
            <div class="transport-type">
              <div class="transport-icon" :class="`transport-icon-${scope.row.iconClass || 'default'}`">
                <i :class="scope.row.icon"></i>
              </div>
              <span>{{ scope.row.transportType }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="basePoints" label="基础积分(每公里)" align="center" min-width="120">
          <template #default="scope">
            <el-tag :type="getPointsTagType(scope.row.basePoints)" effect="dark" class="points-tag">
              {{ scope.row.basePoints }} 分
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="carbonReduction" label="碳减排量(kg/公里)" align="center" min-width="150">
          <template #default="scope">
            <div class="carbon-reduction">
              <div class="carbon-bar" :style="{ width: getCarbonBarWidth(scope.row.carbonReduction) }"></div>
              <span>{{ scope.row.carbonReduction }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="calculationMethod" label="计算方式" align="center" min-width="180">
          <template #default="scope">
            <div class="calculation-formula">
              <p>1. 减碳量 = 距离(km) × {{ scope.row.carbonReduction }}kg</p>
              <p>2. 积分 = 减碳量 × 10 (四舍五入)</p>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="notes" label="备注" align="center" min-width="220" />
      </el-table>
    </el-card>

    <el-row :gutter="20" class="info-cards-row">
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
        <el-card shadow="hover" class="multiplier-card">
          <div class="table-header">
            <h2><i class="eco-icon">✨</i> 积分加成规则</h2>
          </div>

          <el-table
            :data="multiplierTableData"
            stripe
            border
            style="width: 100%"
            :header-cell-style="{ background: '#e3f2fd', color: '#1565c0', fontWeight: 'bold' }"
          >
            <el-table-column prop="condition" label="条件" align="center" min-width="150" />
            <el-table-column prop="multiplier" label="积分倍数" align="center" min-width="100">
              <template #default="scope">
                <div class="multiplier-badge" :class="getMultiplierClass(scope.row.multiplier)">
                  x{{ scope.row.multiplier }}
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="description" label="说明" align="center" min-width="220" />
          </el-table>
        </el-card>
      </el-col>

      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
        <el-card shadow="hover" class="example-card">
          <div class="table-header">
            <h2><i class="eco-icon">📝</i> 积分计算示例</h2>
          </div>

          <el-table
            :data="exampleTableData"
            stripe
            border
            style="width: 100%"
            :header-cell-style="{ background: '#fff8e1', color: '#ff8f00', fontWeight: 'bold' }"
          >
            <el-table-column prop="scenario" label="场景" align="center" min-width="180" />
            <el-table-column prop="calculation" label="计算公式" align="center" min-width="180" />
            <el-table-column prop="totalPoints" label="获得积分" align="center" min-width="120">
              <template #default="scope">
                <div class="total-points-wrapper">
                  <span class="total-points">{{ scope.row.totalPoints }}</span>
                  <span class="points-unit">分</span>
                </div>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>

    <div class="eco-tips">
      <el-card shadow="hover" class="tips-card">
        <div class="tips-header">
          <i class="eco-icon large-icon">💡</i>
          <h3>绿色出行小贴士</h3>
        </div>
        <div class="tips-content">
          <p>1. 短距离出行选择步行或骑行，既健康又环保</p>
          <p>2. 合理规划路线，避开拥堵路段，减少出行时间</p>
          <p>3. 常规通勤路线可考虑公共交通工具，减少私家车使用</p>
          <p>4. 选择共享出行方式，提高资源利用率</p>
          <p>5. 记得定期记录您的绿色出行，不要错过积分奖励！</p>
        </div>
      </el-card>
    </div>

    <div class="actions">
      <el-button type="success" @click="$router.push('/activity-submit')" class="action-button" icon="el-icon-plus">
        立即参与碳减排活动
      </el-button>
      <el-button @click="$router.go(-1)" class="action-button" icon="el-icon-back">返回上一页</el-button>
    </div>

    <!-- 页面底部装饰元素 -->
    <div class="eco-footer">
      <div class="footer-wave"></div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue';
import { useRouter } from 'vue-router';

// 出行方式-积分对照表数据
const carbonPointsTableData = reactive([
  {
    icon: 'el-icon-position',
    iconClass: 'walk',
    transportType: '步行',
    basePoints: 15,
    carbonReduction: '0.215',
    calculationMethod: '距离(km) × 15分',
    notes: '健康环保，零碳排放，适合短距离出行'
  },
  {
    icon: 'el-icon-running',
    iconClass: 'run',
    transportType: '跑步',
    basePoints: 16,
    carbonReduction: '0.275',
    calculationMethod: '距离(km) × 16分',
    notes: '运动健身的同时减少碳排放，效率最高的绿色出行方式'
  },
  {
    icon: 'el-icon-bicycle',
    iconClass: 'bike',
    transportType: '自行车',
    basePoints: 12,
    carbonReduction: '0.196',
    calculationMethod: '距离(km) × 12分',
    notes: '零碳排放，比步行速度更快'
  },
  {
    icon: 'el-icon-bicycle',
    iconClass: 'share-bike',
    transportType: '共享单车',
    basePoints: 10,
    carbonReduction: '0.196',
    calculationMethod: '距离(km) × 10分',
    notes: '使用共享资源，减少了资源浪费'
  },
  {
    icon: 'el-icon-van',
    iconClass: 'bus',
    transportType: '公交车',
    basePoints: 8,
    carbonReduction: '0.03',
    calculationMethod: '距离(km) × 8分',
    notes: '公共交通，每人平均碳排放低'
  },
  {
    icon: 'el-icon-truck',
    iconClass: 'subway',
    transportType: '地铁/轻轨',
    basePoints: 6,
    carbonReduction: '0.04',
    calculationMethod: '距离(km) × 6分',
    notes: '大容量公共交通，单人碳排放较低'
  },
  {
    icon: 'el-icon-lightning',
    iconClass: 'electric',
    transportType: '电动汽车',
    basePoints: 4,
    carbonReduction: '0.03',
    calculationMethod: '距离(km) × 4分',
    notes: '无直接排放，但考虑电力生产的间接排放'
  },
  {
    icon: 'el-icon-more',
    iconClass: 'carpool',
    transportType: '拼车/顺风车',
    basePoints: 3,
    carbonReduction: '0.015',
    calculationMethod: '距离(km) × 3分',
    notes: '共享出行减少了单人出行的碳排放'
  },
  {
    icon: 'el-icon-car',
    iconClass: 'car',
    transportType: '私家车(燃油)',
    basePoints: 0,
    carbonReduction: '0.00',
    calculationMethod: '不计积分',
    notes: '碳排放较高，不鼓励单人驾驶燃油车出行'
  }
]);

// 积分加成规则数据
const multiplierTableData = reactive([
  {
    condition: '工作日通勤',
    multiplier: 1.2,
    description: '工作日早晚高峰期(7:00-9:00, 17:00-19:00)采用绿色出行方式'
  },
  {
    condition: '连续打卡',
    multiplier: 1.5,
    description: '连续7天使用相同的绿色出行方式'
  },
  {
    condition: '极端天气',
    multiplier: 2.0,
    description: '雨雪天气、高温(≥35°C)或低温(≤0°C)天气选择绿色出行'
  },
  {
    condition: '多样化出行',
    multiplier: 1.3,
    description: '一周内使用3种及以上的绿色出行方式'
  },
  {
    condition: '节假日绿色出行',
    multiplier: 1.8,
    description: '法定节假日期间选择绿色出行方式'
  }
]);

// 积分计算示例数据
const exampleTableData = reactive([
  {
    scenario: '工作日步行上班3公里',
    calculation: '3公里 × 0.12kg = 0.36kg减碳量\n0.36kg × 10 ≈ 4分\n4分 × 1.2(工作日加成) = 5分',
    totalPoints: 5
  },
  {
    scenario: '连续7天骑共享单车上班5公里',
    calculation: '5公里 × 0.08kg = 0.4kg减碳量\n0.4kg × 10 = 4分\n4分 × 1.5(连续打卡加成) = 6分',
    totalPoints: 6
  },
  {
    scenario: '雨天乘坐公交车10公里',
    calculation: '10公里 × 0.06kg = 0.6kg减碳量\n0.6kg × 10 = 6分\n6分 × 2.0(极端天气加成) = 12分',
    totalPoints: 12
  },
  {
    scenario: '节假日骑自行车出游15公里',
    calculation: '15公里 × 0.10kg = 1.5kg减碳量\n1.5kg × 10 = 15分\n15分 × 1.8(节假日加成) = 27分',
    totalPoints: 27
  }
]);

// 表格行样式
const tableRowClassName = ({ row, rowIndex }: { row: any, rowIndex: number }) => {
  if (row.basePoints >= 10) {
    return 'high-points-row';
  } else if (row.basePoints > 0) {
    return 'medium-points-row';
  } else {
    return 'zero-points-row';
  }
};

// 根据积分值获取标签类型
const getPointsTagType = (points: number) => {
  if (points >= 10) return 'success';
  if (points >= 5) return 'warning';
  if (points > 0) return 'info';
  return 'danger';
};

// 根据碳减排量获取进度条宽度
const getCarbonBarWidth = (carbonReduction: string) => {
  const value = parseFloat(carbonReduction);
  const maxValue = 0.275; // 最大碳减排量（跑步）
  const percentage = (value / maxValue) * 100;
  return `${percentage}%`;
};

// 根据倍数获取样式类名
const getMultiplierClass = (multiplier: number) => {
  if (multiplier >= 2) return 'multiplier-high';
  if (multiplier >= 1.5) return 'multiplier-medium';
  return 'multiplier-low';
};

// 页面加载时添加动画效果
onMounted(() => {
  // 加载动画等效果可以在这里实现
  document.querySelectorAll('.table-card, .multiplier-card, .example-card').forEach((element, index) => {
    setTimeout(() => {
      (element as HTMLElement).style.opacity = '1';
      (element as HTMLElement).style.transform = 'translateY(0)';
    }, 100 * index);
  });
});
</script>

<style scoped>
/* 主题色变量 */
:root {
  --primary-green: #4caf50;
  --light-green: #e8f5e9;
  --dark-green: #2e7d32;
  --primary-blue: #2196f3;
  --light-blue: #e3f2fd;
  --primary-amber: #ffc107;
  --light-amber: #fff8e1;
}

.carbon-points-table-container {
  padding: 20px;
  background-color: #f9f9f9;
  min-height: calc(100vh - 60px);
  position: relative;
  overflow: hidden;
}

/* 装饰元素 */
.eco-decoration {
  position: absolute;
  top: 0;
  right: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 0;
}

.eco-leaf {
  position: absolute;
  width: 80px;
  height: 80px;
  background-size: contain;
  background-repeat: no-repeat;
  opacity: 0.15;
}

.leaf-1 {
  top: 10%;
  right: 5%;
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%234caf50"><path d="M17,8C8,10 5.9,16.17 3.82,21.34L5.71,22L6.66,19.7C7.14,19.87 7.64,20 8,20C19,20 22,3 22,3C21,5 14,5.25 9,6.25C4,7.25 2,11.5 2,13.5C2,15.5 3.75,17.25 3.75,17.25C7,8 17,8 17,8Z"/></svg>');
  transform: rotate(45deg);
  animation: floatLeaf 15s infinite ease-in-out;
}

.leaf-2 {
  top: 40%;
  left: 3%;
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%234caf50"><path d="M17,8C8,10 5.9,16.17 3.82,21.34L5.71,22L6.66,19.7C7.14,19.87 7.64,20 8,20C19,20 22,3 22,3C21,5 14,5.25 9,6.25C4,7.25 2,11.5 2,13.5C2,15.5 3.75,17.25 3.75,17.25C7,8 17,8 17,8Z"/></svg>');
  transform: rotate(-30deg);
  animation: floatLeaf 20s infinite ease-in-out reverse;
}

.leaf-3 {
  bottom: 20%;
  right: 10%;
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%234caf50"><path d="M17,8C8,10 5.9,16.17 3.82,21.34L5.71,22L6.66,19.7C7.14,19.87 7.64,20 8,20C19,20 22,3 22,3C21,5 14,5.25 9,6.25C4,7.25 2,11.5 2,13.5C2,15.5 3.75,17.25 3.75,17.25C7,8 17,8 17,8Z"/></svg>');
  transform: rotate(15deg);
  animation: floatLeaf 18s infinite ease-in-out 2s;
}

@keyframes floatLeaf {
  0%, 100% { transform: translateY(0) rotate(var(--rotation, 0deg)); }
  50% { transform: translateY(-20px) rotate(var(--rotation, 0deg)); }
}

/* 页面标题 */
.page-header {
  position: relative;
  z-index: 1;
  text-align: center;
  margin-bottom: 40px;
  padding: 30px 0;
  background: linear-gradient(120deg, rgba(76, 175, 80, 0.1) 0%, rgba(105, 240, 174, 0.1) 100%);
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
}

.header-content {
  max-width: 800px;
  margin: 0 auto;
}

.page-header h1 {
  color: #2e7d32;
  font-size: 32px;
  margin-bottom: 15px;
  font-weight: 600;
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
}

.eco-divider {
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 20px 0;
}

.eco-divider::before,
.eco-divider::after {
  content: '';
  flex-grow: 1;
  height: 1px;
  background-color: rgba(76, 175, 80, 0.3);
  margin: 0 15px;
}

.divider-icon {
  font-size: 24px;
}

.description {
  color: #555;
  font-size: 18px;
  line-height: 1.6;
  max-width: 800px;
  margin: 0 auto;
}

/* 卡片样式 */
.table-card,
.multiplier-card,
.example-card,
.tips-card {
  margin-bottom: 30px;
  border-radius: 8px;
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08);
  transition: all 0.5s ease;
  opacity: 0;
  transform: translateY(20px);
  overflow: hidden;
  background-color: white;
}

.tips-card {
  opacity: 1;
  transform: translateY(0);
}

.table-header {
  margin-bottom: 20px;
  padding-bottom: 15px;
  border-bottom: 1px solid #eee;
}

.table-header h2 {
  font-size: 22px;
  color: #2e7d32;
  margin-bottom: 15px;
  display: flex;
  align-items: center;
  font-weight: 600;
}

.eco-icon {
  margin-right: 10px;
  font-size: 20px;
}

.large-icon {
  font-size: 28px;
}

.rule-alert {
  border-radius: 6px;
  margin-top: 15px;
}

/* 表格样式 */
.el-table {
  border-radius: 6px;
  overflow: hidden;
}

/* 行样式 */
:deep(.high-points-row) {
  background-color: rgba(76, 175, 80, 0.08);
}

:deep(.medium-points-row) {
  background-color: rgba(251, 192, 45, 0.08);
}

:deep(.zero-points-row) {
  background-color: rgba(229, 115, 115, 0.08);
}

/* 出行方式图标 */
.transport-type {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
}

.transport-icon {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  color: white;
  background-color: #4caf50;
}

.transport-icon-walk { background-color: #43a047; }
.transport-icon-run { background-color: #2e7d32; }
.transport-icon-bike { background-color: #388e3c; }
.transport-icon-share-bike { background-color: #2e7d32; }
.transport-icon-bus { background-color: #1e88e5; }
.transport-icon-subway { background-color: #1976d2; }
.transport-icon-electric { background-color: #0097a7; }
.transport-icon-carpool { background-color: #ffa000; }
.transport-icon-car { background-color: #e53935; }

.points-tag {
  padding: 4px 12px;
  font-weight: bold;
  border-radius: 16px;
}

/* 碳减排量条形图 */
.carbon-reduction {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.carbon-bar {
  position: absolute;
  left: 0;
  top: 0;
  height: 100%;
  background-color: rgba(76, 175, 80, 0.2);
  z-index: 0;
}

.carbon-reduction span {
  position: relative;
  z-index: 1;
}

/* 积分乘数样式 */
.multiplier-badge {
  display: inline-block;
  padding: 6px 12px;
  border-radius: 20px;
  font-weight: bold;
  color: white;
}

.multiplier-high {
  background-color: #e53935;
}

.multiplier-medium {
  background-color: #fb8c00;
}

.multiplier-low {
  background-color: #43a047;
}

/* 积分值样式 */
.total-points-wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
}

.total-points {
  font-size: 22px;
  font-weight: bold;
  color: #e53935;
}

.points-unit {
  font-size: 14px;
  color: #757575;
  margin-left: 4px;
}

/* 卡片行布局 */
.info-cards-row {
  margin-bottom: 30px;
}

/* 小贴士卡片样式 */
.eco-tips {
  margin-bottom: 30px;
}

.tips-header {
  display: flex;
  align-items: center;
  margin-bottom: 15px;
  padding-bottom: 10px;
  border-bottom: 1px dashed #e0e0e0;
}

.tips-header h3 {
  font-size: 20px;
  color: #2e7d32;
  margin: 0;
  font-weight: 600;
}

.tips-content p {
  margin: 8px 0;
  color: #555;
  line-height: 1.6;
  padding-left: 18px;
  position: relative;
}

.tips-content p::before {
  content: '•';
  position: absolute;
  left: 0;
  color: #4caf50;
  font-weight: bold;
}

/* 底部操作按钮 */
.actions {
  display: flex;
  justify-content: center;
  gap: 20px;
  margin-top: 40px;
  margin-bottom: 50px;
  position: relative;
  z-index: 1;
}

.action-button {
  padding: 12px 24px;
  font-size: 16px;
  border-radius: 50px;
  transition: all 0.3s ease;
}

.action-button:hover {
  transform: translateY(-3px);
  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
}

/* 页脚波浪 */
.eco-footer {
  position: relative;
  height: 60px;
  margin-top: 40px;
  overflow: hidden;
}

.footer-wave {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 60px;
  background-image: url('data:image/svg+xml;utf8,<svg viewBox="0 0 1200 120" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none"><path d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z" opacity=".25" fill="%234caf50"/><path d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z" opacity=".5" fill="%234caf50"/><path d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z" fill="%234caf50"/></svg>');
  background-repeat: no-repeat;
  background-size: cover;
}

/* 响应式调整 */
@media (max-width: 768px) {
  .page-header h1 {
    font-size: 26px;
  }
  
  .description {
    font-size: 16px;
    padding: 0 15px;
  }
  
  .transport-icon {
    width: 32px;
    height: 32px;
    font-size: 16px;
  }
  
  .actions {
    flex-direction: column;
    align-items: center;
    gap: 15px;
  }
  
  .action-button {
    width: 80%;
  }
}
</style>
