<template>
  <div class="home-container">
    <!-- 添加顶部导航栏 -->
    <div class="top-nav">
      <div class="container">
        <div class="logo">JENS碳积分游戏化系统</div>
        <div class="nav-actions">
          <template v-if="isLoggedIn">
            <el-button @click="$router.push('/user-center')">用户中心</el-button>
            <el-button type="danger" @click="handleLogout">退出登录</el-button>
          </template>
          <template v-else>
            <el-button type="primary" @click="$router.push('/login')">登录</el-button>
            <el-button @click="$router.push('/register')">注册</el-button>
          </template>
        </div>
      </div>
    </div>
    
    <div class="banner-section">
      <el-row :gutter="20" justify="center">
        <el-col :span="18">
          <el-card class="welcome-banner">
            <div class="banner-content">
              <h1>JENS碳积分游戏化系统</h1>
              <p class="banner-desc">用游戏化方式记录低碳行为，获取积分奖励，共同守护地球家园</p>
              <div class="banner-actions" v-if="!isLoggedIn">
                <el-button type="success" size="large" @click="$router.push('/login')">立即登录</el-button>
                <el-button size="large" @click="$router.push('/guide')">了解更多</el-button>
              </div>
              <div class="banner-stats" v-else>
                <div class="stat-card">
                  <h3>{{ userStats.totalPoints || 0 }}</h3>
                  <p>当前积分</p>
                </div>
                <div class="stat-card">
                  <h3>{{ (userStats.totalCarbon || 0).toFixed(1) }}kg</h3>
                  <p>碳减排量</p>
                </div>
                <div class="stat-card">
                  <h3>{{ userStats.activityCount || 0 }}</h3>
                  <p>活动次数</p>
                </div>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
    
    <el-row :gutter="20" justify="center" class="feature-section">
      <el-col :span="18">
        <el-card>
          <template #header>
            <div class="section-header">
              <h2>核心功能</h2>
              <p>通过以下功能，开始您的低碳生活</p>
            </div>
          </template>
          
          <el-row :gutter="20">
            <el-col :xs="24" :sm="12" :md="8" :lg="6">
              <div class="feature-card" @click="navigateTo('/activity-submit')">
                <div class="feature-icon"><el-icon :size="40"><Timer /></el-icon></div>
                <h3>记录活动</h3>
                <p>记录您的步行、骑行等低碳活动</p>
              </div>
            </el-col>
            
            <el-col :xs="24" :sm="12" :md="8" :lg="6">
              <div class="feature-card" @click="navigateTo('/data-statistics')">
                <div class="feature-icon"><el-icon :size="40"><DataAnalysis /></el-icon></div>
                <h3>数据统计</h3>
                <p>查看您的碳减排数据和趋势分析</p>
              </div>
            </el-col>
            
            <el-col :xs="24" :sm="12" :md="8" :lg="6">
              <div class="feature-card" @click="navigateTo('/prize')">
                <div class="feature-icon"><el-icon :size="40"><Present /></el-icon></div>
                <h3>奖品兑换</h3>
                <p>使用积分兑换各种精美奖品</p>
              </div>
            </el-col>
            
            <el-col :xs="24" :sm="12" :md="8" :lg="6">
              <div class="feature-card" @click="navigateTo('/user-center', 'achievements')">
                <div class="feature-icon"><el-icon :size="40"><Trophy /></el-icon></div>
                <h3>成就系统</h3>
                <p>完成任务获取成就和额外奖励</p>
              </div>
            </el-col>
          </el-row>
        </el-card>
      </el-col>
    </el-row>
    
    <el-row :gutter="20" justify="center" class="dashboard-section">
      <el-col :span="18" v-if="isLoggedIn">
        <el-card>
          <template #header>
            <div class="section-header">
              <h2>我的数据看板</h2>
              <el-button type="primary" text @click="$router.push('/data-statistics')">查看详细数据</el-button>
            </div>
          </template>
          
          <el-row :gutter="20">
            <el-col :xs="24" :sm="24" :md="12">
              <div class="chart-container" ref="carbonChartRef"></div>
              <div class="chart-title">碳减排趋势图（近7天）</div>
            </el-col>
            <el-col :xs="24" :sm="24" :md="12">
              <div class="chart-container" ref="activityTypeChartRef"></div>
              <div class="chart-title">活动类型分布</div>
            </el-col>
          </el-row>

          <el-row :gutter="20" class="stats-cards">
            <el-col :xs="12" :sm="8" :md="6" :lg="4">
              <div class="stat-card-item">
                <div class="stat-icon carbon-icon">
                  <el-icon><DataLine /></el-icon>
                </div>
                <div class="stat-info">
                  <div class="stat-value">{{ Number(activityStats.totalCarbonReduced || 0).toFixed(1) }}kg</div>
                  <div class="stat-label">总减碳量</div>
                </div>
              </div>
            </el-col>
            <el-col :xs="12" :sm="8" :md="6" :lg="4">
              <div class="stat-card-item">
                <div class="stat-icon points-icon">
                  <el-icon><Present /></el-icon>
                </div>
                <div class="stat-info">
                  <div class="stat-value">{{ activityStats.totalPointsEarned || 0 }}</div>
                  <div class="stat-label">获得积分</div>
                </div>
              </div>
            </el-col>
            <el-col :xs="12" :sm="8" :md="6" :lg="4">
              <div class="stat-card-item">
                <div class="stat-icon activity-icon">
                  <el-icon><Timer /></el-icon>
                </div>
                <div class="stat-info">
                  <div class="stat-value">{{ activityStats.totalActivities || 0 }}</div>
                  <div class="stat-label">活动次数</div>
                </div>
              </div>
            </el-col>
            <el-col :xs="12" :sm="8" :md="6" :lg="4">
              <div class="stat-card-item">
                <div class="stat-icon distance-icon">
                  <el-icon><Location /></el-icon>
                </div>
                <div class="stat-info">
                  <div class="stat-value">{{ formatDistance(activityStats.totalDistance || 0) }}</div>
                  <div class="stat-label">总里程</div>
                </div>
              </div>
            </el-col>
            <el-col :xs="12" :sm="8" :md="6" :lg="4">
              <div class="stat-card-item">
                <div class="stat-icon steps-icon">
                  <el-icon><Position /></el-icon>
                </div>
                <div class="stat-info">
                  <div class="stat-value">{{ formatNumber(activityStats.totalSteps || 0) }}</div>
                  <div class="stat-label">总步数</div>
                </div>
              </div>
            </el-col>
            <el-col :xs="12" :sm="8" :md="6" :lg="4">
              <div class="stat-card-item">
                <div class="stat-icon calories-icon">
                  <el-icon><Aim /></el-icon>
                </div>
                <div class="stat-info">
                  <div class="stat-value">{{ activityStats.totalCalories || 0 }}</div>
                  <div class="stat-label">消耗卡路里</div>
                </div>
              </div>
            </el-col>
          </el-row>
          
          <el-row :gutter="20" class="mt-20">
            <el-col :span="24">
              <div class="recent-activity">
                <h3>最近活动</h3>
                <el-empty v-if="!recentActivities.length" description="暂无活动记录"></el-empty>
                <div v-else class="activity-list">
                  <div v-for="(activity, index) in recentActivities" :key="index" class="activity-item">
                    <el-tag :type="getActivityTypeTag(activity.activityType)" size="small">
                      {{ getActivityTypeName(activity.activityType) }}
                    </el-tag>
                    <span class="activity-time">{{ formatDate(activity.startTime) }}</span>
                    <span class="activity-distance">{{ formatDistance(activity.distance || 0) }}</span>
                    <span class="activity-carbon">减碳 {{ activity.carbonReduced }}kg</span>
                  </div>
                </div>
              </div>
            </el-col>
          </el-row>
        </el-card>
      </el-col>
      
      <el-col :span="18" v-else>
        <el-card class="tips-card">
          <template #header>
            <div class="section-header">
              <h2>环保小知识</h2>
            </div>
          </template>
          
          <el-carousel :interval="5000" height="200px" indicator-position="outside">
            <el-carousel-item v-for="(tip, index) in environmentalTips" :key="index">
              <div class="tip-content">
                <h3>{{ tip.title }}</h3>
                <p>{{ tip.content }}</p>
              </div>
            </el-carousel-item>
          </el-carousel>
        </el-card>
      </el-col>
    </el-row>
    
    <el-row :gutter="20" justify="center" class="community-section">
      <el-col :span="18">
        <el-card>
          <template #header>
            <div class="section-header">
              <h2>碳积分社区</h2>
              <p>查看排行榜和最新活动公告</p>
            </div>
          </template>
          
          <el-row :gutter="20">
            <el-col :span="12">
              <div class="leaderboard">
                <h3>积分排行榜</h3>
                <el-table :data="leaderboard" stripe style="width: 100%">
                  <el-table-column prop="rank" label="排名" width="80"></el-table-column>
                  <el-table-column prop="username" label="用户"></el-table-column>
                  <el-table-column prop="points" label="积分" width="100"></el-table-column>
                </el-table>
              </div>
            </el-col>
            
            <el-col :span="12">
              <div class="announcements">
                <h3>最新公告</h3>
                <el-timeline>
                  <el-timeline-item
                    v-for="(activity, index) in announcements"
                    :key="index"
                    :timestamp="activity.date"
                    :type="getActivityTypeTag(activity.type || 'default')"
                  >
                    {{ activity.content }}
                  </el-timeline-item>
                </el-timeline>
              </div>
            </el-col>
          </el-row>
        </el-card>
      </el-col>
    </el-row>
    
    <el-row :gutter="20" justify="center" class="footer-section">
      <el-col :span="18">
        <div class="api-test-link">
          <p>想要测试API接口？</p>
          <router-link to="/api-test">
            <el-button type="info">前往API测试页面</el-button>
          </router-link>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, computed } from 'vue';
import { 
  Timer, DataAnalysis, Present, Trophy, 
  Help, ShoppingCartFull as ShoppingCart, DataLine, Location, Position, Aim
} from '@element-plus/icons-vue';
import * as echarts from 'echarts';
import { getUserStats, getCarbonStats, getUserPoints } from '@/api/user';
import { getActivityRecords, getActivityStats } from '@/api/activity';
import { ElMessage } from 'element-plus';
import { useRouter } from 'vue-router';
import { logoutAndRefresh } from '@/utils/auth';

const router = useRouter();

// 检查登录状态
const isLoggedIn = computed(() => {
  return !!localStorage.getItem('JENS_TOKEN');
});

// 用户统计数据
const userStats = reactive({
  totalPoints: 0,
  totalCarbon: 0,
  activityCount: 0
});

// 近期活动记录
const recentActivities = ref<any[]>([]);

// 图表引用
const carbonChartRef = ref<HTMLElement | null>(null);
const activityTypeChartRef = ref<HTMLElement | null>(null);

// 排行榜数据
const leaderboard = ref([
  { rank: 1, username: '环保达人', points: 2456 },
  { rank: 2, username: '绿色骑手', points: 2105 },
  { rank: 3, username: '碳中和先锋', points: 1856 },
  { rank: 4, username: '低碳生活家', points: 1654 },
  { rank: 5, username: '环保小卫士', points: 1432 }
]);

// 公告数据
const announcements = ref([
  { date: '2023-09-25', content: '全新版本上线，新增成就系统', type: 'primary' },
  { date: '2023-09-20', content: '国际无车日活动，参与骑行可获双倍积分', type: 'success' },
  { date: '2023-09-15', content: '9月环保主题：绿色出行，从我做起', type: 'info' },
  { date: '2023-09-10', content: '系统维护通知：9月11日凌晨2点-4点', type: 'warning' }
]);

// 环保小知识
const environmentalTips = ref([
  {
    title: '每天步行的环保价值',
    content: '每天步行5公里可减少约0.5kg碳排放，一年可减少182.5kg，相当于种植约8棵树的吸碳量'
  },
  {
    title: '骑自行车代替开车',
    content: '每骑行10公里代替开车可减少约2.2kg的二氧化碳排放，如果每周骑行上班5天，一年可减少约520kg碳排放'
  },
  {
    title: '公共交通的环保效益',
    content: '乘坐公共交通工具比私家车平均每人每公里减少约2/3的碳排放，是最经济高效的减碳方式之一'
  },
  {
    title: '低碳饮食小贴士',
    content: '减少肉类消费、选择当季食物、减少食物浪费，这些饮食习惯可以显著降低你的碳足迹'
  }
]);

// 活动统计数据
const activityStats = reactive({
  totalActivities: 0,
  totalDuration: 0,
  totalDistance: 0,
  totalSteps: 0,
  totalCalories: 0,
  totalCarbonReduced: 0,
  totalPointsEarned: 0,
  activityBreakdown: {
    walking: 0,
    running: 0,
    cycling: 0,
    public_transport: 0,
    carpooling: 0
  }
});

// 获取活动类型标签样式
const getActivityTypeTag = (type: string): 'success' | 'warning' | 'info' | 'primary' | 'danger' => {
  const typeMap: Record<string, 'success' | 'warning' | 'info' | 'primary' | 'danger'> = {
    'walking': 'success',
    'running': 'warning',
    'cycling': 'primary',
    'default': 'info'
  };
  return typeMap[type] || typeMap.default;
};

// 获取活动类型名称
const getActivityTypeName = (type: string): string => {
  const typeMap: Record<string, string> = {
    'walking': '步行',
    'running': '跑步',
    'cycling': '骑行',
    'default': '其他'
  };
  return typeMap[type] || typeMap.default;
};

// 格式化日期
const formatDate = (dateStr: string): string => {
  if (!dateStr) return '';
  const date = new Date(dateStr);
  return `${date.getMonth() + 1}月${date.getDate()}日`;
};

// 格式化距离
const formatDistance = (distance: number): string => {
  if (distance >= 1000) {
    return (distance / 1000).toFixed(1) + 'km';
  }
  return distance + 'm';
};

// 格式化数字（添加千位分隔符）
const formatNumber = (num: number): string => {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
};

// 初始化趋势图表
const initCarbonChart = (data: { dates: string[], values: number[] }) => {
  if (!carbonChartRef.value) return;
  
  const chart = echarts.init(carbonChartRef.value);
  
  const option = {
    tooltip: {
      trigger: 'axis',
      formatter: '{b}: {c} kg'
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: data.dates || []
    },
    yAxis: {
      type: 'value',
      name: '减碳量 (kg)'
    },
    series: [
      {
        name: '减碳量',
        type: 'line',
        smooth: true,
        lineStyle: {
          width: 3,
          color: '#67c23a'
        },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            {
              offset: 0,
              color: 'rgba(103, 194, 58, 0.5)'
            },
            {
              offset: 1,
              color: 'rgba(103, 194, 58, 0.1)'
            }
          ])
        },
        data: data.values || []
      }
    ]
  };
  
  chart.setOption(option);
  
  // 监听窗口大小变化，调整图表大小
  window.addEventListener('resize', () => {
    chart.resize();
  });
};

// 初始化活动类型分布图
const initActivityTypeChart = (activityData: Record<string, number>) => {
  if (!activityTypeChartRef.value) return;
  
  console.log('初始化饼图数据:', activityData);
  
  const chart = echarts.init(activityTypeChartRef.value);
  
  // 准备饼图数据
  const pieData = Object.entries(activityData).map(([type, count]) => {
    return {
      name: getActivityTypeName(type),
      value: count
    };
  }).filter(item => item.value > 0);
  
  const colors = [
    '#67C23A', // 步行 - 绿色
    '#F56C6C', // 跑步 - 红色
    '#409EFF', // 骑行 - 蓝色
    '#E6A23C', // 公共交通 - 橙色
    '#9C27B0'  // 拼车 - 紫色
  ];
  
  const option = {
    tooltip: {
      trigger: 'item',
      formatter: '{b}: {c} ({d}%)'
    },
    legend: {
      orient: 'vertical',
      right: 10,
      top: 'center',
      data: pieData.map(item => item.name)
    },
    color: colors,
    series: [
      {
        name: '活动类型',
        type: 'pie',
        radius: ['40%', '70%'],
        center: ['40%', '50%'],
        avoidLabelOverlap: false,
        itemStyle: {
          borderRadius: 8,
          borderColor: '#fff',
          borderWidth: 2
        },
        label: {
          show: false
        },
        emphasis: {
          label: {
            show: true,
            fontSize: '14',
            fontWeight: 'bold'
          }
        },
        labelLine: {
          show: false
        },
        data: pieData.length ? pieData : [{ name: '暂无数据', value: 1 }]
      }
    ]
  };
  
  chart.setOption(option);
  
  // 监听窗口大小变化，调整图表大小
  window.addEventListener('resize', () => {
    chart.resize();
  });
};

// 获取用户统计数据
const fetchUserStats = async () => {
  if (!isLoggedIn.value) return;
  
  try {
    // 同时获取用户积分信息和活动统计
    const [pointsRes, activityStatsRes] = await Promise.all([
      getUserPoints(),
      getActivityStats('year')
    ]);
    
    // 处理积分数据
    if (pointsRes.code === 200 && pointsRes.data) {
      userStats.totalPoints = pointsRes.data.points || 0;
    }
    
    // 处理活动统计数据
    if (activityStatsRes.code === 200 && activityStatsRes.data) {
      // 更新用户状态数据
      userStats.totalCarbon = activityStatsRes.data.totalCarbonReduced || 0;
      userStats.activityCount = activityStatsRes.data.totalActivities || 0;
      
      // 更新详细活动统计数据
      Object.assign(activityStats, {
        totalActivities: activityStatsRes.data.totalActivities || 0,
        totalDuration: activityStatsRes.data.totalDuration || 0,
        totalDistance: activityStatsRes.data.totalDistance || 0,
        totalSteps: activityStatsRes.data.totalSteps || 0,
        totalCalories: activityStatsRes.data.totalCalories || 0,
        totalCarbonReduced: activityStatsRes.data.totalCarbonReduced || 0,
        totalPointsEarned: activityStatsRes.data.totalPointsEarned || 0
      });
      
      // 尝试获取活动分布数据并显示饼图
      let hasValidBreakdown = false;
      
      // 尝试方式1: 使用activityBreakdown字段
      if (activityStatsRes.data.activityBreakdown) {
        console.log('使用activityBreakdown字段', activityStatsRes.data.activityBreakdown);
        activityStats.activityBreakdown = activityStatsRes.data.activityBreakdown;
        hasValidBreakdown = true;
      } 
      // 尝试方式2: 使用activityTypeDistribution字段
      else if (activityStatsRes.data.activityTypeDistribution) {
        console.log('使用activityTypeDistribution字段', activityStatsRes.data.activityTypeDistribution);
        activityStats.activityBreakdown = activityStatsRes.data.activityTypeDistribution;
        hasValidBreakdown = true;
      } 
      // 尝试方式3: 使用各类型计数构建分布
      else if (
        typeof activityStatsRes.data.walkingCount === 'number' || 
        typeof activityStatsRes.data.runningCount === 'number' || 
        typeof activityStatsRes.data.cyclingCount === 'number'
      ) {
        console.log('使用单独计数字段构建分布');
        const breakdown = {
          walking: activityStatsRes.data.walkingCount || 0,
          running: activityStatsRes.data.runningCount || 0,
          cycling: activityStatsRes.data.cyclingCount || 0,
          public_transport: 0,
          carpooling: 0
        };
        console.log('构建的分布数据:', breakdown);
        activityStats.activityBreakdown = breakdown;
        hasValidBreakdown = true;
      }
      
      // 如果以上都没有，使用默认数据
      if (!hasValidBreakdown) {
        console.log('使用默认分布数据');
        activityStats.activityBreakdown = {
          walking: 20,
          running: 8,
          cycling: 5,
          public_transport: 0,
          carpooling: 0
        };
      }
      
      // 显示饼图
      setTimeout(() => {
        try {
          initActivityTypeChart(activityStats.activityBreakdown);
        } catch (error) {
          console.error('饼图初始化错误:', error);
        }
      }, 300);
    }
  } catch (error) {
    console.error('获取用户统计数据失败:', error);
    // 使用示例数据
    userStats.totalPoints = 850;
    userStats.totalCarbon = 125;
    userStats.activityCount = 36;
    
    // 示例活动统计数据
    Object.assign(activityStats, {
      totalActivities: 36,
      totalDuration: 108000, // 30小时
      totalDistance: 165000, // 165公里
      totalSteps: 185000,
      totalCalories: 9500,
      totalCarbonReduced: 125,
      totalPointsEarned: 850,
      activityBreakdown: {
        walking: 20,
        running: 8,
        cycling: 5,
        public_transport: 2,
        carpooling: 1
      }
    });
    
    // 初始化活动类型分布图
    setTimeout(() => {
      initActivityTypeChart(activityStats.activityBreakdown);
    }, 300);
  }
};

// 获取近期活动
const fetchRecentActivities = async () => {
  if (!isLoggedIn.value) return;
  
  try {
    const res = await getActivityRecords({ page: 1, pageSize: 5 });
    if (res.code === 200 && res.data) {
      if (res.data.records && Array.isArray(res.data.records)) {
        recentActivities.value = res.data.records;
      } else if (Array.isArray(res.data)) {
        recentActivities.value = res.data;
      }
    }
  } catch (error) {
    console.error('获取近期活动失败:', error);
    // 使用示例数据
    recentActivities.value = [
      { activityType: 'walking', startTime: '2023-09-24 14:30:00', carbonReduced: 1.2 },
      { activityType: 'cycling', startTime: '2023-09-22 08:20:00', carbonReduced: 2.5 },
      { activityType: 'running', startTime: '2023-09-20 18:15:00', carbonReduced: 1.8 }
    ];
  }
};

// 获取碳减排趋势数据
const fetchCarbonTrend = async () => {
  if (!isLoggedIn.value || !carbonChartRef.value) return;
  
  try {
    const res = await getCarbonStats({ period: 'week' });
    
    if (res.code === 200 && res.data) {
      // 处理图表数据
      const chartData: { dates: string[], values: number[] } = {
        dates: [],
        values: []
      };
      
      // 从API响应中提取数据
      if (res.data.dailyStats && Array.isArray(res.data.dailyStats)) {
        res.data.dailyStats.forEach((item: any) => {
          chartData.dates.push(item.date);
          chartData.values.push(item.carbonReduced);
        });
        
        initCarbonChart(chartData);
      } else {
        // 示例数据
        const today = new Date();
        const dates: string[] = [];
        const values: number[] = [];
        
        for (let i = 6; i >= 0; i--) {
          const date = new Date(today);
          date.setDate(today.getDate() - i);
          
          dates.push(formatDate(date.toISOString()));
          values.push(Math.random() * 5 + 0.5);
        }
        
        initCarbonChart({ dates, values });
      }
    } else {
      // 使用示例数据
      const today = new Date();
      const dates: string[] = [];
      const values: number[] = [];
      
      for (let i = 6; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(today.getDate() - i);
        
        dates.push(formatDate(date.toISOString()));
        values.push(Math.random() * 5 + 0.5);
      }
      
      initCarbonChart({ dates, values });
    }
  } catch (error) {
    console.error('获取碳减排趋势数据失败:', error);
    
    // 使用示例数据
    const today = new Date();
    const dates: string[] = [];
    const values: number[] = [];
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);
      
      dates.push(formatDate(date.toISOString()));
      values.push(Math.random() * 5 + 0.5);
    }
    
    initCarbonChart({ dates, values });
  }
};

// 导航到路径，检查登录状态
const navigateTo = (path: string, tab?: string) => {
  if (!isLoggedIn.value) {
    ElMessage.warning('请先登录，才能使用该功能');
    router.push('/login');
    return;
  }
  if (tab) {
    router.push({ path, query: { tab } });
  } else {
    router.push(path);
  }
};

// 处理退出登录
const handleLogout = () => {
  ElMessage.success('已退出登录');
  logoutAndRefresh();
};

// 组件挂载时获取数据
onMounted(() => {
  if (isLoggedIn.value) {
    fetchUserStats();
    fetchRecentActivities();
    setTimeout(() => {
      fetchCarbonTrend();
    }, 300); // 稍微延迟，确保DOM已渲染
  }
});
</script>

<style scoped>
.home-container {
  padding: 20px;
  background-color: #f5f7fa;
}

.top-nav {
  background-color: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  padding: 10px 0;
  position: sticky;
  top: 0;
  z-index: 100;
}

.top-nav .container {
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;
}

.top-nav .logo {
  font-size: 18px;
  font-weight: bold;
  color: #409EFF;
}

.nav-actions {
  display: flex;
  gap: 10px;
}

.banner-section {
  margin-bottom: 30px;
}

.welcome-banner {
  background-image: linear-gradient(135deg, #67C23A 0%, #409EFF 100%);
  color: white;
  border: none;
  overflow: hidden;
}

.banner-content {
  padding: 40px 20px;
  text-align: center;
}

.banner-content h1 {
  font-size: 36px;
  margin-bottom: 10px;
}

.banner-desc {
  font-size: 18px;
  margin-bottom: 30px;
  opacity: 0.9;
}

.banner-actions {
  margin-top: 20px;
}

.banner-stats {
  display: flex;
  justify-content: center;
  gap: 40px;
  margin-top: 20px;
}

.stat-card {
  background-color: rgba(255, 255, 255, 0.2);
  padding: 15px 25px;
  border-radius: 8px;
}

.stat-card h3 {
  font-size: 28px;
  margin: 0;
}

.stat-card p {
  margin: 5px 0 0;
  font-size: 14px;
  opacity: 0.8;
}

.feature-section, 
.dashboard-section,
.community-section,
.footer-section {
  margin-bottom: 30px;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 10px;
}

.section-header h2 {
  font-size: 22px;
  margin: 0;
}

.section-header p {
  color: #909399;
  margin: 0;
}

.feature-card {
  height: 180px;
  padding: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  cursor: pointer;
  border-radius: 8px;
  transition: all 0.3s;
  margin-bottom: 20px;
}

.feature-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
}

.feature-icon {
  margin-bottom: 15px;
  color: #409EFF;
}

.feature-card h3 {
  font-size: 18px;
  margin: 0 0 10px;
}

.feature-card p {
  color: #606266;
  margin: 0;
}

.chart-container {
  height: 300px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  margin-bottom: 10px;
}

.chart-title {
  text-align: center;
  margin-bottom: 20px;
  color: #606266;
  font-size: 14px;
}

.stats-cards {
  margin-top: 20px;
  margin-bottom: 10px;
}

.stat-card-item {
  background-color: #fff;
  border-radius: 8px;
  padding: 15px;
  display: flex;
  align-items: center;
  margin-bottom: 20px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.05);
  transition: all 0.3s;
}

.stat-card-item:hover {
  transform: translateY(-3px);
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 15px;
  color: white;
  font-size: 22px;
}

.carbon-icon {
  background: linear-gradient(135deg, #67C23A 0%, #4CAF50 100%);
}

.points-icon {
  background: linear-gradient(135deg, #E6A23C 0%, #FF9800 100%);
}

.activity-icon {
  background: linear-gradient(135deg, #409EFF 0%, #2196F3 100%);
}

.distance-icon {
  background: linear-gradient(135deg, #9C27B0 0%, #673AB7 100%);
}

.steps-icon {
  background: linear-gradient(135deg, #F56C6C 0%, #F44336 100%);
}

.calories-icon {
  background: linear-gradient(135deg, #909399 0%, #607D8B 100%);
}

.stat-info {
  flex: 1;
}

.stat-value {
  font-size: 20px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 5px;
}

.stat-label {
  font-size: 13px;
  color: #909399;
}

.mt-20 {
  margin-top: 20px;
}

.recent-activity {
  height: auto;
  max-height: 300px;
  overflow-y: auto;
  padding: 15px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.activity-item {
  padding: 12px 10px;
  border-bottom: 1px solid #f0f0f0;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
}

.activity-time {
  margin-left: 10px;
  color: #909399;
  font-size: 13px;
  flex: 1;
}

.activity-distance {
  color: #409EFF;
  margin-right: 15px;
  font-size: 13px;
}

.activity-carbon {
  color: #67C23A;
  font-weight: bold;
}

.leaderboard, .announcements {
  height: 320px;
}

.leaderboard h3, .announcements h3 {
  margin-top: 0;
  padding-bottom: 10px;
  border-bottom: 1px solid #eee;
}

.tip-content {
  padding: 20px;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  background-color: #f9f9f9;
}

.tip-content h3 {
  margin-top: 0;
  color: #409EFF;
}

.api-test-link {
  margin-top: 40px;
  text-align: center;
  padding: 20px;
  border-top: 1px solid #eee;
}

@media screen and (max-width: 768px) {
  .stat-card-item {
    padding: 10px;
  }
  
  .stat-icon {
    width: 40px;
    height: 40px;
    font-size: 18px;
    margin-right: 10px;
  }
  
  .stat-value {
    font-size: 16px;
  }
  
  .stat-label {
    font-size: 12px;
  }
  
  .chart-container {
    height: 250px;
  }
}
</style> 