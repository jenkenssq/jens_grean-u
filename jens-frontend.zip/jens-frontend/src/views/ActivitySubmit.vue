<template>
  <div class="activity-submit-container">
    <!-- 全局错误提示 -->
    <div v-if="globalError" class="global-error-alert">
      <i class="el-icon-warning"></i> {{ globalError }}
      <span class="close-icon" @click="globalError = ''">×</span>
    </div>
    
    <el-card class="submit-card">
      <template #header>
        <div class="card-header">
          <span class="eco-badge">
            <i class="el-icon-leaf"></i>
          </span>
          <h2 class="main-title">记录低碳活动</h2>
          <p class="sub-title">记录您的低碳活动，获取积分奖励</p>
        </div>
      </template>
      
      <el-form :model="activityForm" :rules="rules" ref="activityFormRef" label-width="100px" class="activity-form">
        <!-- 活动类型 -->
        <el-form-item label="活动类型" prop="activityType">
          <div class="activity-type-wrapper">
            <el-select 
              v-model="activityForm.activityType" 
              placeholder="请选择活动类型" 
              @change="handleActivityTypeChange"
              popper-class="activity-type-dropdown"
              style="width: 100%"
            >
              <el-option v-for="item in activityTypes" :key="item.value" :label="item.label" :value="item.value">
                <div class="activity-option">
                  <div class="activity-icon" :class="item.value">
                    <i :class="getActivityIcon(item.value)"></i>
                  </div>
                  <div class="activity-text">
                    <span class="activity-label">{{ item.label }}</span>
                    <span class="activity-desc">{{ item.description }}</span>
                  </div>
                </div>
              </el-option>
            </el-select>
            
            <!-- 显示当前选中的活动类型 -->
            <div v-if="activityForm.activityType" class="selected-activity-type">
              <div class="activity-icon-large" :class="activityForm.activityType">
                <i :class="getActivityIcon(activityForm.activityType)"></i>
              </div>
              <div class="selected-activity-info">
                <span class="selected-activity-label">{{ getActivityLabel(activityForm.activityType) }}</span>
                <span class="selected-activity-factor">减碳系数: {{ getActivityFactor(activityForm.activityType) }} kg/km</span>
              </div>
            </div>
          </div>
        </el-form-item>
        
        <!-- 传感器数据导入 -->
        <el-form-item label="数据来源">
          <div class="sensor-control">
            <el-switch
              v-model="useSensorData"
              active-text="使用传感器数据"
              inactive-text="手动输入"
              @change="handleSensorSwitchChange"
            />
            <el-button 
              v-if="useSensorData" 
              type="primary" 
              size="small" 
              :icon="sensorActive ? 'VideoPause' : 'VideoPlay'"
              :loading="sensorLoading"
              @click="toggleSensorMonitoring"
            >
              {{ sensorActive ? '停止监测' : '开始监测' }}
            </el-button>
          </div>
        </el-form-item>
        
        <!-- 传感器数据展示区域 -->
        <div v-if="useSensorData" class="sensor-data-panel">
          <h4>
            传感器数据 
            <el-tag size="small" :type="sensorActive ? 'success' : 'info'" effect="dark">
              <i class="el-icon-monitor"></i>
              {{ sensorActive ? '监测中' : '未监测' }}
            </el-tag>
            <span v-if="sensorActive" class="monitoring-indicator">
              <span class="pulse"></span>
            </span>
          </h4>
          <el-row :gutter="20">
            <el-col :span="8">
              <div class="sensor-item">
                <div class="sensor-icon gps-icon">
                  <el-icon><Location /></el-icon>
                </div>
                <div class="sensor-info">
                  <div class="sensor-value">{{ formatLocation(sensorValues.location) }}</div>
                  <div class="sensor-label">GPS位置</div>
                </div>
              </div>
            </el-col>
            <el-col :span="8">
              <div class="sensor-item">
                <div class="sensor-icon heart-icon">
                  <el-icon><Connection /></el-icon>
                </div>
                <div class="sensor-info">
                  <div class="sensor-value">
                    {{ sensorValues.heartRate || 0 }}次/分
                    <span v-if="sensorActive && sensorValues.heartRate" class="heartbeat-animation">
                      ❤
                    </span>
                  </div>
                  <div class="sensor-label">心率</div>
                </div>
              </div>
            </el-col>
            <el-col :span="8">
              <div class="sensor-item">
                <div class="sensor-icon speed-icon">
                  <el-icon><Position /></el-icon>
                </div>
                <div class="sensor-info">
                  <div class="sensor-value">{{ sensorValues.speed || 0 }}m/s</div>
                  <div class="sensor-label">当前速度</div>
                </div>
              </div>
            </el-col>
          </el-row>
          <el-row :gutter="20" class="sensor-row-second">
            <el-col :span="8">
              <div class="sensor-item">
                <div class="sensor-icon steps-icon">
                  <el-icon><Position /></el-icon>
                </div>
                <div class="sensor-info">
                  <div class="sensor-value">{{ sensorValues.steps || 0 }}步</div>
                  <div class="sensor-label">累计步数</div>
                  <div v-if="sensorActive && sensorValues.steps > 0" class="progress-bar">
                    <div class="progress-fill" :style="{width: Math.min(sensorValues.steps / 100, 100) + '%'}"></div>
                  </div>
                </div>
              </div>
            </el-col>
            <el-col :span="8">
              <div class="sensor-item">
                <div class="sensor-icon calories-icon">
                  <el-icon><Position /></el-icon>
                </div>
                <div class="sensor-info">
                  <div class="sensor-value">{{ sensorValues.calories || 0 }}千卡</div>
                  <div class="sensor-label">消耗卡路里</div>
                </div>
              </div>
            </el-col>
            <el-col :span="8">
              <div class="sensor-item">
                <div class="sensor-icon distance-icon">
                  <el-icon><Position /></el-icon>
                </div>
                <div class="sensor-info">
                  <div class="sensor-value">{{ (sensorValues.distance / 1000).toFixed(2) }}km</div>
                  <div class="sensor-label">累计距离</div>
                  <div v-if="sensorActive && sensorValues.distance > 0" class="progress-bar">
                    <div class="progress-fill" :style="{width: Math.min(sensorValues.distance / 1000, 100) + '%'}"></div>
                  </div>
                </div>
              </div>
            </el-col>
          </el-row>
          <div class="sensor-settings">
            <el-button v-if="!sensorActive" size="small" type="primary" plain @click="openSensorSettings">
              传感器设置
            </el-button>
          </div>
        </div>
        
        <!-- 如果不使用传感器，显示手动输入区域 -->
        <template v-if="!useSensorData">
          <!-- 开始时间 -->
          <el-form-item label="开始时间" prop="startTime">
            <el-date-picker
              v-model="activityForm.startTime"
              type="datetime"
              placeholder="选择开始时间"
              format="YYYY-MM-DD HH:mm:ss"
              value-format="YYYY-MM-DD HH:mm:ss"
              :disabled-date="disableFutureDate"
              style="width: 100%"
              :clearable="false"
              @change="handleDateChange('startTime')"
            ></el-date-picker>
            <div v-if="formErrors.startTime" class="error-message">{{ formErrors.startTime }}</div>
          </el-form-item>
          
          <!-- 结束时间 -->
          <el-form-item label="结束时间" prop="endTime">
            <el-date-picker
              v-model="activityForm.endTime"
              type="datetime"
              placeholder="选择结束时间"
              format="YYYY-MM-DD HH:mm:ss"
              value-format="YYYY-MM-DD HH:mm:ss"
              :disabled-date="disableFutureDate"
              style="width: 100%"
              :clearable="false"
              @change="handleDateChange('endTime')"
            ></el-date-picker>
            <div v-if="formErrors.endTime" class="error-message">{{ formErrors.endTime }}</div>
          </el-form-item>
          
          <!-- 活动距离 -->
          <el-form-item label="活动距离" prop="distance">
            <el-input-number
              v-model="activityForm.distance"
              :min="0"
              :max="200"
              :step="0.1"
              :precision="1"
              style="width: 100%"
            >
              <template #suffix>公里</template>
            </el-input-number>
          </el-form-item>
          
          <!-- 步数（仅步行和跑步时显示） -->
          <el-form-item v-if="activityForm.activityType === 'walking' || activityForm.activityType === 'running'" label="步数" prop="steps">
            <el-input-number
              v-model="activityForm.steps"
              :min="0"
              :max="100000"
              :step="100"
              style="width: 100%"
            >
              <template #suffix>步</template>
            </el-input-number>
          </el-form-item>
          
          <!-- 消耗卡路里 -->
          <el-form-item label="消耗卡路里" prop="calories">
            <el-input-number
              v-model="activityForm.calories"
              :min="0"
              :max="5000"
              :step="10"
              style="width: 100%"
            >
              <template #suffix>千卡</template>
            </el-input-number>
          </el-form-item>
        </template>
        
        <!-- 使用传感器时，自动设置开始和结束时间 -->
        <template v-else>
          <!-- 开始时间 -->
          <el-form-item label="开始时间" prop="startTime">
            <el-date-picker
              v-model="activityForm.startTime"
              type="datetime"
              placeholder="传感器监测开始时会自动设置"
              format="YYYY-MM-DD HH:mm:ss"
              value-format="YYYY-MM-DD HH:mm:ss"
              :disabled="sensorActive"
              :disabled-date="disableFutureDate"
              style="width: 100%"
              :clearable="false"
              @change="handleDateChange('startTime')"
            ></el-date-picker>
            <div v-if="formErrors.startTime" class="error-message">{{ formErrors.startTime }}</div>
          </el-form-item>
          
          <!-- 结束时间 -->
          <el-form-item label="结束时间" prop="endTime">
            <el-date-picker
              v-model="activityForm.endTime"
              type="datetime"
              placeholder="传感器监测结束时会自动设置"
              format="YYYY-MM-DD HH:mm:ss"
              value-format="YYYY-MM-DD HH:mm:ss"
              :disabled="sensorActive"
              :disabled-date="disableFutureDate"
              style="width: 100%"
              :clearable="false"
              @change="handleDateChange('endTime')"
            ></el-date-picker>
            <div v-if="formErrors.endTime" class="error-message">{{ formErrors.endTime }}</div>
          </el-form-item>
        </template>
        
        <!-- 活动备注 -->
        <el-form-item label="活动备注" prop="remark">
          <el-input
            v-model="activityForm.remark"
            type="textarea"
            :rows="3"
            placeholder="请输入活动备注（选填）"
          ></el-input>
        </el-form-item>
        
        <!-- 提交按钮 -->
        <el-form-item>
          <div class="submit-buttons">
            <el-button 
              type="primary" 
              :loading="loading" 
              @click="submitActivity"
              class="submit-btn"
            >
              <i class="el-icon-upload"></i> 提交活动记录
            </el-button>
            <el-button @click="resetForm" class="reset-btn">
              <i class="el-icon-refresh-right"></i> 重置
            </el-button>
          </div>
        </el-form-item>
      </el-form>
      
      <!-- 预估结果 -->
      <div class="estimate-result" v-if="showEstimate">
        <h3>减碳预估</h3>
        <div class="estimate-item">
          <span class="label">预计减碳量：</span>
          <span class="value">{{ estimateResult.carbonReduced }} kg
            <span class="eco-icon">🌱</span>
          </span>
        </div>
        <div class="estimate-item">
          <span class="label">预计获得积分：</span>
          <span class="value">{{ estimateResult.pointsEarned }} 积分
            <span class="points-icon">⭐</span>
          </span>
        </div>
        <div class="estimate-desc">
          <p>* 实际减碳量和积分将在提交后计算</p>
        </div>
      </div>
    </el-card>
    
    <!-- 活动提示 -->
    <el-card class="tips-card">
      <template #header>
        <div class="card-header">
          <h3>活动提示</h3>
        </div>
      </template>
      <div class="tips-content">
        <h4>如何获得更多积分？</h4>
        <ul>
          <li>保持每天进行低碳活动，养成良好习惯</li>
          <li>选择合适的活动类型，如骑行比步行能减少更多碳排放</li>
          <li>活动时间越长，减碳量越高，获得积分也就越多</li>
          <li>完成"连续打卡"等成就可获得额外积分奖励</li>
        </ul>
        
        <h4>记录活动注意事项</h4>
        <ul>
          <li>请如实填写活动数据，系统会对异常数据进行检查</li>
          <li>活动结束时间必须晚于开始时间</li>
          <li>单次活动最长时间不能超过24小时</li>
          <li>请在活动结束后及时提交记录</li>
        </ul>
      </div>
    </el-card>
    
    <!-- 传感器设置对话框 -->
    <el-dialog v-model="sensorSettingsVisible" title="传感器设置" width="500px">
      <el-form label-width="120px">
        <el-form-item label="活动类型">
          <el-select v-model="sensorConfig.activityType" placeholder="选择活动类型" disabled>
            <el-option 
              v-for="item in activityTypes" 
              :key="item.value" 
              :label="item.label" 
              :value="item.value" 
            />
          </el-select>
          <div class="tip-text">* 活动类型与主表单保持一致</div>
        </el-form-item>
        <el-form-item label="启用GPS定位">
          <el-switch v-model="sensorConfig.locationEnabled" />
        </el-form-item>
        <el-form-item label="启用心率监测">
          <el-switch v-model="sensorConfig.heartRateEnabled" />
        </el-form-item>
        <el-form-item label="启用运动检测">
          <el-switch v-model="sensorConfig.motionEnabled" />
        </el-form-item>
        <el-form-item label="数据噪声">
          <el-slider v-model="sensorConfig.noiseValue" :min="0" :max="10" :step="1" />
          <div class="tip-text">* 数据噪声越大，模拟数据波动越大</div>
        </el-form-item>
        <el-form-item label="更新频率(秒)">
          <el-slider v-model="sensorConfig.updateInterval" :min="1" :max="10" :step="1" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="sensorSettingsVisible = false">取消</el-button>
          <el-button type="primary" @click="saveSensorSettings">保存设置</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted, onBeforeUnmount } from 'vue';
import { ElMessage, ElMessageBox, FormInstance } from 'element-plus';
import { useRouter } from 'vue-router';
import { submitActivityRecord, estimateActivityReward } from '@/api/activity';
import { getAllEnabledFactors } from '@/api/carbonFactor';
import { getSensorConfig, updateSensorConfig, generateSimulationData } from '@/api/sensor';
import { Location, Connection, Position, VideoPlay, VideoPause } from '@element-plus/icons-vue';

const router = useRouter();
const activityFormRef = ref<FormInstance>();
const loading = ref(false);
const showEstimate = ref(false);

// 传感器相关状态
const useSensorData = ref(false);
const sensorActive = ref(false);
const sensorLoading = ref(false);
const sensorSettingsVisible = ref(false);
const sensorTimer = ref<number | null>(null);

// 传感器配置
const sensorConfig = reactive({
  locationEnabled: true,
  motionEnabled: true,
  heartRateEnabled: true,
  noiseValue: 3,
  updateInterval: 2,
  simulationMode: 1,
  activityType: 'walking'
});

// 传感器数据
const sensorValues = reactive({
  location: { latitude: 0, longitude: 0 },
  heartRate: 0,
  steps: 0,
  speed: 0,
  calories: 0,
  distance: 0
});

// 活动类型列表
const activityTypes = ref([
  { value: 'walking', label: '步行', description: '日常步行、散步', factor: 0.15 },
  { value: 'running', label: '跑步', description: '慢跑、长跑', factor: 0.2 },
  { value: 'cycling', label: '骑行', description: '自行车、共享单车', factor: 0.25 },
  { value: 'public_transport', label: '公共交通', description: '地铁、公交车、轻轨', factor: 0.03 },
  { value: 'carpooling', label: '拼车', description: '多人共乘', factor: 0.015 }
]);

// 活动表单数据
const activityForm = reactive({
  activityType: '',
  startTime: '',
  endTime: '',
  distance: 0,
  steps: 0,
  calories: 0,
  remark: ''
});

// 预估结果
const estimateResult = reactive({
  carbonReduced: 0,
  pointsEarned: 0
});

// 表单校验规则
const rules = {
  activityType: [
    { required: true, message: '请选择活动类型', trigger: 'change' }
  ],
  startTime: [
    { required: true, message: '请选择开始时间', trigger: 'change' }
  ],
  endTime: [
    { required: true, message: '请选择结束时间', trigger: 'change' },
    { validator: validateEndTime, trigger: 'change' }
  ],
  distance: [
    { required: true, message: '请输入活动距离', trigger: 'blur' }
  ]
};

// 表单错误信息
const formErrors = reactive({
  startTime: '',
  endTime: '',
  activityType: '',
  distance: ''
});

const globalError = ref(''); // 全局错误提示信息

// 禁用未来日期
const disableFutureDate = (time: Date) => {
  return time > new Date();
};

// 处理日期选择器变更事件
function handleDateChange(field: 'startTime' | 'endTime') {
  // 清除对应字段的错误
  formErrors[field] = '';
  
  // 如果日期字段有值，确保格式正确（秒级别）
  if (activityForm[field]) {
    let dateValue = activityForm[field];
    
    // 检查是否有秒级格式，如果没有则添加
    if (dateValue.length === 16 && dateValue.indexOf(':') !== -1) {
      // 只有分钟级格式 (YYYY-MM-DD HH:mm)，添加秒级
      dateValue += ':00';
      activityForm[field] = dateValue;
    }
    
    // 验证格式是否合法
    try {
      const date = new Date(dateValue);
      if (isNaN(date.getTime())) {
        formErrors[field] = `${field === 'startTime' ? '开始' : '结束'}时间格式不正确`;
      } else if (field === 'endTime' && activityForm.startTime) {
        // 如果是结束时间，验证是否晚于开始时间
        const startTime = new Date(activityForm.startTime).getTime();
        const endTime = date.getTime();
        
        if (endTime <= startTime) {
          formErrors.endTime = '结束时间必须晚于开始时间';
        } else if (endTime - startTime > 24 * 60 * 60 * 1000) {
          formErrors.endTime = '活动时间不能超过24小时';
        } else {
          // 如果都验证通过，计算预估结果
          calculateEstimate();
        }
      }
    } catch (e) {
      formErrors[field] = `${field === 'startTime' ? '开始' : '结束'}时间格式不正确`;
    }
  }
}

// 校验时间格式
function validateTimeFormat() {
  formErrors.startTime = '';
  formErrors.endTime = '';
  
  // 检查开始时间格式
  if (activityForm.startTime) {
    try {
      // 尝试修复格式 - 确保使用ISO格式（T分隔符）
      let fixedStartTime = fixDateTimeFormat(activityForm.startTime);
      
      // 如果格式没有秒，则添加":00"，并确保使用T分隔符
      if (fixedStartTime.length === 16) {
        if (fixedStartTime.includes(' ')) {
          fixedStartTime = fixedStartTime.replace(' ', 'T') + ':00';
        } else {
          fixedStartTime += ':00';
        }
      } else if (!fixedStartTime.includes('T') && fixedStartTime.includes(' ')) {
        fixedStartTime = fixedStartTime.replace(' ', 'T');
      }
      
      if (fixedStartTime !== activityForm.startTime) {
        // 如果格式已修复，更新值
        activityForm.startTime = fixedStartTime;
      }
      
      const date = new Date(activityForm.startTime);
      if (isNaN(date.getTime())) {
        formErrors.startTime = '开始时间格式错误，请重新选择';
        return false;
      }
    } catch (e) {
      formErrors.startTime = '开始时间格式错误，请重新选择';
      return false;
    }
  }
  
  // 检查结束时间格式
  if (activityForm.endTime) {
    try {
      // 尝试修复格式 - 确保使用ISO格式（T分隔符）
      let fixedEndTime = fixDateTimeFormat(activityForm.endTime);
      
      // 如果格式没有秒，则添加":00"，并确保使用T分隔符
      if (fixedEndTime.length === 16) {
        if (fixedEndTime.includes(' ')) {
          fixedEndTime = fixedEndTime.replace(' ', 'T') + ':00';
        } else {
          fixedEndTime += ':00';
        }
      } else if (!fixedEndTime.includes('T') && fixedEndTime.includes(' ')) {
        fixedEndTime = fixedEndTime.replace(' ', 'T');
      }
      
      if (fixedEndTime !== activityForm.endTime) {
        // 如果格式已修复，更新值
        activityForm.endTime = fixedEndTime;
      }
      
      const date = new Date(activityForm.endTime);
      if (isNaN(date.getTime())) {
        formErrors.endTime = '结束时间格式错误，请重新选择';
        return false;
      }
    } catch (e) {
      formErrors.endTime = '结束时间格式错误，请重新选择';
      return false;
    }
  }
  
  // 如果两者都有值，检查结束时间是否晚于开始时间
  if (activityForm.startTime && activityForm.endTime) {
    const startTime = new Date(activityForm.startTime).getTime();
    const endTime = new Date(activityForm.endTime).getTime();
    
    if (endTime <= startTime) {
      formErrors.endTime = '结束时间必须晚于开始时间';
      return false;
    }
    
    if (endTime - startTime > 24 * 60 * 60 * 1000) {
      formErrors.endTime = '活动时间不能超过24小时';
      return false;
    }
  }
  
  return true;
}

// 校验结束时间
function validateEndTime(rule: any, value: any, callback: any) {
  formErrors.endTime = '';
  
  if (value === '') {
    callback(new Error('请选择结束时间'));
    return;
  }
  
  if (!activityForm.startTime) {
    callback(new Error('请先选择开始时间'));
    return;
  }
  
  // 尝试修复开始和结束时间格式
  try {
    if (typeof activityForm.startTime === 'string' && activityForm.startTime.length === 16) {
      // 使用T分隔符添加秒
      activityForm.startTime = activityForm.startTime.replace(' ', 'T') + ':00';
    } else if (typeof activityForm.startTime === 'string' && !activityForm.startTime.includes('T')) {
      // 将空格替换为T
      activityForm.startTime = activityForm.startTime.replace(' ', 'T');
    }
    
    if (typeof value === 'string' && value.length === 16) {
      // 使用T分隔符添加秒
      activityForm.endTime = value.replace(' ', 'T') + ':00';
      // 使用修改后的值继续验证
      value = activityForm.endTime;
    } else if (typeof value === 'string' && !value.includes('T')) {
      // 将空格替换为T
      activityForm.endTime = value.replace(' ', 'T');
      value = activityForm.endTime;
    }
    
    const startDate = new Date(activityForm.startTime);
    const endDate = new Date(value);
    
    if (isNaN(startDate.getTime())) {
      formErrors.startTime = '开始时间格式错误';
      callback(new Error('开始时间格式错误'));
      return;
    }
    
    if (isNaN(endDate.getTime())) {
      formErrors.endTime = '结束时间格式错误';
      callback(new Error('结束时间格式错误'));
      return;
    }
    
    const startTime = startDate.getTime();
    const endTime = endDate.getTime();
    
    if (endTime <= startTime) {
      formErrors.endTime = '结束时间必须晚于开始时间';
      callback(new Error('结束时间必须晚于开始时间'));
      return;
    }
    
    if (endTime - startTime > 24 * 60 * 60 * 1000) {
      formErrors.endTime = '活动时间不能超过24小时';
      callback(new Error('活动时间不能超过24小时'));
      return;
    }
    
    // 计算活动时长和预估减碳量
    calculateEstimate();
    callback();
  } catch (e) {
    formErrors.endTime = '结束时间格式错误';
    callback(new Error('结束时间格式错误'));
  }
}

// 计算预估减碳量和积分
async function calculateEstimate() {
  if (!activityForm.activityType || !activityForm.startTime || !activityForm.endTime || activityForm.distance <= 0) {
    showEstimate.value = false;
    return;
  }
  
  const startTime = new Date(activityForm.startTime).getTime();
  const endTime = new Date(activityForm.endTime).getTime();
  const duration = Math.floor((endTime - startTime) / 1000); // 转换为秒
  
  try {
    // 使用API获取预估数据
    const estimateData = {
      activityType: activityForm.activityType,
      duration: duration,
      distance: activityForm.distance * 1000, // 转换为米
      steps: useSensorData.value ? sensorValues.steps : (activityForm.steps || 0)
    };
    
    const res = await estimateActivityReward(estimateData);
    
    if (res.code === 200 && res.data) {
      // 使用API返回的预估数据
      estimateResult.carbonReduced = parseFloat(res.data.carbonReduced.toFixed(2)) || 0;
      estimateResult.pointsEarned = res.data.pointsEarned || 0;
      showEstimate.value = true;
    } else {
      // 本地预估（作为备选）
      const activityType = activityTypes.value.find(type => type.value === activityForm.activityType);
      const factor = activityType ? activityType.factor : 0.15;
      
      // 计算预估减碳量（距离 * 因子）
      estimateResult.carbonReduced = parseFloat((activityForm.distance * factor).toFixed(2));
      
      // 计算预估积分（减碳量 * 10，四舍五入取整）
      estimateResult.pointsEarned = Math.round(estimateResult.carbonReduced * 10);
      showEstimate.value = true;
    }
  } catch (error) {
    console.error('预估奖励失败:', error);
    
    // 本地预估（出错时的备选）
    const activityType = activityTypes.value.find(type => type.value === activityForm.activityType);
    const factor = activityType ? activityType.factor : 0.15;
    
    // 计算预估减碳量（距离 * 因子）
    estimateResult.carbonReduced = parseFloat((activityForm.distance * factor).toFixed(2));
    
    // 计算预估积分（减碳量 * 10，四舍五入取整）
    estimateResult.pointsEarned = Math.round(estimateResult.carbonReduced * 10);
    
    showEstimate.value = true;
  }
}

// 活动类型变更处理
function handleActivityTypeChange() {
  // 如果是步行或跑步，根据距离自动计算步数
  if (activityForm.activityType === 'walking' || activityForm.activityType === 'running') {
    if (activityForm.distance > 0) {
      const stepsPerKm = activityForm.activityType === 'walking' ? 1300 : 1100;
      activityForm.steps = Math.round(activityForm.distance * stepsPerKm);
    }
  }
  
  // 更新传感器配置的活动类型
  if (useSensorData.value) {
    sensorConfig.activityType = activityForm.activityType;
  }
  
  calculateEstimate();
}

// 提交活动记录
async function submitActivity() {
  if (!activityFormRef.value) return;
  
  // 清除全局错误提示
  globalError.value = '';
  
  // 先验证日期时间格式
  if (!validateTimeFormat()) {
    globalError.value = '请检查时间格式错误';
    return;
  }
  
  const valid = await activityFormRef.value.validate();
  
  if (valid) {
    loading.value = true;
    
    try {
      // 停止传感器监测
      stopSensorMonitoring();
      
      // 再次检查时间格式
      if (!activityForm.startTime || !activityForm.endTime) {
        throw new Error('开始时间和结束时间不能为空');
      }
      
      // 确保日期格式正确使用ISO格式（包含T和秒）
      if (activityForm.startTime.length === 16) {
        activityForm.startTime = activityForm.startTime.replace(' ', 'T') + ':00';
      } else if (!activityForm.startTime.includes('T')) {
        activityForm.startTime = activityForm.startTime.replace(' ', 'T');
      }
      
      if (activityForm.endTime.length === 16) {
        activityForm.endTime = activityForm.endTime.replace(' ', 'T') + ':00';
      } else if (!activityForm.endTime.includes('T')) {
        activityForm.endTime = activityForm.endTime.replace(' ', 'T');
      }
      
      let startDate: Date, endDate: Date;
      try {
        startDate = new Date(activityForm.startTime);
        endDate = new Date(activityForm.endTime);
        
        if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
          throw new Error('时间格式错误');
        }
      } catch (e) {
        throw new Error('日期格式无效，请重新选择时间');
      }
      
      // 计算活动时长（秒）
      const startTime = startDate.getTime();
      const endTime = endDate.getTime();
      
      if (endTime <= startTime) {
        throw new Error('结束时间必须晚于开始时间');
      }
      
      const duration = Math.floor((endTime - startTime) / 1000);
      
      // 构造提交数据
      const activityData = {
        activityType: activityForm.activityType,
        startTime: activityForm.startTime,
        endTime: activityForm.endTime,
        duration,
        distance: activityForm.distance,
        steps: useSensorData.value ? sensorValues.steps : (activityForm.steps || 0),
        calories: useSensorData.value ? sensorValues.calories : (activityForm.calories || 0),
        remark: activityForm.remark || '',
        // 添加传感器数据
        sensorData: useSensorData.value ? {
          heartRate: sensorValues.heartRate,
          location: sensorValues.location,
          speed: sensorValues.speed
        } : null
      };
      
      // 提交活动记录
      const res = await submitActivityRecord(activityData);
      
      if (res && res.code === 200) {
        ElMessageBox.alert(
          `活动记录提交成功！<br>减碳量：${res.data.carbonReduced || estimateResult.carbonReduced} kg<br>获得积分：${res.data.pointsEarned || estimateResult.pointsEarned}`,
          '提交成功',
          {
            dangerouslyUseHTMLString: true,
            confirmButtonText: '确定',
            callback: () => {
              router.push('/data-statistics');
            }
          }
        );
      } else {
        ElMessage.error('提交失败：' + (res?.message || '未知错误'));
      }
    } catch (error: any) {
      console.error('提交活动记录错误:', error);
      globalError.value = '提交失败：' + (error.message || '未知错误');
      ElMessage.error('提交失败：' + (error.message || '未知错误'));
    } finally {
      loading.value = false;
    }
  } else {
    globalError.value = '请正确填写所有必填项';
    ElMessage.warning('请正确填写所有必填项');
    return;
  }
}

// 重置表单
function resetForm() {
  if (activityFormRef.value) {
    // 停止传感器监测
    stopSensorMonitoring();
    
    // 重置表单数据
    activityFormRef.value.resetFields();
    
    // 清除错误信息
    formErrors.startTime = '';
    formErrors.endTime = '';
    formErrors.activityType = '';
    formErrors.distance = '';
    globalError.value = '';
    
    // 隐藏预估结果
    showEstimate.value = false;
  }
}

// 处理传感器开关变化
function handleSensorSwitchChange(val: string | number | boolean) {
  // 使用双等号比较，处理不同类型的值
  if (val == true) {
    // 如果开启传感器数据
    if (!sensorActive.value) {
      openSensorSettings();
    }
  } else {
    // 如果关闭传感器数据
    stopSensorMonitoring();
  }
}

// 打开传感器设置
function openSensorSettings() {
  sensorSettingsVisible.value = true;
  
  // 获取当前传感器配置
  getSensorConfig().then(res => {
    if (res.code === 200 && res.data) {
      Object.assign(sensorConfig, res.data);
      // 确保活动类型与当前选择的活动类型一致
      if (activityForm.activityType) {
        sensorConfig.activityType = activityForm.activityType;
      }
    }
  }).catch(err => {
    console.error('获取传感器配置失败:', err);
  });
}

// 保存传感器设置
function saveSensorSettings() {
  sensorSettingsVisible.value = false;
  
  // 更新传感器配置
  updateSensorConfig(sensorConfig).then(res => {
    if (res.code === 200) {
      ElMessage.success('传感器设置已保存');
      
      // 如果用户选择了使用传感器数据，自动开始监测
      if (useSensorData.value && !sensorActive.value) {
        startSensorMonitoring();
      }
    } else {
      ElMessage.error('保存设置失败: ' + res.message);
    }
  }).catch(err => {
    console.error('更新传感器配置失败:', err);
    ElMessage.error('保存设置失败: ' + err.message);
  });
}

// 开始传感器监测
function startSensorMonitoring() {
  if (sensorActive.value) return;
  
  sensorLoading.value = true;
  
  // 设置开始时间为当前时间 (使用formatDateToISO函数)
  const now = new Date();
  activityForm.startTime = formatDateToISO(now);
  
  // 确保日期格式正确 - 分钟级别带秒数
  if (activityForm.startTime.length === 16) {
    activityForm.startTime += ':00';
  }
  
  // 清除错误提示
  formErrors.startTime = '';
  formErrors.endTime = '';
  globalError.value = '';
  
  // 清除之前的累计数据
  sensorValues.steps = 0;
  sensorValues.calories = 0;
  sensorValues.distance = 0;
  
  // 生成初始模拟数据
  fetchSensorData()
    .then(() => {
      sensorActive.value = true;
      // 设置定时器，定期更新数据
      sensorTimer.value = window.setInterval(() => {
        fetchSensorData();
      }, sensorConfig.updateInterval * 1000);
    })
    .catch(error => {
      globalError.value = '启动传感器监测失败: ' + (error.message || '未知错误');
      ElMessage.error('启动传感器监测失败');
      sensorLoading.value = false;
    })
    .finally(() => {
      sensorLoading.value = false;
    });
}

// 停止传感器监测
function stopSensorMonitoring() {
  if (!sensorActive.value) return;
  
  // 清除定时器
  if (sensorTimer.value) {
    clearInterval(sensorTimer.value);
    sensorTimer.value = null;
  }
  
  // 设置结束时间为当前时间 (使用formatDateToISO函数)
  if (activityForm.startTime) {
    const now = new Date();
    activityForm.endTime = formatDateToISO(now);
    
    // 确保日期格式正确 - 分钟级别带秒数
    if (activityForm.endTime.length === 16) {
      activityForm.endTime += ':00';
    }
    
    // 清除错误提示
    formErrors.endTime = '';
    
    // 验证时间是否有效
    if (validateTimeFormat()) {
      // 重新计算预估结果
      calculateEstimate();
    }
  }
  
  sensorActive.value = false;
}

// 修正日期时间格式到分钟级别
function formatDateToMinuteISO(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  
  return `${year}-${month}-${day}T${hours}:${minutes}`;
}

// 修复日期时间格式函数，用于检测和修复格式错误
function fixDateTimeFormat(dateTimeStr: string): string {
  if (!dateTimeStr) return '';
  
  try {
    // 检查日期是否为分钟级别格式 (YYYY-MM-DD HH:mm)
    if (dateTimeStr.length === 16 && dateTimeStr.split(':').length === 2) {
      // 将空格替换为T并添加秒
      return dateTimeStr.replace(' ', 'T') + ':00';
    }
    
    // 尝试直接解析
    const date = new Date(dateTimeStr);
    if (!isNaN(date.getTime())) {
      // 确保返回的是带秒的格式
      return formatDateToISO(date);
    }
    
    // 尝试修复格式 - 处理常见错误格式
    // 1. 处理格式但空格分隔符的情况 (2025-05-11 08:00:00)
    if (dateTimeStr.includes(' ') && !dateTimeStr.includes('T')) {
      const fixed = dateTimeStr.replace(' ', 'T');
      const date = new Date(fixed);
      if (!isNaN(date.getTime())) {
        return formatDateToISO(date);
      }
    }
    
    // 2. 尝试解析日期部分和时间部分
    const parts = dateTimeStr.split(/[\s]+/);
    if (parts.length >= 2) {
      const datePart = parts[0];
      const timePart = parts[1];
      
      // 检查日期部分 (YYYY-MM-DD)
      const datePieces = datePart.split('-');
      if (datePieces.length === 3) {
        const year = parseInt(datePieces[0]);
        const month = parseInt(datePieces[1]);
        const day = parseInt(datePieces[2]);
        
        if (!isNaN(year) && !isNaN(month) && !isNaN(day)) {
          // 检查时间部分 (HH:MM:SS 或 HH:MM)
          const timePieces = timePart.split(':');
          if (timePieces.length >= 2) {
            const hours = parseInt(timePieces[0]);
            const minutes = parseInt(timePieces[1]);
            const seconds = timePieces.length > 2 ? parseInt(timePieces[2]) : 0;
            
            if (!isNaN(hours) && !isNaN(minutes) && !isNaN(seconds)) {
              // 创建日期对象
              const date = new Date(year, month - 1, day, hours, minutes, seconds);
              if (!isNaN(date.getTime())) {
                return formatDateToISO(date);
              }
            }
          }
        }
      }
    }
    
    // 如果所有尝试都失败，返回原始字符串
    return dateTimeStr;
  } catch (e) {
    console.error('日期格式修复失败:', e);
    return dateTimeStr;
  }
}

// 切换传感器监测状态
function toggleSensorMonitoring() {
  if (sensorActive.value) {
    stopSensorMonitoring();
  } else {
    startSensorMonitoring();
  }
}

// 获取传感器数据
async function fetchSensorData() {
  try {
    const res = await generateSimulationData(sensorConfig.updateInterval);
    if (res.code === 200 && res.data) {
      // 更新传感器数据
      if (res.data.location) {
        sensorValues.location = res.data.location;
      }
      if (res.data.heartRate) {
        sensorValues.heartRate = res.data.heartRate;
      }
      if (res.data.steps) {
        sensorValues.steps = res.data.steps;
        // 如果使用传感器数据，自动更新表单中的步数
        if (activityForm.activityType === 'walking' || activityForm.activityType === 'running') {
          activityForm.steps = sensorValues.steps;
        }
      }
      if (res.data.speed) {
        sensorValues.speed = res.data.speed;
      }
      if (res.data.calories) {
        sensorValues.calories = res.data.calories;
        // 更新表单中的卡路里
        activityForm.calories = sensorValues.calories;
      }
      if (res.data.distance) {
        sensorValues.distance = res.data.distance;
        // 更新表单中的距离
        activityForm.distance = parseFloat((sensorValues.distance / 1000).toFixed(1)); // 转换为千米
        
        // 重新计算预估结果
        calculateEstimate();
      }
    }
  } catch (error) {
    console.error('获取传感器数据失败:', error);
    // 如果获取失败，停止监测
    stopSensorMonitoring();
    ElMessage.error('获取传感器数据失败，已停止监测');
  }
}

// 格式化位置信息
function formatLocation(location: { latitude: number, longitude: number }) {
  if (!location || location.latitude === 0 && location.longitude === 0) {
    return '暂无位置';
  }
  return `${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}`;
}

// 获取活动类型对应的图标
function getActivityIcon(type: string) {
  const iconMap: Record<string, string> = {
    'walking': 'el-icon-guide',
    'running': 'el-icon-data-analysis',
    'cycling': 'el-icon-bicycle',
    'public_transport': 'el-icon-van',
    'carpooling': 'el-icon-truck'
  };
  
  return iconMap[type] || 'el-icon-more';
}

// 获取活动类型的显示名称
function getActivityLabel(type: string): string {
  const activity = activityTypes.value.find(item => item.value === type);
  return activity ? activity.label : '未知活动';
}

// 获取活动类型的碳减排因子
function getActivityFactor(type: string): number {
  const activity = activityTypes.value.find(item => item.value === type);
  return activity ? activity.factor : 0;
}

// 组件挂载后获取碳减排因子数据
onMounted(async () => {
  try {
    // 获取碳减排因子列表
    const res = await getAllEnabledFactors();
    if (res.code === 200 && res.data && Array.isArray(res.data)) {
      // 更新活动类型的碳减排因子
      activityTypes.value.forEach(type => {
        const factor = res.data.find(item => item.activityType === type.value);
        if (factor) {
          type.factor = factor.factorValue;
        }
      });
    }
  } catch (error) {
    console.error('获取碳减排因子错误:', error);
    globalError.value = '获取碳减排因子失败，请刷新页面重试';
  }
});

// 组件卸载前清理定时器
onBeforeUnmount(() => {
  stopSensorMonitoring();
});

// 修正日期时间格式（含秒）
function formatDateToISO(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  
  return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
}
</script>

<style scoped>
.activity-submit-container {
  padding: 20px;
  background: linear-gradient(135deg, #f0f7fa 0%, #e3f2fd 100%);
  min-height: calc(100vh - 60px);
  display: flex;
  flex-direction: column;
  align-items: center;
}

.submit-card {
  margin-bottom: 20px;
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  transition: all 0.3s ease;
  overflow: hidden;
  border: none;
  width: 100%;
  max-width: 900px; /* 限制最大宽度 */
}

.submit-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
}

.card-header {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 25px 20px; /* 增加上下内边距 */
  background: linear-gradient(90deg, #409eff 0%, #67c23a 100%);
  color: white;
  text-align: center;
  position: relative;
  overflow: hidden;
}

.card-header::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><circle cx="50" cy="50" r="40" fill="white" fill-opacity="0.05"/></svg>');
  background-size: 150px 150px;
  opacity: 0.2;
}

.eco-badge {
  position: relative;
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background-color: rgba(255, 255, 255, 0.2);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 10px;
  font-size: 24px;
}

.main-title {
  margin: 0;
  font-size: 28px; /* 再增大字号 */
  font-weight: 600;
  letter-spacing: 1px;
  position: relative;
  display: inline-block;
  padding: 0 10px;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.sub-title {
  margin: 10px 0 0;
  font-size: 16px;
  opacity: 0.9;
}

.activity-form {
  margin-top: 20px;
  padding: 0 15px;
}

.estimate-result {
  margin-top: 30px;
  padding: 20px;
  background-color: #f0f9eb;
  border-radius: 8px;
  border-left: 4px solid #67c23a;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.05);
  animation: fadeIn 0.5s ease-in-out;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

.estimate-result h3 {
  margin: 0 0 15px;
  font-size: 18px;
  color: #67c23a;
  display: flex;
  align-items: center;
}

.estimate-result h3::before {
  content: "";
  display: inline-block;
  width: 18px;
  height: 18px;
  margin-right: 8px;
  background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%2367c23a"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"></path></svg>') no-repeat center center;
  background-size: contain;
}

.estimate-item {
  margin-bottom: 12px;
  display: flex;
  align-items: center;
}

.estimate-item .label {
  min-width: 120px;
  color: #606266;
  font-weight: 500;
}

.estimate-item .value {
  font-weight: 600;
  color: #303133;
  font-size: 18px;
}

.estimate-desc {
  margin-top: 15px;
  font-size: 12px;
  color: #909399;
  border-top: 1px dashed #e0e0e0;
  padding-top: 10px;
}

.tips-card {
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.08);
  border-radius: 8px;
  border: none;
  width: 100%;
  max-width: 900px; /* 与上面的卡片保持一致 */
}

.tips-card .card-header {
  background: linear-gradient(90deg, #909399 0%, #606266 100%);
}

.tips-card .card-header h3 {
  margin: 0;
  font-size: 18px;
  font-weight: 500;
}

.tips-content {
  color: #606266;
  padding: 0 15px 15px;
}

.tips-content h4 {
  margin: 20px 0 12px;
  font-size: 16px;
  color: #303133;
  position: relative;
  padding-left: 15px;
}

.tips-content h4::before {
  content: "";
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 4px;
  height: 16px;
  background: linear-gradient(to bottom, #409eff, #67c23a);
  border-radius: 2px;
}

.tips-content h4:first-child {
  margin-top: 15px;
}

.tips-content ul {
  margin: 10px 0;
  padding-left: 20px;
}

.tips-content li {
  margin-bottom: 10px;
  line-height: 1.6;
  position: relative;
  padding-left: 5px;
}

.tips-content li::marker {
  color: #409eff;
}

/* 传感器相关样式 */
.sensor-control {
  display: flex;
  align-items: center;
  gap: 15px;
}

.sensor-data-panel {
  margin: 20px 0;
  padding: 20px;
  background: linear-gradient(to right, #f0f7fa, #ecf5ff);
  border-radius: 8px;
  border-left: 4px solid #409eff;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease;
}

.sensor-data-panel h4 {
  margin: 0 0 20px 0;
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 16px;
  color: #409eff;
}

.sensor-row-second {
  margin-top: 20px;
}

.sensor-item {
  display: flex;
  align-items: center;
  padding: 15px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  transition: all 0.2s ease;
  height: 100%;
  min-height: 80px;
}

.sensor-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.sensor-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 46px;
  height: 46px;
  border-radius: 50%;
  background-color: #ecf5ff;
  color: #409eff;
  margin-right: 12px;
  flex-shrink: 0;
}

.sensor-info {
  flex: 1;
}

.sensor-value {
  font-size: 18px;
  font-weight: 500;
  color: #303133;
  margin-bottom: 6px;
}

.sensor-label {
  font-size: 13px;
  color: #909399;
}

.sensor-settings {
  margin-top: 20px;
  text-align: right;
}

.tip-text {
  font-size: 12px;
  color: #909399;
  margin-top: 5px;
  font-style: italic;
}

/* 按钮样式美化 */
.activity-form :deep(.el-button--primary) {
  background: linear-gradient(90deg, #409eff 0%, #67c23a 100%);
  border: none;
  box-shadow: 0 2px 6px rgba(64, 158, 255, 0.3);
  transition: all 0.3s ease;
}

.activity-form :deep(.el-button--primary:hover) {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(64, 158, 255, 0.4);
}

/* 表单项自定义样式 */
.activity-form :deep(.el-form-item__label) {
  font-weight: 500;
}

.activity-form :deep(.el-select .el-input__inner),
.activity-form :deep(.el-input-number .el-input__inner),
.activity-form :deep(.el-date-editor .el-input__inner),
.activity-form :deep(.el-textarea__inner) {
  border-radius: 6px;
  transition: all 0.3s ease;
}

.activity-form :deep(.el-select .el-input__inner:focus),
.activity-form :deep(.el-input-number .el-input__inner:focus),
.activity-form :deep(.el-date-editor .el-input__inner:focus),
.activity-form :deep(.el-textarea__inner:focus) {
  border-color: #409eff;
  box-shadow: 0 0 0 2px rgba(64, 158, 255, 0.2);
}

/* 对话框样式 */
:deep(.el-dialog) {
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
}

:deep(.el-dialog__header) {
  background: linear-gradient(90deg, #409eff 0%, #67c23a 100%);
  padding: 15px 20px;
}

:deep(.el-dialog__title) {
  color: white;
  font-weight: 500;
}

:deep(.el-dialog__body) {
  padding: 25px 20px;
}

:deep(.el-dialog__footer) {
  padding: 15px 20px;
  border-top: 1px solid #ebeef5;
}

/* 响应式调整 */
@media (max-width: 768px) {
  .activity-submit-container {
    padding: 10px;
  }
  
  .submit-card, .tips-card {
    margin-bottom: 15px;
  }
  
  .card-header h2 {
    font-size: 18px;
  }
  
  .estimate-item .value {
    font-size: 16px;
  }
  
  .sensor-item {
    padding: 12px;
    min-height: 70px;
  }
  
  .sensor-value {
    font-size: 16px;
  }
  
  .sensor-icon {
    width: 40px;
    height: 40px;
  }
}

.eco-icon, .points-icon {
  display: inline-block;
  margin-left: 8px;
  animation: bounce 2s infinite;
}

@keyframes bounce {
  0%, 20%, 50%, 80%, 100% {
    transform: translateY(0);
  }
  40% {
    transform: translateY(-10px);
  }
  60% {
    transform: translateY(-5px);
  }
}

.points-icon {
  animation-delay: 0.5s;
}

/* 提交按钮优化 */
.submit-buttons {
  display: flex;
  gap: 15px;
  margin-top: 10px;
}

.submit-btn {
  flex: 2;
  height: 44px;
  font-size: 16px;
  font-weight: 500;
  letter-spacing: 1px;
  padding: 0 30px;
  border-radius: 22px;
  transition: all 0.3s ease;
}

.reset-btn {
  flex: 1;
  height: 44px;
  border-radius: 22px;
  transition: all 0.3s ease;
}

.activity-form :deep(.el-button--primary.submit-btn) {
  background: linear-gradient(90deg, #409eff 0%, #67c23a 100%);
  border: none;
  box-shadow: 0 4px 12px rgba(64, 158, 255, 0.4);
}

.activity-form :deep(.el-button--primary.submit-btn:hover) {
  transform: translateY(-2px);
  box-shadow: 0 6px 16px rgba(64, 158, 255, 0.5);
}

.activity-form :deep(.el-button--default.reset-btn:hover) {
  border-color: #c0c4cc;
  color: #606266;
  transform: translateY(-2px);
  box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
}

.activity-form :deep(.el-form-item.is-error .el-input__inner),
.activity-form :deep(.el-form-item.is-error .el-textarea__inner) {
  box-shadow: 0 0 0 2px rgba(245, 108, 108, 0.1);
}

/* 美化滚动条 */
::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

::-webkit-scrollbar-track {
  background: #f5f5f5;
  border-radius: 4px;
}

::-webkit-scrollbar-thumb {
  background: #c0c4cc;
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: #909399;
}

/* 增强响应式设计 */
@media (max-width: 992px) {
  .sensor-row-second {
    margin-top: 15px;
  }
  
  .submit-btn {
    height: 40px;
    font-size: 15px;
  }
  
  .reset-btn {
    height: 40px;
  }
}

@media (max-width: 768px) {
  .activity-submit-container {
    padding: 10px;
  }
  
  .submit-card, .tips-card {
    margin-bottom: 15px;
  }
  
  .card-header h2 {
    font-size: 18px;
  }
  
  .estimate-item .value {
    font-size: 16px;
  }
  
  .sensor-item {
    padding: 12px;
    min-height: 70px;
  }
  
  .sensor-value {
    font-size: 16px;
  }
  
  .sensor-icon {
    width: 40px;
    height: 40px;
  }
  
  .submit-buttons {
    flex-direction: column;
    gap: 10px;
  }
  
  .submit-btn, .reset-btn {
    width: 100%;
  }
}

@media (max-width: 576px) {
  .activity-submit-container {
    padding: 5px;
  }
  
  .card-header h2 {
    font-size: 16px;
  }
  
  .card-header p {
    font-size: 12px;
  }
  
  .sensor-row-second {
    margin-top: 10px;
  }
  
  .submit-btn, .reset-btn {
    height: 36px;
    font-size: 14px;
  }
  
  :deep(.el-form-item__label) {
    font-size: 13px;
  }
}

/* 错误提示样式 */
.error-message {
  color: #f56c6c;
  font-size: 12px;
  margin-top: 4px;
  line-height: 1.4;
}

.el-form-item.is-error .el-input__inner,
.el-form-item.is-error .el-date-editor,
.el-form-item.is-error .el-textarea__inner {
  border-color: #f56c6c;
}

/* 全局错误提示样式 */
.global-error-alert {
  background-color: #fef0f0;
  color: #f56c6c;
  padding: 10px 15px;
  border-radius: 4px;
  margin-bottom: 15px;
  font-size: 14px;
  display: flex;
  align-items: center;
  position: relative;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  animation: fadeIn 0.3s ease;
  max-width: 900px;
  width: 100%;
}

.global-error-alert i {
  margin-right: 8px;
  font-size: 16px;
}

.close-icon {
  position: absolute;
  right: 15px;
  top: 10px;
  font-size: 16px;
  cursor: pointer;
  opacity: 0.7;
  transition: opacity 0.2s;
}

.close-icon:hover {
  opacity: 1;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(-10px); }
  to { opacity: 1; transform: translateY(0); }
}

/* 活动类型选择相关样式 */
.activity-type-wrapper {
  display: flex;
  flex-direction: column;
  gap: 15px;
  width: 100%;
}

/* 增强下拉框样式 */
:deep(.el-select .el-input__wrapper) {
  padding: 4px 12px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease;
}

:deep(.el-select .el-input__wrapper:hover) {
  box-shadow: 0 3px 10px rgba(64, 158, 255, 0.2);
}

:deep(.el-select .el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 1px #409eff inset, 0 3px 12px rgba(64, 158, 255, 0.2);
}

:deep(.el-select-dropdown__item) {
  padding: 8px 12px;
}

:deep(.el-select-dropdown__item.selected) {
  font-weight: normal;
  color: #409eff;
  background-color: #ecf5ff;
}

:deep(.el-select-dropdown__item:hover) {
  background-color: #f5f7fa;
}

/* 活动选项样式 */
.activity-option {
  display: flex;
  align-items: center;
  padding: 8px 4px;
  border-radius: 8px;
  transition: all 0.3s ease;
}

.activity-option:hover {
  background-color: #f0f7ff;
  transform: translateX(5px);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.activity-icon {
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  margin-right: 12px;
  font-size: 18px;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
  box-shadow: 0 3px 8px rgba(0, 0, 0, 0.15);
  min-width: 40px;
}

.activity-icon::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: radial-gradient(circle, rgba(255,255,255,0.5) 0%, rgba(255,255,255,0) 70%);
}

.activity-icon.walking {
  background: linear-gradient(135deg, #42b983 0%, #33a06f 100%);
  color: white;
}

.activity-icon.running {
  background: linear-gradient(135deg, #f56c6c 0%, #e74c3c 100%);
  color: white;
}

.activity-icon.cycling {
  background: linear-gradient(135deg, #409eff 0%, #1989fa 100%);
  color: white;
}

.activity-icon.public_transport {
  background: linear-gradient(135deg, #e6a23c 0%, #d48806 100%);
  color: white;
}

.activity-icon.carpooling {
  background: linear-gradient(135deg, #9c27b0 0%, #7b1fa2 100%);
  color: white;
}

.activity-text {
  display: flex;
  flex-direction: column;
}

.activity-label {
  font-weight: 500;
  font-size: 15px;
  color: #303133;
  margin-bottom: 2px;
}

.activity-desc {
  font-size: 12px;
  color: #909399;
}

/* 选中的活动类型显示样式 */
.selected-activity-type {
  display: flex;
  align-items: center;
  margin-top: 15px;
  padding: 18px;
  background: linear-gradient(120deg, #e0f7fa 0%, #e3f2fd 100%);
  border-radius: 12px;
  border-left: 4px solid #409eff;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
  animation: fadeInUp 0.5s ease;
  position: relative;
  overflow: hidden;
}

.selected-activity-type::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.4) 100%);
  opacity: 0.5;
  pointer-events: none;
}

.selected-activity-type::after {
  content: '';
  position: absolute;
  width: 100px;
  height: 100px;
  background: radial-gradient(circle, rgba(255,255,255,0.8) 0%, rgba(255,255,255,0) 70%);
  top: -30px;
  right: -30px;
  opacity: 0.4;
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(15px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.activity-icon-large {
  width: 60px;
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  color: white;
  margin-right: 18px;
  font-size: 24px;
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
  position: relative;
  overflow: hidden;
  transition: all 0.3s ease;
}

.activity-icon-large::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: radial-gradient(circle, rgba(255,255,255,0.4) 0%, rgba(255,255,255,0) 70%);
}

.activity-icon-large:hover {
  transform: scale(1.05) rotate(5deg);
}

.activity-icon-large.walking {
  background: linear-gradient(135deg, #42b983 0%, #33a06f 100%);
}

.activity-icon-large.running {
  background: linear-gradient(135deg, #f56c6c 0%, #e74c3c 100%);
}

.activity-icon-large.cycling {
  background: linear-gradient(135deg, #409eff 0%, #1989fa 100%);
}

.activity-icon-large.public_transport {
  background: linear-gradient(135deg, #e6a23c 0%, #d48806 100%);
}

.activity-icon-large.carpooling {
  background: linear-gradient(135deg, #9c27b0 0%, #7b1fa2 100%);
}

.selected-activity-info {
  display: flex;
  flex-direction: column;
  position: relative;
}

.selected-activity-label {
  font-size: 20px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 8px;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
}

.selected-activity-factor {
  display: inline-block;
  font-size: 14px;
  color: #67c23a;
  font-weight: 500;
  background-color: rgba(103, 194, 58, 0.1);
  padding: 4px 12px;
  border-radius: 20px;
  box-shadow: 0 2px 6px rgba(103, 194, 58, 0.15);
}

/* 全局活动类型下拉菜单样式 */
:deep(.activity-type-dropdown) {
  border-radius: 8px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  padding: 10px;
  width: auto !important; /* 允许宽度自适应 */
  min-width: 260px !important; /* 确保最小宽度 */
}

:deep(.activity-type-dropdown .el-scrollbar__wrap) {
  padding: 5px 0;
}

/* 调整选项内容样式 */
:deep(.el-select-dropdown__item) {
  padding: 10px 15px;
  height: auto;
  line-height: 1.5;
}

:deep(.el-select-dropdown__item.selected) {
  background-color: #f0f7ff;
}

:deep(.activity-type-dropdown .activity-option) {
  width: 100%;
  padding: 8px 6px;
}

/* 确保选择器内部元素样式 */
:deep(.el-select) {
  width: 100%;
  display: block;
}

:deep(.el-select .el-input) {
  width: 100%;
}

:deep(.el-select .el-input__wrapper) {
  width: 100%;
}

/* 响应式调整 */
@media (max-width: 768px) {
  :deep(.activity-type-dropdown) {
    width: 100% !important;
    left: 0 !important;
    right: 0 !important;
    max-width: 100% !important;
  }
  
  .activity-icon-large {
    width: 50px;
    height: 50px;
    font-size: 20px;
  }
  
  .selected-activity-label {
    font-size: 18px;
  }
}

@media (max-width: 576px) {
  .activity-icon-large {
    width: 44px;
    height: 44px;
    font-size: 18px;
    margin-right: 14px;
  }
  
  .selected-activity-label {
    font-size: 16px;
  }
  
  .selected-activity-factor {
    font-size: 12px;
    padding: 3px 10px;
  }
  
  .selected-activity-type {
    padding: 14px;
  }
}

.selected-activity-label {
  font-size: 18px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 5px;
}

.selected-activity-factor {
  font-size: 14px;
  color: #67c23a;
  font-weight: 500;
}
</style> 