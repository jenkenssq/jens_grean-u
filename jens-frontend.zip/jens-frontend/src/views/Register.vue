<template>
  <div class="register-container">
    <div class="register-card">
      <div class="card-content">
        <div class="brand-area">
          <div class="logo-circle">
            <div class="leaf-icon"></div>
          </div>
          <h2 class="page-title">碳积分游戏化项目</h2>
          <p class="slogan">参与低碳行动，赢取绿色未来</p>
        </div>
        
        <div class="form-container">
          <h3 class="form-title">用户注册</h3>
          
          <div class="form-item">
            <label>用户名</label>
            <div class="input-wrapper">
              <span class="input-icon user-icon"></span>
              <input v-model="registerForm.username" type="text" placeholder="请输入用户名">
            </div>
          </div>
          
          <div class="form-item">
            <label>昵称</label>
            <div class="input-wrapper">
              <span class="input-icon user-icon"></span>
              <input v-model="registerForm.nickname" type="text" placeholder="请输入昵称">
            </div>
          </div>
          
          <div class="form-item">
            <label>手机号</label>
            <div class="input-wrapper">
              <span class="input-icon mobile-icon"></span>
              <input v-model="registerForm.mobile" type="text" placeholder="请输入手机号">
            </div>
          </div>
          
          <div class="form-item">
            <label>邮箱</label>
            <div class="input-wrapper">
              <span class="input-icon email-icon"></span>
              <input v-model="registerForm.email" type="text" placeholder="请输入邮箱">
            </div>
          </div>
          
          <div class="form-item">
            <label>密码</label>
            <div class="input-wrapper">
              <span class="input-icon password-icon"></span>
              <input v-model="registerForm.password" type="password" placeholder="请设置密码" show-password>
            </div>
          </div>
          
          <div class="form-item">
            <label>确认密码</label>
            <div class="input-wrapper">
              <span class="input-icon password-icon"></span>
              <input v-model="registerForm.confirmPassword" type="password" placeholder="请再次输入密码" show-password>
            </div>
          </div>
          
          <button class="submit-button register-btn" @click="handleRegister" :disabled="loading">
            <span v-if="loading" class="loading-spinner"></span>
            <span v-else>注册</span>
          </button>
          
          <div class="form-footer">
            <router-link to="/login" class="switch-link">已有账号？立即登录</router-link>
          </div>
        </div>
      </div>
    </div>
    
    <div class="decorations">
      <div class="eco-element eco-element-1"></div>
      <div class="eco-element eco-element-2"></div>
      <div class="eco-element eco-element-3"></div>
      <div class="triangle triangle-1"></div>
      <div class="triangle triangle-2"></div>
      <div class="triangle triangle-3"></div>
    </div>
    
    <div class="floating-particles">
      <div class="particle particle-1"></div>
      <div class="particle particle-2"></div>
      <div class="particle particle-3"></div>
      <div class="particle particle-4"></div>
      <div class="particle particle-5"></div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue';
import { useRouter } from 'vue-router';
import { ElMessage } from 'element-plus';
import { register } from '@/api/auth';

const router = useRouter();
const loading = ref(false);

// 注册表单
const registerForm = reactive({
  username: '',
  nickname: '',
  mobile: '',
  email: '',
  password: '',
  confirmPassword: ''
});

// 表单验证
const validateForm = () => {
  if (!registerForm.username) {
    ElMessage.warning('请输入用户名');
    return false;
  }
  
  if (!registerForm.nickname) {
    ElMessage.warning('请输入昵称');
    return false;
  }
  
  if (!registerForm.mobile) {
    ElMessage.warning('请输入手机号');
    return false;
  } else if (!/^1[3-9]\d{9}$/.test(registerForm.mobile)) {
    ElMessage.warning('请输入正确的手机号码');
    return false;
  }
  
  if (!registerForm.email) {
    ElMessage.warning('请输入邮箱');
    return false;
  } else if (!/^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/.test(registerForm.email)) {
    ElMessage.warning('请输入正确的邮箱地址');
    return false;
  }
  
  if (!registerForm.password) {
    ElMessage.warning('请输入密码');
    return false;
  } else if (registerForm.password.length < 6 || registerForm.password.length > 20) {
    ElMessage.warning('密码长度应为6到20个字符');
    return false;
  }
  
  if (!registerForm.confirmPassword) {
    ElMessage.warning('请再次输入密码');
    return false;
  } else if (registerForm.password !== registerForm.confirmPassword) {
    ElMessage.warning('两次输入的密码不一致');
    return false;
  }
  
  return true;
};

// 注册处理
const handleRegister = async () => {
  if (!validateForm()) {
    return;
  }
  
  loading.value = true;
  try {
    const { confirmPassword, ...registerData } = registerForm;
    const res = await register(registerData);
    
    if (res.code === 200) {
      ElMessage.success('注册成功，请登录');
      router.push('/login');
    } else {
      ElMessage.warning(res.message || '注册结果异常，请检查');
    }
  } catch (error: any) {
    console.error('注册错误:', error);
    ElMessage.error(error.message || '注册失败，请稍后再试');
  } finally {
    loading.value = false;
  }
};
</script>

<style scoped>
.register-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%);
  position: relative;
  overflow: hidden;
}

.register-card {
  width: 420px;
  background-color: rgba(255, 255, 255, 0.95);
  border-radius: 16px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
  position: relative;
  z-index: 10;
  overflow: hidden;
  backdrop-filter: blur(5px);
  transform: translateY(0);
  transition: transform 0.5s ease-in-out;
}

.register-card:hover {
  transform: translateY(-5px);
}

.card-content {
  padding: 35px;
}

.brand-area {
  text-align: center;
  margin-bottom: 25px;
}

.logo-circle {
  width: 70px;
  height: 70px;
  border-radius: 50%;
  background: linear-gradient(45deg, #43a047, #66bb6a);
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 15px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  position: relative;
  overflow: hidden;
}

.leaf-icon {
  width: 40px;
  height: 40px;
  background-color: white;
  mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath d='M17.5 10.5C17.5 5.81 13.69 2 9 2c.18 3.68 1.83 5.97 4 7.14V10.5c-3.58.82-6.25 4.08-6.5 7.97-.5.26-.04.53.12.73.16.19.4.3.65.3h4c.71 0 1.31-.47 1.48-1.14.33-1.33 1.48-2.36 2.9-2.36h.91c2.19 0 3.95-1.76 3.95-3.95l.01-1.55zM13 17h-2v-2h2v2z'/%3E%3C/svg%3E");
  mask-size: cover;
}

.page-title {
  color: #2e7d32;
  text-align: center;
  font-size: 24px;
  font-weight: 600;
  margin-bottom: 8px;
}

.slogan {
  color: #689f38;
  font-size: 14px;
  margin-bottom: 10px;
  font-weight: 400;
}

.form-title {
  color: #2e7d32;
  text-align: center;
  font-size: 18px;
  margin-bottom: 25px;
  font-weight: 500;
  position: relative;
  padding-bottom: 10px;
}

.form-title::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 40px;
  height: 3px;
  background: linear-gradient(90deg, #66bb6a, #388e3c);
  border-radius: 3px;
}

.form-container {
  width: 100%;
  animation: fadeIn 0.5s ease-in-out;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

.form-item {
  margin-bottom: 20px;
}

.form-item label {
  display: block;
  margin-bottom: 6px;
  font-size: 14px;
  color: #444;
  font-weight: 500;
}

.input-wrapper {
  position: relative;
  display: flex;
  align-items: center;
}

.input-icon {
  position: absolute;
  left: 12px;
  width: 20px;
  height: 20px;
  opacity: 0.6;
}

.user-icon {
  background-color: #555;
  mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath d='M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z'/%3E%3C/svg%3E");
  mask-size: cover;
}

.mobile-icon {
  background-color: #555;
  mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath d='M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z'/%3E%3C/svg%3E");
  mask-size: cover;
}

.email-icon {
  background-color: #555;
  mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath d='M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z'/%3E%3C/svg%3E");
  mask-size: cover;
}

.password-icon {
  background-color: #555;
  mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath d='M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z'/%3E%3C/svg%3E");
  mask-size: cover;
}

.form-item input {
  width: 100%;
  height: 46px;
  border: 1px solid #dcdfe6;
  border-radius: 8px;
  padding: 0 15px 0 40px;
  font-size: 14px;
  transition: all 0.3s;
  background-color: #f9f9f9;
}

.form-item input:focus {
  outline: none;
  border-color: #4caf50;
  box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.2);
  background-color: #fff;
}

.form-item input::placeholder {
  color: #aaa;
}

.submit-button {
  width: 100%;
  height: 46px;
  background: linear-gradient(45deg, #2e7d32, #4caf50);
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s;
  box-shadow: 0 4px 10px rgba(76, 175, 80, 0.3);
  display: flex;
  align-items: center;
  justify-content: center;
}

.submit-button:hover {
  background: linear-gradient(45deg, #1b5e20, #388e3c);
  box-shadow: 0 6px 15px rgba(76, 175, 80, 0.4);
  transform: translateY(-2px);
}

.submit-button:active {
  transform: translateY(0);
  box-shadow: 0 2px 8px rgba(76, 175, 80, 0.3);
}

.submit-button:disabled {
  background: #cccccc;
  cursor: not-allowed;
  box-shadow: none;
}

.loading-spinner {
  display: inline-block;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-top-color: #fff;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.register-btn {
  background: linear-gradient(45deg, #388e3c, #66bb6a);
}

.register-btn:hover {
  background: linear-gradient(45deg, #2e7d32, #4caf50);
}

.form-footer {
  margin-top: 20px;
  text-align: center;
  font-size: 14px;
}

.switch-link {
  color: #4caf50;
  cursor: pointer;
  text-decoration: none;
  font-weight: 500;
  transition: color 0.3s;
}

.switch-link:hover {
  color: #2e7d32;
  text-decoration: underline;
}

.decorations {
  position: absolute;
  bottom: 0;
  right: 0;
  z-index: 1;
}

.triangle {
  position: absolute;
  width: 0;
  height: 0;
  border-style: solid;
}

.triangle-1 {
  right: 40px;
  bottom: 40px;
  border-width: 0 50px 50px 0;
  border-color: transparent rgba(46, 125, 50, 0.7) transparent transparent;
}

.triangle-2 {
  right: 100px;
  bottom: 80px;
  border-width: 0 70px 70px 0;
  border-color: transparent rgba(76, 175, 80, 0.6) transparent transparent;
}

.triangle-3 {
  right: 180px;
  bottom: 140px;
  border-width: 0 60px 60px 0;
  border-color: transparent rgba(129, 199, 132, 0.5) transparent transparent;
}

.floating-particles {
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  overflow: hidden;
  z-index: 1;
}

.particle {
  position: absolute;
  background-color: rgba(76, 175, 80, 0.2);
  border-radius: 50%;
}

.particle-1 {
  width: 30px;
  height: 30px;
  top: 20%;
  left: 10%;
  animation: float 15s infinite linear;
}

.particle-2 {
  width: 20px;
  height: 20px;
  top: 30%;
  left: 80%;
  animation: float 18s infinite linear;
}

.particle-3 {
  width: 40px;
  height: 40px;
  top: 70%;
  left: 20%;
  animation: float 20s infinite linear;
}

.particle-4 {
  width: 25px;
  height: 25px;
  top: 50%;
  left: 90%;
  animation: float 16s infinite linear;
}

.particle-5 {
  width: 35px;
  height: 35px;
  top: 80%;
  left: 60%;
  animation: float 22s infinite linear;
}

@keyframes float {
  0% {
    transform: translateY(0) rotate(0deg);
  }
  50% {
    transform: translateY(-20px) rotate(180deg);
  }
  100% {
    transform: translateY(0) rotate(360deg);
  }
}

.eco-element {
  position: absolute;
  width: 40px;
  height: 40px;
  background-color: rgba(76, 175, 80, 0.2);
  border-radius: 50%;
}

.eco-element-1 {
  top: 10%;
  left: 5%;
  width: 80px;
  height: 80px;
}

.eco-element-2 {
  top: 20%;
  right: 10%;
  width: 60px;
  height: 60px;
}

.eco-element-3 {
  bottom: 15%;
  left: 15%;
  width: 50px;
  height: 50px;
}
</style> 