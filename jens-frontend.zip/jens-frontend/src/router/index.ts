import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router';

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'Home',
    component: () => import('@/views/Home.vue'),
    meta: {
      title: '首页',
      requiresAuth: false,
    },
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/Login.vue'),
    meta: {
      title: '登录',
      requiresAuth: false,
    },
  },
  {
    path: '/register',
    name: 'Register',
    component: () => import('@/views/Register.vue'),
    meta: {
      title: '注册',
      requiresAuth: false,
    },
  },
  {
    path: '/api-test',
    name: 'ApiTest',
    component: () => import('@/views/ApiTest.vue'),
    meta: {
      title: 'API测试',
      requiresAuth: false,
    },
  },
  {
    path: '/data-statistics',
    name: 'DataStatistics',
    component: () => import('@/views/DataStatistics.vue'),
    meta: {
      title: '数据统计',
      requiresAuth: true,
    },
  },
  {
    path: '/prize',
    name: 'Prize',
    component: () => import('@/views/PrizeExchange.vue'),
    meta: {
      title: '奖品兑换',
      requiresAuth: true,
    },
  },
  {
    path: '/carbon-points-table',
    name: 'CarbonPointsTable',
    component: () => import('@/views/carbon-points-table.vue'),
    meta: {
      title: '出行方式-积分对照表',
      requiresAuth: true,
    },
  },
  {
    path: '/user-center',
    name: 'UserCenter',
    component: () => import('@/views/UserCenter.vue'),
    meta: {
      title: '用户中心',
      requiresAuth: true,
    },
  },
  {
    path: '/dashboard',
    name: 'Dashboard',
    component: () => import('@/views/UserCenter.vue'),
    meta: {
      title: '用户中心',
      requiresAuth: true,
    },
  },
  {
    path: '/activity-submit',
    name: 'ActivitySubmit',
    component: () => import('@/views/ActivitySubmit.vue'),
    meta: {
      title: '记录活动',
      requiresAuth: true,
    },
  },
  {
    path: '/achievements',
    name: 'Achievements',
    redirect: '/user-center',
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    redirect: '/',
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

// 全局前置守卫
router.beforeEach((to, from, next) => {
  // 设置页面标题
  document.title = `${to.meta.title || 'JENS碳积分游戏化系统'}`;
  
  // 检查是否需要登录
  if (to.matched.some(record => record.meta.requiresAuth)) {
    // 从localStorage获取token
    const token = localStorage.getItem('JENS_TOKEN');
    
    if (!token) {
      // 未登录，跳转到登录页
      next({
        path: '/login',
        query: { redirect: to.fullPath },  // 保存完整路径，确保包含查询参数
      });
    } else {
      // 已登录，继续访问
      next();
    }
  } else {
    // 不需要登录，继续访问
    next();
  }
});

export default router; 