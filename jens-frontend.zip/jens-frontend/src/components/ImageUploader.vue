<template>
  <div class="image-uploader">
    <div 
      v-if="!modelValue && !loading" 
      class="upload-area"
      @click="triggerUpload"
      :class="{ 'is-dragover': isDragover }"
      @dragover.prevent="isDragover = true"
      @dragleave.prevent="isDragover = false"
      @drop.prevent="handleDrop"
    >
      <el-icon class="upload-icon"><Upload /></el-icon>
      <div class="upload-text">{{ placeholder || '点击或拖拽图片上传' }}</div>
      <div class="upload-tip" v-if="tip">{{ tip }}</div>
    </div>
    
    <div v-else-if="loading" class="loading-area">
      <el-icon class="loading-icon"><Loading /></el-icon>
      <div class="loading-text">图片上传中...</div>
    </div>
    
    <div v-else class="preview-area" @click="handlePreview">
      <img :src="getImageUrl(modelValue)" class="preview-image" />
      <div class="preview-actions">
        <el-button 
          type="danger" 
          circle 
          size="small" 
          @click.stop="handleRemove"
          title="删除图片"
        >
          <el-icon><Delete /></el-icon>
        </el-button>
      </div>
    </div>
    
    <input 
      ref="fileInput"
      type="file" 
      :accept="accept"
      style="display: none"
      @change="handleFileChange"
    />
    
    <el-dialog v-model="previewVisible" title="图片预览" width="50%">
      <img :src="getImageUrl(modelValue)" style="width: 100%" />
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, defineProps, defineEmits } from 'vue';
import { ElMessage } from 'element-plus';
import { Upload, Loading, Delete } from '@element-plus/icons-vue';
import { uploadImage, getImageUrl } from '@/utils/file-upload';

// 定义组件属性
const props = defineProps({
  modelValue: {
    type: String,
    default: ''
  },
  placeholder: {
    type: String,
    default: ''
  },
  tip: {
    type: String,
    default: '支持JPG、PNG、GIF格式，最大5MB'
  },
  accept: {
    type: String,
    default: 'image/jpeg,image/png,image/gif,image/webp'
  }
});

// 定义事件
const emit = defineEmits(['update:modelValue', 'upload-success', 'upload-error', 'remove']);

// 组件状态
const fileInput = ref<HTMLInputElement | null>(null);
const loading = ref(false);
const isDragover = ref(false);
const previewVisible = ref(false);

// 触发文件选择对话框
const triggerUpload = () => {
  if (fileInput.value) {
    fileInput.value.click();
  }
};

// 处理文件选择
const handleFileChange = async (event: Event) => {
  const target = event.target as HTMLInputElement;
  if (!target.files || target.files.length === 0) {
    return;
  }
  
  const file = target.files[0];
  await uploadFile(file);
  
  // 清空文件选择，以便下次选择同一文件时仍能触发change事件
  if (fileInput.value) {
    fileInput.value.value = '';
  }
};

// 处理拖放上传
const handleDrop = async (event: DragEvent) => {
  isDragover.value = false;
  
  if (!event.dataTransfer || !event.dataTransfer.files || event.dataTransfer.files.length === 0) {
    return;
  }
  
  const file = event.dataTransfer.files[0];
  if (!file.type.startsWith('image/')) {
    ElMessage.error('只能上传图片文件');
    return;
  }
  
  await uploadFile(file);
};

// 上传文件
const uploadFile = async (file: File) => {
  loading.value = true;
  
  try {
    const result = await uploadImage(file);
    
    if (result.code === 200 && result.data) {
      emit('update:modelValue', result.data);
      emit('upload-success', result.data);
      ElMessage.success('图片上传成功');
    } else {
      emit('upload-error', result.message);
      ElMessage.error(result.message || '图片上传失败');
    }
  } catch (error: any) {
    console.error('上传图片失败:', error);
    emit('upload-error', error.message || '图片上传失败');
    ElMessage.error(error.message || '图片上传失败');
  } finally {
    loading.value = false;
  }
};

// 处理图片预览
const handlePreview = () => {
  if (props.modelValue) {
    previewVisible.value = true;
  }
};

// 处理图片删除
const handleRemove = () => {
  emit('update:modelValue', '');
  emit('remove');
};
</script>

<style scoped>
.image-uploader {
  width: 100%;
}

.upload-area {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  text-align: center;
  padding: 30px 20px;
  transition: border-color 0.3s;
}

.upload-area:hover, .upload-area.is-dragover {
  border-color: #409EFF;
}

.upload-icon {
  font-size: 28px;
  color: #8c939d;
  margin-bottom: 10px;
}

.upload-text {
  font-size: 14px;
  color: #606266;
  margin-bottom: 6px;
}

.upload-tip {
  font-size: 12px;
  color: #909399;
}

.loading-area {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  position: relative;
  overflow: hidden;
  text-align: center;
  padding: 30px 20px;
}

.loading-icon {
  font-size: 28px;
  color: #409EFF;
  animation: rotating 2s linear infinite;
  margin-bottom: 10px;
}

.loading-text {
  font-size: 14px;
  color: #606266;
}

.preview-area {
  position: relative;
  border-radius: 6px;
  overflow: hidden;
}

.preview-image {
  width: 100%;
  display: block;
}

.preview-actions {
  position: absolute;
  top: 8px;
  right: 8px;
  display: none;
}

.preview-area:hover .preview-actions {
  display: block;
}

@keyframes rotating {
  from {
    transform: rotateZ(0deg);
  }
  to {
    transform: rotateZ(360deg);
  }
}
</style> 